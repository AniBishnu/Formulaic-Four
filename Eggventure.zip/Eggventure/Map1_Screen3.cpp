#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void display_Map1_Screen3()
{
    glPushMatrix();
    glTranslated(6.0,0.0,0.0);

    ///pani

    glBegin(GL_POLYGON);
    glColor3ub(16,81,137);
    glVertex2f(-0.58f,-0.73f);
    glVertex2f(-0.04f,-0.73f);
    glVertex2f(-0.04f,-1.0f);
    glVertex2f(-0.58f,-1.0f);
    glEnd();






    ///wall


    rassta(0.202,-0.96);
    bar(0.17,-0.96);
    bar(0.38,-0.96);
    bar(0.57,-0.96);
    glLineWidth(2.2);
    pathor(1.45,-0.02);

    glBegin(GL_POLYGON);
    glColor3f(0.447f,0.306f,0.290f);
    glVertex2f(-1.0f,-0.54f);
    glVertex2f(-0.73f,-0.54f);
    glVertex2f(-0.73f,-0.67f);
    glVertex2f(-1.0f,-0.67f);
    glEnd();

    glLineWidth(6);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(-1.0f,-0.56f);
    glVertex2f(-0.73f,-0.56f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.447f,0.306f,0.290f);
    glVertex2f(0.08f,-0.54f);
    glVertex2f(1.0f,-0.54f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(0.08f,-0.67f);
    glEnd();

    glLineWidth(6);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(0.08f,-0.56f);
    glVertex2f(1.0f,-0.56f);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(161,150,146);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(-0.73f,-0.67f);
    glVertex2f(-0.73f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(161,150,146);
    glVertex2f(0.08f,-0.67f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(0.08f,-1.0f);
    glEnd();


     /// Bricks
    ///1
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.7f);
    glVertex2f(-0.89f,-0.7f);
    glVertex2f(-0.89f,-0.78f);
    glVertex2f(-0.99f,-0.78f);
    glEnd();
    ///2
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.99f,-0.8f);
    glVertex2f(-0.89f,-0.8f);
    glVertex2f(-0.89f,-0.88f);
    glVertex2f(-0.99f,-0.88f);
    glEnd();

    ///3
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.9f);
    glVertex2f(-0.87f,-0.9f);
    glVertex2f(-0.87f,-1.0f);
    glVertex2f(-0.99f,-1.0f);
    glEnd();

    ///4
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.88f,-0.7f);
    glVertex2f(-0.82f,-0.7f);
    glVertex2f(-0.82f,-0.78f);
    glVertex2f(-0.88f,-0.78f);
    glEnd();

///5
    glBegin(GL_POLYGON);
     glColor3ub(117,51,16);
    glVertex2f(-0.81f,-0.7f);
    glVertex2f(-0.77f,-0.7f);
    glVertex2f(-0.77f,-0.78f);
    glVertex2f(-0.81f,-0.78f);
    glEnd();



     ///14
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.04f,-0.7f);
    glVertex2f(0.19f,-0.7f);
    glVertex2f(0.19f,-0.78f);
    glVertex2f(0.04f,-0.78f);
    glEnd();


     ///15
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.20f,-0.7f);
    glVertex2f(0.23f,-0.7f);
    glVertex2f(0.23f,-0.78f);
    glVertex2f(0.20f,-0.78f);
    glEnd();

    ///16
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.24f,-0.7f);
    glVertex2f(0.39f,-0.7f);
    glVertex2f(0.39f,-0.78f);
    glVertex2f(0.24f,-0.78f);
    glEnd();

      ///17
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.4f,-0.7f);
    glVertex2f(0.51f,-0.7f);
    glVertex2f(0.51f,-0.78f);
    glVertex2f(0.4f,-0.78f);
    glEnd();

          ///18
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.52f,-0.7f);
    glVertex2f(0.59f,-0.7f);
    glVertex2f(0.59f,-0.78f);
    glVertex2f(0.52f,-0.78f);
    glEnd();

          ///19
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.6f,-0.7f);
    glVertex2f(0.64f,-0.7f);
    glVertex2f(0.64f,-0.78f);
    glVertex2f(0.6f,-0.78f);
    glEnd();


          ///20
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.65f,-0.7f);
    glVertex2f(0.74f,-0.7f);
    glVertex2f(0.74f,-0.78f);
    glVertex2f(0.65f,-0.78f);
    glEnd();

             ///21
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.75f,-0.7f);
    glVertex2f(0.8f,-0.7f);
    glVertex2f(0.8f,-0.78f);
    glVertex2f(0.75f,-0.78f);
    glEnd();

           ///22
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.81f,-0.7f);
    glVertex2f(0.88f,-0.7f);
    glVertex2f(0.88f,-0.78f);
    glVertex2f(0.81f,-0.78f);
    glEnd();

              ///23
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.89f,-0.7f);
    glVertex2f(1.0f,-0.7f);
    glVertex2f(1.0f,-0.78f);
    glVertex2f(0.89f,-0.78f);
    glEnd();



///24
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.88f,-0.8f);
    glVertex2f(-0.78f,-0.8f);
    glVertex2f(-0.78f,-0.88f);
    glVertex2f(-0.88f,-0.88f);
    glEnd();




       ///32
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.01f,-0.8f);
    glVertex2f(0.15f,-0.8f);
    glVertex2f(0.15f,-0.88f);
    glVertex2f(0.01f,-0.88f);
    glEnd();

         ///33
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.16f,-0.8f);
    glVertex2f(0.28f,-0.8f);
    glVertex2f(0.28f,-0.88f);
    glVertex2f(0.16f,-0.88f);
    glEnd();

         ///34
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.29f,-0.8f);
    glVertex2f(0.38f,-0.8f);
    glVertex2f(0.38f,-0.88f);
    glVertex2f(0.29f,-0.88f);
    glEnd();

      ///34
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.39f,-0.8f);
    glVertex2f(0.46f,-0.8f);
    glVertex2f(0.46f,-0.88f);
    glVertex2f(0.39f,-0.88f);
    glEnd();
        ///35
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.47f,-0.8f);
    glVertex2f(0.51f,-0.8f);
    glVertex2f(0.51f,-0.88f);
    glVertex2f(0.47f,-0.88f);
    glEnd();
       ///36
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.52f,-0.8f);
    glVertex2f(0.6f,-0.8f);
    glVertex2f(0.6f,-0.88f);
    glVertex2f(0.52f,-0.88f);
    glEnd();

        ///37
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.61f,-0.8f);
    glVertex2f(0.75f,-0.8f);
    glVertex2f(0.75f,-0.88f);
    glVertex2f(0.61f,-0.88f);
    glEnd();
    ///38
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.76f,-0.8f);
    glVertex2f(0.91f,-0.8f);
    glVertex2f(0.91f,-0.88f);
    glVertex2f(0.76f,-0.88f);
    glEnd();
 ///40
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.92f,-0.8f);
    glVertex2f(1.0f,-0.8f);
    glVertex2f(1.0f,-0.88f);
    glVertex2f(0.92f,-0.88f);
    glEnd();


    ///41
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.86f,-0.9f);
    glVertex2f(-0.79f,-0.9f);
    glVertex2f(-0.79f,-1.0f);
    glVertex2f(-0.86f,-1.0f);
    glEnd();



      ///47
    glBegin(GL_POLYGON);
    glColor3ub(123,81,57);
    glVertex2f(0.08,-0.9f);
    glVertex2f(0.18f,-0.9f);
    glVertex2f(0.18f,-1.0f);
    glVertex2f(0.08,-1.0f);
    glEnd();

     ///48
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.19,-0.9f);
    glVertex2f(0.34f,-0.9f);
    glVertex2f(0.34f,-1.0f);
    glVertex2f(0.19,-1.0f);
    glEnd();
     ///49
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.35,-0.9f);
    glVertex2f(0.41f,-0.9f);
    glVertex2f(0.41f,-1.0f);
    glVertex2f(0.35,-1.0f);
    glEnd();
    ///50
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.42,-0.9f);
    glVertex2f(0.49f,-0.9f);
    glVertex2f(0.49f,-1.0f);
    glVertex2f(0.42,-1.0f);
    glEnd();

       ///51
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.5,-0.9f);
    glVertex2f(0.62f,-0.9f);
    glVertex2f(0.62f,-1.0f);
    glVertex2f(0.5f,-1.0f);
    glEnd();
           ///52
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.63,-0.9f);
    glVertex2f(0.75f,-0.9f);
    glVertex2f(0.75f,-1.0f);
    glVertex2f(0.63,-1.0f);
    glEnd();
         ///53
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.76,-0.9f);
    glVertex2f(0.87f,-0.9f);
    glVertex2f(0.87f,-1.0f);
    glVertex2f(0.76,-1.0f);
    glEnd();
///54
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.88,-0.9f);
    glVertex2f(1.0f,-0.9f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(0.88f,-1.0f);
    glEnd();


    rassta(0,0);

    bar(0,0);
    bar(0.17,0);
    bar(0.34,0);
    obs1(0,1.168);
    obs1(0.233,1.168);
    pathor(0,-0.02);
    pathor(0.22,-0.02);
    pathor(0.44,-0.02);
    pathor(0.66,-0.02);
    pathor(0.66,-0.417);
    pathor(0,-0.417);
    grass(0.77,-0.341);
    grass(0.89,-0.341);

    glLineWidth(1);
    woodenBox(0.55,0.16);
    woodenBox(0.77,0.16);
    glPopMatrix();

}

