#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"


void backbox()
{
    ///box back down dark gray
    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(-0.46f,-0.18f);
    glVertex2f(0.13f,-0.18f);
    glVertex2f(0.13f,-1.0f);
    glVertex2f(-0.46f,-1.0f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(-0.46f,-0.18f);
    glVertex2f(0.13f,-0.18f);
    glVertex2f(0.13f,-1.0f);
    glVertex2f(-0.46f,-1.0f);
    glEnd();
}


void boxin(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(47,150,175);
    glVertex2f(x+(-0.40f),y+(-0.25f));
    glVertex2f(x+(-0.16f),y+(-0.25f));
    glVertex2f(x+(-0.16f),y+(-0.6f));
    glVertex2f(x+(-0.40f),y+(-0.6f));
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.40f),y+(-0.25f));
    glVertex2f(x+(-0.16f),y+(-0.25f));
    glVertex2f(x+(-0.16f),y+(-0.6f));
    glVertex2f(x+(-0.40f),y+(-0.6f));
    glEnd();

    glPointSize(5);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.38f),y+(-0.28f));
    glVertex2f(x+(-0.18f),y+(-0.28f));
    glVertex2f(x+(-0.18f),y+(-0.57f));
    glVertex2f(x+(-0.38f),y+(-0.57f));
    glEnd();
}

void display_Map3_Screen1(float x,float y)
{
    glPushMatrix();
    glTranslatef(2.0f, 0.0f, 0.0f);
    ///Back ground
    glBegin(GL_POLYGON);
    glColor3ub(43,35,67);
    glVertex2f(1.0f,1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glVertex2f(-1.0f,1.0f);
    glEnd();




    ///wall back upper silver

    glBegin(GL_POLYGON);
    glColor3ub(47,150,175);
    glVertex2f(-1.0f,-0.52f);
    glVertex2f(-0.46f,-0.52f);
    glVertex2f(-0.46f,-0.67f);
    glVertex2f(-1.0f,-0.67f);
    glEnd();

    ///wall back down dark gray
    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(-0.460f,-0.67f);
    glVertex2f(-0.460f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();

    ///yellow and black brick
    obst1(0.0,0.0);
    obst1(0.26,0.0);
    obst1(0.36,0.0);


    ///white Back ground white transparent 1
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POLYGON);
    glColor4ub(255,255,255,110);
    glVertex2f(-0.46f,-0.535f);
    glVertex2f(-1.0f,-0.535f);
    glVertex2f(-1.0f,-0.55f);
    glVertex2f(-0.46f,-0.55f);
    glEnd();


    levelDevide(0.0,0.0);
    levelDevide(0.10,0.10);
    levelDevide(0.20,0.20);
    levelDevide(0.30,0.30);
    levelDevide(0.40,0.40);

    ///black Back ground solid
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(-0.460f,-0.61f);
    glVertex2f(-1.0f,-0.61f);
    glVertex2f(-1.0f,-0.63f);
    glVertex2f(-0.460f,-0.63f);
    glEnd();


    ///black Back ground solid
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(-0.460f,-0.63f);
    glVertex2f(-1.0f,-0.63f);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(-0.460f,-0.67f);


    ///black Back ground transparent 1
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(-0.460f,-0.60f);
    glVertex2f(-1.0f,-0.60f);
    glVertex2f(-1.0f,-0.64f);
    glVertex2f(-0.460f,-0.64f);
    glEnd();

    ///black Back ground transparent 2
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(-0.460f,-0.655f);
    glVertex2f(-1.0f,-0.655f);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(-0.460f,-0.67f);
    glEnd();

    ///Row 1
    brickR1(0.00,0.00);
    brickR1(0.18,0.00);
    brickR1(0.36,0.00);


    ///Row 2

     ///brick 1
    glBegin(GL_POLYGON);
    glColor3ub(48,85,129);
    glVertex2f(-0.99f,-0.80f);
    glVertex2f(-0.95f,-0.80f);
    glVertex2f(-0.95f,-0.88f);
    glVertex2f(-0.99f,-0.88f);
    glEnd();

    brickR2(0.00,0.00);
    brickR2(0.18,0.00);
    brickR2(0.36,0.00);

    ///Row 3
    brickR3(0.00,0.00);
    brickR3(0.18,0.00);
    brickR3(0.36,0.00);

    backbox();
    boxin(0.0,0.0);
    boxin(0.24,0.0);
    boxin(0.0,-0.36);
    boxin(0.24,-0.36);


    pathway();
    glPushMatrix();
    glTranslatef(0.87,-0.33,0.0);
    pathway();
    glPopMatrix();

    pathway();
    glPushMatrix();
    glTranslatef(0.87,0.41,0.0);
    pathway();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.59,-0.48,0.0);
    pathway();
    glPopMatrix();
    box_M3(0.0,0.0);
    box_M3(-0.32,0.0);
    piller_M3(0.05,0.12);
    piller_M3(-0.9,0.12);
    glPopMatrix();
}
