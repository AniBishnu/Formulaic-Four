#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void bridge()
{

    glBegin(GL_POLYGON);
    glColor3ub(190,116,71);
    glVertex2f(-0.12f,-0.31f);
    glVertex2f(0.55f,-0.31f);
    glVertex2f(0.55f,-0.41f);
    glVertex2f(-0.12f,-0.41f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(190,116,71);
    glVertex2f(0.55f,-0.31f);
    glVertex2f(0.7f,-0.54f);
    glVertex2f(0.63f,-0.54f);
    glVertex2f(0.55f,-0.41f);
    glEnd();
}

void bridgedanda9()
{
    glTranslatef(0.07f,0.0f,0.0f);
    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(0.47f,-0.2f);
    glVertex2f(0.64f,-0.46f);
    glVertex2f(0.64f,-0.475f);
    glVertex2f(0.46f,-0.205f);
    glEnd();

}


void bridgeColumn()
{

    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(-0.12f,-0.41f);
    glVertex2f(-0.02f,-0.41f);
    glVertex2f(0.2f,-0.63f);
    glVertex2f(0.18f,-0.7f);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(0.45f,-0.41f);
    glVertex2f(0.55f,-0.41f);
    glVertex2f(0.25f,-0.7f);
    glVertex2f(0.22f,-0.63f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(163,110,60);
    glVertex2f(0.21f,-0.61f);
    glVertex2f(0.26f,-0.7f);
    glVertex2f(0.17f,-0.7f);
    glEnd();



}


void bridgeColumn1(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(x+(-0.375f),y+(-0.94f));
    glVertex2f(x+(-0.375f),y+(-0.67f));
    glVertex2f(x+(-0.295f),y+(-0.67f));
    glVertex2f(x+(-0.295f),y+(-0.94f));
    glVertex2f(x+(-0.27f),y+(-1.0f));
    glVertex2f(x+(-0.40f),y+(-1.0f));
    glEnd();

    glLineWidth(2);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.375f),y+(-0.94f));
    glVertex2f(x+(-0.295f),y+(-0.94f));
    glEnd();

}

void bridgeTrap()
{
    glBegin(GL_TRIANGLES);
    glColor3ub(123,87,58);
    glVertex2f(0.62f,0.24f);
    glVertex2f(0.77f,0.1f);
    glVertex2f(0.77f,0.4f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(0.77f,0.4f);
    glVertex2f(0.97,0.4f);
    glVertex2f(0.97f,0.1f);
    glVertex2f(0.77f,0.1f);
    glEnd();

    glLineWidth(18);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(0.77f,0.24f);
    glVertex2f(0.97,0.24f);
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(117,51,16);
    glVertex2f(0.77f,0.24f);
    glVertex2f(0.97,0.24f);
    glEnd();



}
void display_Map1_Screen2(float x,float y)
{
    glPushMatrix();
    glTranslatef(4.0,0.0,0.0);



///pani

    glBegin(GL_POLYGON);
    glColor3ub(46,165,255);
    glVertex2f(-1.0,-0.82f);
    glVertex2f(1.0f,-0.82f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0,-1.0f);
    glEnd();

    ///wall

    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(-1.0f,-0.54f);
    glVertex2f(-0.84f,-0.54f);
    glVertex2f(-0.84f,-0.67f);
    glVertex2f(-1.0f,-0.67f);
    glEnd();


    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(-1.0f,-0.56f);
    glVertex2f(-0.84f,-0.56f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(-0.86f,-0.67f);
    glVertex2f(-0.86f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();




    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(-0.77f,-0.54f);
    glVertex2f(-0.57f,-0.54f);
    glVertex2f(-0.57f,-0.67f);
    glVertex2f(-0.77f,-0.67f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(-0.51f,-0.61f);
    glVertex2f(-0.28f,-0.61f);
    glVertex2f(-0.28f,-0.67f);
    glVertex2f(-0.51f,-0.67f);
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(-0.51f,-0.62f);
    glVertex2f(-0.28f,-0.62f);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(-0.51f,-0.43f);
    glVertex2f(-0.28f,-0.43f);
    glVertex2f(-0.28f,-0.605f);
    glVertex2f(-0.51f,-0.605f);
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(-0.51f,-0.43f);
    glVertex2f(-0.28f,-0.43f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(-0.395f,-0.42f);
    glVertex2f(-0.395f,-0.6f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(0.58f,-0.54f);
    glVertex2f(1.0f,-0.54f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(0.58f,-0.67f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(0.51f,-0.67f);
    glVertex2f(0.51f,-0.77f);
    glVertex2f(0.45f,-0.77f);
    glVertex2f(0.45f,-0.87f);
    glVertex2f(0.41f,-0.87f);
    glVertex2f(0.41f,-1.0f);



    glEnd();

     /// Bricks
    ///1
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.7f);
    glVertex2f(-0.89f,-0.7f);
    glVertex2f(-0.89f,-0.78f);
    glVertex2f(-0.99f,-0.78f);
    glEnd();
    ///2
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.99f,-0.8f);
    glVertex2f(-0.89f,-0.8f);
    glVertex2f(-0.89f,-0.88f);
    glVertex2f(-0.99f,-0.88f);
    glEnd();

    ///3
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.9f);
    glVertex2f(-0.87f,-0.9f);
    glVertex2f(-0.87f,-1.0f);
    glVertex2f(-0.99f,-1.0f);
    glEnd();





          ///11
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.52f,-0.7f);
    glVertex2f(0.59f,-0.7f);
    glVertex2f(0.59f,-0.78f);
    glVertex2f(0.52,-0.78f);
    glEnd();

          ///12
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.6f,-0.7f);
    glVertex2f(0.64f,-0.7f);
    glVertex2f(0.64f,-0.78f);
    glVertex2f(0.6,-0.78f);
    glEnd();


          ///13
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.65f,-0.7f);
    glVertex2f(0.74f,-0.7f);
    glVertex2f(0.74f,-0.78f);
    glVertex2f(0.65,-0.78f);
    glEnd();

             ///14
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.75f,-0.7f);
    glVertex2f(0.8f,-0.7f);
    glVertex2f(0.8f,-0.78f);
    glVertex2f(0.75,-0.78f);
    glEnd();

           ///15
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.81f,-0.7f);
    glVertex2f(0.88f,-0.7f);
    glVertex2f(0.88f,-0.78f);
    glVertex2f(0.81,-0.78f);
    glEnd();

              ///16
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.89f,-0.7f);
    glVertex2f(1.0f,-0.7f);
    glVertex2f(1.0f,-0.78f);
    glVertex2f(0.89,-0.78f);
    glEnd();







        ///23
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.47f,-0.8f);
    glVertex2f(0.51f,-0.8f);
    glVertex2f(0.51f,-0.88f);
    glVertex2f(0.47f,-0.88f);
    glEnd();
       ///24
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.52f,-0.8f);
    glVertex2f(0.6f,-0.8f);
    glVertex2f(0.6f,-0.88f);
    glVertex2f(0.52f,-0.88f);
    glEnd();

        ///25
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.61f,-0.8f);
    glVertex2f(0.75f,-0.8f);
    glVertex2f(0.75f,-0.88f);
    glVertex2f(0.61f,-0.88f);
    glEnd();
    ///26
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.76f,-0.8f);
    glVertex2f(0.91f,-0.8f);
    glVertex2f(0.91f,-0.88f);
    glVertex2f(0.76f,-0.88f);
    glEnd();
 ///27
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.92f,-0.8f);
    glVertex2f(1.0f,-0.8f);
    glVertex2f(1.0f,-0.88f);
    glVertex2f(0.92f,-0.88f);
    glEnd();




    ///34
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.42,-0.9f);
    glVertex2f(0.49f,-0.9f);
    glVertex2f(0.49f,-1.0f);
    glVertex2f(0.42,-1.0f);
    glEnd();

       ///35
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.5,-0.9f);
    glVertex2f(0.62f,-0.9f);
    glVertex2f(0.62f,-1.0f);
    glVertex2f(0.5f,-1.0f);
    glEnd();
           ///36
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.63,-0.9f);
    glVertex2f(0.75f,-0.9f);
    glVertex2f(0.75f,-1.0f);
    glVertex2f(0.63,-1.0f);
    glEnd();
    ///37
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.76,-0.9f);
    glVertex2f(0.87f,-0.9f);
    glVertex2f(0.87f,-1.0f);
    glVertex2f(0.76,-1.0f);
    glEnd();
    ///38
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.88,-0.9f);
    glVertex2f(1.0f,-0.9f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(0.88f,-1.0f);
    glEnd();

    bridge();
    bridgeColumn1(.55,0);
    bridgeColumn();
    bridgedanda(0.4,0.225);
    bridgedanda(0.47,0.225);
    bridgedanda(0.54,0.225);
    bridgedanda(0.61,0.225);
    bridgedanda(0.68,0.225);
    bridgedanda(0.75,0.225);
    bridgedanda(0.82,0.225);
    bridgedanda(0.89,0.225);
    bridgedanda(0.96,0.225);
    bridgedanda(1.0,0.225);
    bridgedanda1(1.17,0);
    bridgedanda9();
    bridgeTrap();

    glPopMatrix();
}
