#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void display_Map3_Screen2()
{
    glPushMatrix();
    glTranslated(4.0,0.0,0.0);



    ///wall back upper

    glBegin(GL_POLYGON);
    glColor3ub(47,150,175);
    glVertex2f(-1.0f,-0.52f);
    glVertex2f(1.0f,-0.52f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(-1.0f,-0.67f);
    glEnd();

    ///wall back down
    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();

    ///yellow and black brick
    obst1(0.0,0.0);
    obst1(0.36,0.0);
    obst1(1.06,0.0);
    obst1(1.26,0.0);
    obst1(1.56,0.0);


    ///white Back ground white transparent 1
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POLYGON);
    glColor4ub(255,255,255,110);
    glVertex2f(1.0f,-0.535f);
    glVertex2f(-1.0f,-0.535f);
    glVertex2f(-1.0f,-0.55f);
    glVertex2f(1.0f,-0.55f);
    glEnd();


    levelDevide(0.0,0.0);
    levelDevide(0.10,0.10);
    levelDevide(0.20,0.20);
    levelDevide(0.30,0.30);
    levelDevide(0.40,0.40);
    levelDevide(0.50,0.50);
    levelDevide(0.60,0.60);
    levelDevide(0.70,0.70);
    levelDevide(0.80,0.80);
    levelDevide(0.90,0.90);
    levelDevide(1.00,1.00);
    levelDevide(1.10,1.10);
    levelDevide(1.20,1.20);
    levelDevide(1.30,1.30);
    levelDevide(1.40,1.40);
    levelDevide(1.50,1.50);
    levelDevide(1.60,1.60);
    levelDevide(1.70,1.70);
    levelDevide(1.80,1.80);

    ///black Back ground solid
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(1.0f,-0.61f);
    glVertex2f(-1.0f,-0.61f);
    glVertex2f(-1.0f,-0.63f);
    glVertex2f(1.0f,-0.63f);
    glEnd();


    ///black Back ground solid
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(1.0f,-0.63f);
    glVertex2f(-1.0f,-0.63f);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(1.0f,-0.67f);


    ///black Back ground transparent 1
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(1.0f,-0.60f);
    glVertex2f(-1.0f,-0.60f);
    glVertex2f(-1.0f,-0.64f);
    glVertex2f(1.0f,-0.64f);
    glEnd();

    ///black Back ground transparent 2
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(1.0f,-0.655f);
    glVertex2f(-1.0f,-0.655f);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(1.0f,-0.67f);
    glEnd();

    ///Row 1
    brickR1(0.00,0.00);
    brickR1(0.18,0.00);
    brickR1(0.36,0.00);
    brickR1(0.54,0.00);
    brickR1(0.72,0.00);
    brickR1(0.9,0.00);
    brickR1(1.08,0.00);
    brickR1(1.26,0.00);
    brickR1(1.44,0.00);
    brickR1(1.62,0.00);
    brickR1(1.8,0.00);
    brickR1(1.98,0.00);
    brickR1(2.16,0.00);

    ///Row 2

     ///brick 1
    glBegin(GL_POLYGON);
    glColor3ub(48,85,129);
    glVertex2f(-0.99f,-0.80f);
    glVertex2f(-0.95f,-0.80f);
    glVertex2f(-0.95f,-0.88f);
    glVertex2f(-0.99f,-0.88f);
    glEnd();

    brickR2(0.00,0.00);
    brickR2(0.18,0.00);
    brickR2(0.36,0.00);
    brickR2(0.54,0.00);
    brickR2(0.72,0.00);
    brickR2(0.9,0.00);
    brickR2(1.08,0.00);
    brickR2(1.26,0.00);
    brickR2(1.44,0.00);
    brickR2(1.62,0.00);
    brickR2(1.8,0.00);
    brickR2(1.98,0.00);

    ///Row 3
    brickR3(0.00,0.00);
    brickR3(0.18,0.00);
    brickR3(0.36,0.00);
    brickR3(0.54,0.00);
    brickR3(0.72,0.00);
    brickR3(0.9,0.00);
    brickR3(1.08,0.00);
    brickR3(1.26,0.00);
    brickR3(1.44,0.00);
    brickR3(1.62,0.00);
    brickR3(1.8,0.00);
    brickR3(1.98,0.00);




    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(1.05f,-1.0f);
    glVertex2f(1.05f,1.0f);
    glVertex2f(1.0f,1.0f);
    glEnd();
    bridge_M3(0.0,0.0);
    piller_M3(0.0,0.12);
    piller_M3(0.4,0.12);
    X_Box_M3(0.0,0.0);
    bridgepiller(0,0);
    bridgepiller(-0.2,0);
    bridgepiller(-0.4,0);
    bridgepiller(-0.6,0);
    cross(0,0);
    cross(0.12,0);
    cross(0.24,0);
    cross(0.36,0);
    cross(0.48,0);
    cross(0.60,0);
    cross(0.72,0);
    cross(0.84,0);

    box_M3(-0.09,-0.23);
    box_M3(-0.41,-0.23);

    glPopMatrix();
}
