#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"


void square(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(99,116,136);
    glVertex2f(0.8f,0.81f);
    glVertex2f(0.8f,-0.74f);
    glVertex2f(-0.86f,-0.74f);
    glVertex2f(-0.86f,0.81f);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(99,116,136);
    glVertex2f(0.8f,0.81f);
    glVertex2f(1.0f,1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(0.8f,-0.74f);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(99,116,136);
    glVertex2f(-1.0f,-1.0f);
    glVertex2f(-0.86f,-0.74f);
    glVertex2f(-0.86f,0.81f);
    glVertex2f(-1.0f,1.0f);

    glEnd();

}

void square1TI(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(35,42,49);
    glVertex2f(-0.88f,0.75f);
    glVertex2f(0.81f,0.75f);
    glVertex2f(0.81f,-0.71f);
    glVertex2f(-0.88f,-0.71f);
    glEnd();

}

void square2TI(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(20,23,29);
    glVertex2f(-0.8f,0.67f);
    glVertex2f(0.72f,0.67f);
    glVertex2f(0.72f,-0.61f);
    glVertex2f(-0.8f,-0.61f);
    glEnd();

}

void insidesquare(float x , float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(43,46,54);
    glVertex2f(x+(-0.77f),y+(0.57f));
    glVertex2f(x+(-0.53f),y+(0.57f));
    glVertex2f(x+(-0.53f),y+(-0.01f));
    glVertex2f(x+(-0.77f),y+(-0.01f));
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.77f),y+(0.57f));
    glVertex2f(x+(-0.53f),y+(0.57f));
    glVertex2f(x+(-0.53f),y+(-0.01f));
    glVertex2f(x+(-0.77f),y+(-0.01f));
    glEnd();

    glPointSize(9);
    glBegin(GL_POINTS);
    glColor3ub(21,23,27);
    glVertex2f(x+(-0.75f),y+(0.54f));
    glVertex2f(x+(-0.55f),y+(0.54f));
    glVertex2f(x+(-0.55f),y+(0.03f));
    glVertex2f(x+(-0.75f),y+(0.03f));
    glEnd();
}


void insidesquare1(float x , float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(43,46,54);
    glVertex2f(x+(-0.17f),y+(0.57f));
    glVertex2f(x+(-0.53f),y+(0.57f));
    glVertex2f(x+(-0.53f),y+(-0.01f));
    glVertex2f(x+(-0.17f),y+(-0.01f));
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.17f),y+(0.57f));
    glVertex2f(x+(-0.53f),y+(0.57f));
    glVertex2f(x+(-0.53f),y+(-0.01f));
    glVertex2f(x+(-0.17f),y+(-0.01f));
    glEnd();

    glPointSize(9);
    glBegin(GL_POINTS);
    glColor3ub(21,23,27);
    glVertex2f(x+(-0.5f),y+(0.54f));
    glVertex2f(x+(-0.19f),y+(0.54f));
    glVertex2f(x+(-0.19f),y+(0.03f));
    glVertex2f(x+(-0.5f),y+(0.03f));
    glEnd();
}

void insidesquare2(float x , float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(43,46,54);
    glVertex2f(x+(0.54f),y+(0.57f));
    glVertex2f(x+(0.7f),y+(0.57f));
    glVertex2f(x+(0.7f),y+(-0.01f));
    glVertex2f(x+(0.54f),y+(-0.01f));
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(0.54f),y+(0.57f));
    glVertex2f(x+(0.7f),y+(0.57f));
    glVertex2f(x+(0.7f),y+(-0.01f));
    glVertex2f(x+(0.54f),y+(-0.01f));
    glEnd();

    glPointSize(9);
    glBegin(GL_POINTS);
    glColor3ub(21,23,27);
    glVertex2f(x+(0.57f),y+(0.54f));
    glVertex2f(x+(0.57f),y+(0.03f));
    glEnd();
}

void text()
{
    glLineWidth(7);
    glBegin(GL_LINES);
    glColor3ub(255,255,255);
    glVertex2f(-0.75f,0.55f);
    glVertex2f(0.69f,0.55f);
    glVertex2f(-0.75f,0.4f);
    glVertex2f(0.69f,0.4f);
    glEnd();
    glColor3ub(255,255,255);
    renderBitmapString(-0.67f, 0.45f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "ID");
    renderBitmapString(-0.73f, 0.32f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "22-46080-1");
    renderBitmapString(-0.73f, 0.22f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "22-46084-1");
    renderBitmapString(-0.73f, 0.12f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "22-46115-1");
    renderBitmapString(-0.73f, 0.02f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "22-46116-1");
    renderBitmapString(-0.73f, -0.08f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "22-46118-1");
    renderBitmapString(-0.4f, 0.45f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Name");
    renderBitmapString(-0.4f, 0.32f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Avirupa Das");
    renderBitmapString(-0.4f, 0.22f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Mahfuza Farjana");
    renderBitmapString(-0.4f, 0.12f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Anirudda Nath Bishnu");
    renderBitmapString(-0.4f, 0.02f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "MD. Taufiqur Rahman");
    renderBitmapString(-0.4f, -0.08f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "MD. Nasif Sadnan Chowdhury");
    renderBitmapString(0.5f, 0.45f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Contribution");
    renderBitmapString(0.5f, 0.32f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "");
    renderBitmapString(0.5f, 0.22f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Contribution");
    renderBitmapString(0.5f, 0.12f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Contribution");
    renderBitmapString(0.5f, 0.02f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Contribution");
    renderBitmapString(0.5f, -0.08f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Contribution");
    renderBitmapString(-0.2f, -0.18f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Supervised By");
    renderBitmapString(-0.23f, -0.27f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Mahfuzur Rahman");
    renderBitmapString(-0.16f, -0.36f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Lecturer");
    renderBitmapString(-0.299f, -0.44f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Faculty of Science & Technology");
    renderBitmapString(-0.39f, -0.51f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "American International University-Bangladesh");
    glBegin(GL_LINES);
    glColor3ub(255,255,255);
    glVertex2f(-0.75f,-0.54f);
    glVertex2f(0.69f,-0.54f);

    glEnd();

}


void BackscreenTI(float x, float y)
{
    ///transparent
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,200);
    glVertex2f(-1.0f,1.0f);
    glVertex2f(1.0f,1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();
    ///glDisable(GL_BLEND);




    square(0,0);
    square1(0,0);
    square2(0,0);
    insidesquare(0,0);
    insidesquare(0,-0.58);
    insidesquare1(0.35,0);
    insidesquare1(0.71,0);
    insidesquare1(0.35,-0.58);
    insidesquare1(0.71,-0.58);
    insidesquare1(0,0);
    insidesquare1(0,-0.58);
    insidesquare2(0,-0.58);
    insidesquare2(0,0.0);
    glPushMatrix();
    glTranslatef(0.0,-0.03,0.0);
    glBegin(GL_POLYGON);
    glColor4ub(52,18,17,255);
    glVertex2f(-0.38f,0.81f);
    glVertex2f(0.43f,0.81f);
    glVertex2f(0.43f,0.73f);
    glVertex2f(-0.38f,0.73f);
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(-0.38f,0.81f);
    glVertex2f(0.43f,0.81f);
    glVertex2f(0.43f,0.73f);
    glVertex2f(-0.38f,0.73f);
    glEnd();


    glPointSize(8);
    glPushMatrix();
    glTranslatef(0.01,0.0,0.0);
    glBegin(GL_POINTS);
    glColor4ub(0,0,0,127);
    glVertex2f(-0.82f,0.7f);
    glVertex2f(0.75f,0.7f);
    glVertex2f(0.75f,-0.66f);
    glVertex2f(-0.82f,-0.66f);
    glEnd();
    glPopMatrix();



    /// menu
    glBegin(GL_POLYGON);
    glColor4ub(58,60,72,255);
    glVertex2f(-0.3f,0.77f);
    glVertex2f(-0.25f,0.9f);
    glVertex2f(0.3f,0.9f);
    glVertex2f(0.35f,0.77f);
    glVertex2f(0.3f,0.64f);
    glVertex2f(-0.25f,0.64f);
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(-0.3f,0.77f);
    glVertex2f(-0.25f,0.9f);
    glVertex2f(0.3f,0.9f);
    glVertex2f(0.35f,0.77f);
    glVertex2f(0.3f,0.64f);
    glVertex2f(-0.25f,0.64f);
    glEnd();

    glBegin(GL_POINTS);
    glColor4ub(0,0,0,127);
    glVertex2f(-0.24f,0.86f);
    glVertex2f(0.29f,0.86f);
    glVertex2f(0.29f,0.68f);
    glVertex2f(-0.24f,0.68f);
    glEnd();
    glPopMatrix();
    text();






    ///glPushMatrix();
    ///glScalef();
    glColor3ub(255,255,255);
    renderBitmapString(-0.02f, 0.78f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Team");
    renderBitmapString(-0.05f, 0.68f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Information");
    glColor3ub(0,0,0);


    ///renderBitmapString(-0.49f, 0.4f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Game output");
    ///renderBitmapString(0.25f, 0.4f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Keyboard input");
    ///Options_Back(0.0,0.0);
    ///Options_Back(0.75,0.0);
}

void Team_display()
{
    glClearColor(0.196f, 0.658f, 0.514, 0.0f); // Set background color to black and opaque
    glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer (background)



    Initial_Display="home";
    ///Back ground
    glBegin(GL_POLYGON);
    glColor3f(1.0f,1.0f,1.0f);
    glVertex2f(1.0f,1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glVertex2f(-1.0f,1.0f);
    glEnd();

    ///Back ground
    glBegin(GL_POLYGON);
    glColor3ub(100,164,251);
    glVertex2f(1.0f,-.47f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glVertex2f(-1.0f,-.47f);
    glEnd();

/// pahar

    glBegin(GL_POLYGON);
    glColor3f(0.298f,0.682f,0.286f);
    glVertex2f(-0.29f,-0.47f);
    glVertex2f(-0.22f,-0.35f);
    glVertex2f(-0.2f,-0.34f);
    glVertex2f(-0.19f,-0.35f);
    glVertex2f(-0.1f,-0.46f);
    glVertex2f(0.03f,-0.34f);
    glVertex2f(0.05f,-0.33f);
    glVertex2f(0.06f,-0.34f);
    glVertex2f(0.21f,-0.45f);
    glVertex2f(0.31f,-0.35f);
    glVertex2f(0.33f,-0.33f);
    glVertex2f(0.35f,-0.35f);
    glVertex2f(0.49f,-0.48f);
    glVertex2f(0.57f,-0.41f);
    glVertex2f(0.59f,-0.39f);
    glVertex2f(0.6f,-0.4f);
    glVertex2f(0.69f,-0.49f);
    glVertex2f(0.79f,-0.3f);
    glVertex2f(0.89f,-0.44f);
    glVertex2f(1.0f,-0.34f);
    glVertex2f(1.0f,-0.59f);
    glVertex2f(-0.4f,-0.59f);
    glVertex2f(-0.4f,-0.43f);
    glVertex2f(-0.32f,-0.43f);
    glEnd();



    ///wall

    glBegin(GL_POLYGON);
    glColor3f(0.447f,0.306f,0.290f);
    glVertex2f(-1.0f,-0.3f);
    glVertex2f(-0.32f,-0.3f);
    glVertex2f(-0.32f,-0.43f);
    glVertex2f(-1.0f,-0.43f);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3f(0.851f,0.851f,0.851f);
    glVertex2f(-1.0f,-0.43f);
    glVertex2f(-0.4f,-0.43f);
    glVertex2f(-0.4f,-0.57f);
    glVertex2f(-1.0f,-0.57f);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3f(0.851f,0.851f,0.851f);
    glVertex2f(-1.0f,-0.57f);
    glVertex2f(-0.37f,-0.57f);
    glVertex2f(-0.37f,-0.74f);
    glVertex2f(-1.0f,-0.74f);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3f(0.851f,0.851f,0.851f);
    glVertex2f(-0.43f,-0.74f);
    glVertex2f(-1.0f,-0.74f);
    glVertex2f(-1.0f,-0.85f);
    glVertex2f(-0.43f,-0.85f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.851f,0.851f,0.851f);
    glVertex2f(-1.0f,-0.85f);
    glVertex2f(-0.37f,-0.85f);
    glVertex2f(-0.37f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();





    ///ghas

    glBegin(GL_POLYGON);
    glColor3f(0.137f,0.31f,0.118f);
    glVertex2f(0.13f,-1.0f);
    glVertex2f(0.11f,-0.9f);
    glVertex2f(0.1f,-0.85f);
    glVertex2f(0.09f,-0.78f);
    glVertex2f(0.09f,-0.76f);
    glVertex2f(0.12f,-0.78f);
    glVertex2f(0.14f,-0.81f);
    glVertex2f(0.16f,-0.85f);
    glVertex2f(0.16f,-0.67f);
    glVertex2f(0.16f,-0.62f);
    glVertex2f(0.17f,-0.56f);
    glVertex2f(0.18f,-0.53f);
    glVertex2f(0.2f,-0.56f);
    glVertex2f(0.21f,-0.59f);
    glVertex2f(0.21f,-0.6f);
    glVertex2f(0.22f,-0.63f);
    glVertex2f(0.23f,-0.7f);
    glVertex2f(0.23f,-0.76f);
    glVertex2f(0.24f,-0.83f);
    glVertex2f(0.26f,-0.79f);
    glVertex2f(0.27f,-0.73f);
    glVertex2f(0.28f,-0.69f);
    glVertex2f(0.29f,-0.66f);
    glVertex2f(0.31f,-0.65f);
    glVertex2f(0.32f,-0.68f);
    glVertex2f(0.32f,-0.72f);
    glVertex2f(0.31f,-0.79f);
    glVertex2f(0.28f,-1.0f);
    glEnd();

    ///ghas 2
    glBegin(GL_POLYGON);
    glColor3f(0.137f,0.31f,0.118f);
    glVertex2f(0.35f,-1.0f);
    glVertex2f(0.34f,-0.96f);
    glVertex2f(0.35f,-0.87f);
    glVertex2f(0.36f,-0.9f);
    glVertex2f(0.37f,-0.82f);
    glVertex2f(0.38f,-0.75f);
    glVertex2f(0.39f,-0.7f);
    glVertex2f(0.41f,-0.75f);
    glVertex2f(0.42f,-0.81f);
    glVertex2f(0.43f,-0.89f);
    glVertex2f(0.45f,-0.83f);
    glVertex2f(0.47f,-0.8f);
    glVertex2f(0.48f,-0.83f);
    glVertex2f(0.47f,-0.9f);
    glVertex2f(0.45f,-0.96f);

    glVertex2f(0.44f,-1.0f);
    glEnd();





    ///Gach

    glBegin(GL_POLYGON);
    glColor3f(0.388f,0.145f,0.090f);
    glVertex2f(0.9f,-0.65f);
    glVertex2f(0.88f,-0.95f);
    glVertex2f(0.88f,-1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(1.0f,-0.48f);
    glVertex2f(0.91f,-0.48f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.388f,0.145f,0.090f);
    glVertex2f(0.91f,-0.48f);
    glVertex2f(0.92f,-0.1f);
    glVertex2f(0.93f,0.07f);
    glVertex2f(1.0f,0.07f);
    glVertex2f(1.0f,-0.48f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.388f,0.145f,0.090f);
    glVertex2f(0.93f,0.07f);
    glVertex2f(0.9f,0.41f);
    glVertex2f(1.0f,0.41f);
    glVertex2f(1.0f,0.07f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.388f,0.145f,0.090f);
    glVertex2f(0.9f,0.41f);
    glVertex2f(0.84f,0.65f);
    glVertex2f(1.0f,0.65f);
    glVertex2f(1.0f,0.41f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.388f,0.145f,0.090f);
    glVertex2f(0.84f,0.65f);
    glVertex2f(0.81f,0.78f);
    glVertex2f(1.0f,0.78f);
    glVertex2f(1.0f,0.65f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.388f,0.145f,0.090f);
    glVertex2f(0.69f,1.0f);
    glVertex2f(1.0f,1.0f);
    glVertex2f(1.0f,0.41f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2f(0.91f,0.64f);
    glVertex2f(0.92f,0.65f);
    glVertex2f(0.96f,1.0f);
    glVertex2f(0.78f,1.0f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2f(0.95f,0.68f);
    glVertex2f(0.96f,0.67f);
    glVertex2f(1.04f,1.0f);
    glVertex2f(0.975f,1.0f);
    glEnd();

        ///danda

    glBegin(GL_POLYGON);
    glColor3f(0.918f,0.545f,0.427f);
    glVertex2f(0.51f,0.46f);
    glVertex2f(0.56f,0.53f);
    glVertex2f(0.57f,-0.75f);
    glVertex2f(0.53f,-0.75f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.918f,0.545f,0.427f);
    glVertex2f(0.86f,0.45f);
    glVertex2f(0.79f,0.49f);
    glVertex2f(0.76f,-0.69f);
    glVertex2f(0.81f,-0.73f);
    glEnd();

    ///Arrow Board

    glBegin(GL_POLYGON);
    glColor3f(0.757f,0.33f,0.22f);
    glVertex2f(0.89f,0.43f);
    glVertex2f(0.96f,0.29f);
    glVertex2f(0.87f,0.19f);
    glVertex2f(0.46f,0.22f);
    glVertex2f(0.45f,0.27f);
    glVertex2f(0.45f,0.4f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.757f,0.33f,0.22f);
    glVertex2f(0.92f,0.05f);
    glVertex2f(0.95f,0.13f);
    glVertex2f(0.49f,0.17f);
    glVertex2f(0.44f,0.05f);
    glVertex2f(0.48f,-0.04f);
    glVertex2f(0.92f,-0.04f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.757f,0.33f,0.22f);
    glVertex2f(0.88f,-0.11f);
    glVertex2f(0.95f,-0.25f);
    glVertex2f(0.87f,-0.33f);
    glVertex2f(0.5f,-0.29f);
    glVertex2f(0.48f,-0.23f);
    glVertex2f(0.48f,-0.15f);
    glEnd();

    /// Bricks
    ///1
    glBegin(GL_POLYGON);
    glColor3f(0.459f,0.2f,0.063f);
    glVertex2f(-1.0f,-0.47f);
    glVertex2f(-0.88f,-0.47f);
    glVertex2f(-0.88f,-0.59f);
    glVertex2f(-1.0f,-0.59f);
    glEnd();
    ///2
    glBegin(GL_POLYGON);
    glColor3f(0.698f,0.396f,0.22f);
    glVertex2f(-0.87f,-0.47f);
    glVertex2f(-0.72f,-0.47f);
    glVertex2f(-0.72f,-0.59f);
    glVertex2f(-0.87f,-0.59f);
    glEnd();


    ///3
    glBegin(GL_POLYGON);
    glColor3f(0.267f,0.231f,0.227f);
    glVertex2f(-0.71f,-0.47f);
    glVertex2f(-0.57f,-0.47f);
    glVertex2f(-0.57f,-0.59f);
    glVertex2f(-0.71f,-0.59f);
    glEnd();
    ///4
    glBegin(GL_POLYGON);
    glColor3f(0.482f,0.318f,0.224f);
    glVertex2f(-0.56f,-0.47f);
    glVertex2f(-0.42f,-0.47f);
    glVertex2f(-0.42f,-0.59f);
    glVertex2f(-0.56f,-0.59f);
    glEnd();


    ///5
    glBegin(GL_POLYGON);
    glColor3f(0.639f,0.431f,0.235f);
    glVertex2f(-1.0f,-0.61f);
    glVertex2f(-0.85f,-0.61f);
    glVertex2f(-0.85f,-0.72f);
    glVertex2f(-1.0f,-0.72f);
    glEnd();


///6
    glBegin(GL_POLYGON);
    glColor3f(0.459f,0.2f,0.063f);
    glVertex2f(-0.84f,-0.61f);
    glVertex2f(-0.73f,-0.61f);
    glVertex2f(-0.73f,-0.72f);
    glVertex2f(-0.84f,-0.72f);
    glEnd();

///7
    glBegin(GL_POLYGON);
    glColor3f(0.698f,0.608f,0.475f);
    glVertex2f(-0.72f,-0.61f);
    glVertex2f(-0.64f,-0.61f);
    glVertex2f(-0.64f,-0.72f);
    glVertex2f(-0.72f,-0.72f);
    glEnd();

///8
    glBegin(GL_POLYGON);
    glColor3f(0.482f,0.318f,0.224f);
    glVertex2f(-0.63f,-0.61f);
    glVertex2f(-0.55f,-0.72f);
    glVertex2f(-0.55f,-0.72f);
    glVertex2f(-0.63f,-0.61f);
    glEnd();

///9
    glBegin(GL_POLYGON);
    glColor3f(0.459f,0.2f,0.063f);
    glVertex2f(-0.54f,-0.61f);
    glVertex2f(-0.39f,-0.61f);
    glVertex2f(-0.39f,-0.72f);
    glVertex2f(-0.54f,-0.72f);
    glEnd();

///10
    glBegin(GL_POLYGON);
    glColor3f(0.918f,0.729f,0.541f);
    glVertex2f(-1.0f,-0.74f);
    glVertex2f(-0.9f,-0.74f);
    glVertex2f(-0.9f,-0.85f);
    glVertex2f(-1.0f,-0.85f);
    glEnd();

///11
    glBegin(GL_POLYGON);
    glColor3f(0.698f,0.396f,0.22f);
    glVertex2f(-0.89f,-0.74f);
    glVertex2f(-0.72f,-0.74f);
    glVertex2f(-0.72f,-0.85f);
    glVertex2f(-0.89f,-0.85f);
    glEnd();

///12
    glBegin(GL_POLYGON);
    glColor3f(0.482f,0.318f,0.224f);
    glVertex2f(-0.71f,-0.74f);
    glVertex2f(-0.53f,-0.74f);
    glVertex2f(-0.53f,-0.85f);
    glVertex2f(-0.71f,-0.85f);
    glEnd();

///13
    glBegin(GL_POLYGON);
    glColor3f(0.459f,0.2f,0.063f);
    glVertex2f(-0.52f,-0.74f);
    glVertex2f(-0.44f,-0.74f);
    glVertex2f(-0.44f,-0.85f);
    glVertex2f(-0.52f,-0.85f);
    glEnd();
 ///14
    glBegin(GL_POLYGON);
    glColor3f(0.698f,0.396f,0.22f);
    glVertex2f(-1.0f,-0.87f);
    glVertex2f(-0.87f,-0.87f);
    glVertex2f(-0.87f,-1.0f);
    glVertex2f(-1.f,-1.0f);
    glEnd();
///15
    glBegin(GL_POLYGON);
    glColor3f(0.698f,0.608f,0.475f);
    glVertex2f(-0.86f,-0.87f);
    glVertex2f(-0.77f,-0.87f);
    glVertex2f(-0.77f,-1.0f);
    glVertex2f(-0.86f,-1.0f);
    glEnd();
///16




    glBegin(GL_POLYGON);
    glColor3f(0.459f,0.2f,0.063f);
    glVertex2f(-0.76f,-0.87f);
    glVertex2f(-0.7f,-0.87f);
    glVertex2f(-0.7f,-1.0f);
    glVertex2f(-0.76f,-1.0f);
    glEnd();
///17

    glBegin(GL_POLYGON);
    glColor3f(0.639f,0.431f,0.235f);
    glVertex2f(-0.69f,-0.87f);
    glVertex2f(-0.59f,-0.87f);
    glVertex2f(-0.59f,-1.0f);
    glVertex2f(-0.69f,-1.0f);
    glEnd();
///18

    glBegin(GL_POLYGON);
    glColor3f(0.698f,0.396f,0.22f);
    glVertex2f(-0.58f,-0.87f);
    glVertex2f(-0.39f,-0.87f);
    glVertex2f(-0.39f,-1.0f);
    glVertex2f(-0.58f,-1.0f);
    glEnd();



///pink button outside
    glBegin(GL_POLYGON);
    glColor3ub(244,203,239);
    glVertex2f(-0.06f,0.05f);
    glVertex2f(-0.02f,0.11f);
    glVertex2f(0.05f,0.11f);
    glVertex2f(0.09f,0.05f);
    glVertex2f(0.09f,-0.11f);
    glVertex2f(0.05f,-0.2f);

    glVertex2f(-0.02f,-0.2f);
      glVertex2f(-0.06f,-0.11f);

    glEnd();

    ///1st triangle
       glBegin(GL_POLYGON);
    glColor3ub(125,50,139);
    glVertex2f(-0.06f,-0.02f);
    glVertex2f(-0.06f,-0.07f);
    glVertex2f(-0.03f,-0.04f);


    glEnd();

    ///2nd triangle
       glBegin(GL_POLYGON);
    glColor3ub(125,50,139);
    glVertex2f(0.01f,0.11f);
    glVertex2f(0.03f,0.11f);
    glVertex2f(0.02f,0.07f);
        glEnd();

    ///3rd triangle



       glBegin(GL_POLYGON);
    glColor3ub(125,50,139);
    glVertex2f(0.09f,-0.01f);
    glVertex2f(0.09f,-0.08f);
    glVertex2f(0.07f,-0.04f);
        glEnd();


        ///4th triangle Error
           glBegin(GL_TRIANGLES);
    glColor3ub(125,50,139);
    glVertex2f(0.03f,-0.02f);
    glVertex2f(0.01f,-0.02f);
    glVertex2f(0.02f,-0.14f);
        glEnd();




///Ash outside logo

    glBegin(GL_POLYGON);
    glColor3ub(196,196,196);
    glVertex2f(-0.26f,0.29f);
    glVertex2f(-0.2f,0.4f);
    glVertex2f(-0.15f,0.29f);
    glVertex2f(-0.2f,0.17f);

    glEnd();


    ///Ash inside logo


    glBegin(GL_POLYGON);
    glColor3ub(117,117,117);
    glVertex2f(-0.24f,0.28f);
    glVertex2f(-0.2f,0.35f);
    glVertex2f(-0.17f,0.29f);
    glVertex2f(-0.2f,0.21f);

    glEnd();





    Pata c;
	c.position1(0,0);         // Clear the color buffer (background)
	c.position1(-0.2,0.14);         // Clear the color buffer (background)
	c.position1(-0.0,0.17);         // Clear the color buffer (background)
	c.position1(-0.0,0.17);         // Clear the color buffer (background)
	c.position1(0.1,0.19);         // Clear the color buffer (background)
	c.position1(0.07,0.13);         // Clear the color buffer (background)
	c.position1(-0.07,0.10);         // Clear the color buffer (background)
	c.position1(-0.04,0.12);         // Clear the color buffer (background)
	c.position1(-0.05,0.17);         // Clear the color buffer (background)
	c.position1(-0.1,0.2);         // Clear the color buffer (background)
	c.position1(-0.34,0.153);         // Clear the color buffer (background)

	BackscreenTI(0.0,0.0);

    glFlush(); // Render now
}
