#ifndef CLOUD_H_INCLUDED
#define CLOUD_H_INCLUDED
#include <iostream>

void cloud(float x, float y);
void Movement_SpecialInput(int key, int x, int y);


void Movement_SpecialInputM2(int key, int x, int y);
void Movement_handleKeypressM2(unsigned char key, int x, int y);

void Movement_handleKeypress_Home(unsigned char key, int x, int y);
void Movement_handleKeypress_Map_Opt(unsigned char key, int x, int y);



void Movement_SpecialInputM3(int key, int x, int y);
void Movement_handleKeypressM3(unsigned char key, int x, int y);

void square2(float x,float y);
void square1(float x,float y);
void housebrickR2(float x,float y);
void housebrickR1(float x,float y);

char inputed_option_Home();
char inputed_option_Map_Opt();

void Movement_handleKeypress(unsigned char key, int x, int y);
void renderBitmapString(float x, float y, float z, void *font, char *string);


void Home_display();
void Map_Opt_display();
void Team_display();


extern std::string Initial_Display;



extern GLfloat Load_Scale;

extern GLfloat mapTranslateX ;
extern GLfloat charTranslateX ;
extern GLfloat charTranslatey ;

extern GLboolean jumping ;
extern GLboolean jumped ;


void Start_Game();
void Load_display();


class character2
{
public:
    float X_Left_Char=0.1;
    float X_Right_Char=0.22;
    float Y_Top_Char= -0.4;
    float Y_Bottom_Char=-0.54;

    float set_right_Char(){return X_Right_Char;}
    float set_Left_Char(){return X_Left_Char;}
    float set_Top_Char(){return Y_Top_Char;}
    float set_Bottom_Char(){return Y_Bottom_Char;}

    void Draw()
    {
        glPushMatrix();
        glTranslatef(charTranslateX,0.0, 0.0f);
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        glVertex2f(0.1,charTranslatey+(-0.4f));
        glVertex2f(0.22f,charTranslatey+(-0.4f));
        glVertex2f(0.22f,charTranslatey+(-0.54f));
        glVertex2f(0.1f,charTranslatey+(-0.54f));
        glEnd();
        glPopMatrix();
    }
};


void menuboard(float x, float y);
void pointboard(float x, float y);

void point_table();

#endif // CLOUD_H_INCLUDED
