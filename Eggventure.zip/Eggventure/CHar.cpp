#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"


/*void character::Draw()
{
    glPushMatrix();
    glTranslatef(charTranslateX, charTranslatey, 0.0f);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(0.1,-0.4f);
    glVertex2f(0.22f,-0.4f);
    glVertex2f(0.22f,-0.54f);
    glVertex2f(0.1f,-0.54f);
    glEnd();
    glPopMatrix();
}*/
