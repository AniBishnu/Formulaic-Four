#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

GLfloat mapTranslateX = 0.0;
GLfloat charTranslateX = 0.0;
GLfloat charTranslatey = 0.0;

std::string Initial_Display="";

GLboolean jumping = false;
GLboolean jumped = false;



GLfloat Load_Scale;

void renderBitmapString(float x, float y, float z, void *font, char *string)
{
    char *c;
    glRasterPos3f(x, y,z);
    for (c=string; *c != '\0'; c++)
    {
        glutBitmapCharacter(font, *c);
    }
}


void housebrickR1(float x,float y)
{
    ///1st
    glBegin(GL_POLYGON);
    glColor3ub(189,106,108);
    glVertex2f(-0.99f,(0.83f-y));
    glVertex2f(-0.93f,(0.83f-y));
    glVertex2f(-0.93f,(0.75f-y));
    glVertex2f(-0.99f,(0.75f-y));
    glEnd();
    ///2
    glBegin(GL_POLYGON);
    glColor3ub(189,106,108);
    glVertex2f(-0.92f,(0.83f-y));
    glVertex2f(-0.82f,(0.83f-y));
    glVertex2f(-0.82f,(0.75f-y));
    glVertex2f(-0.92f,(0.75f-y));
    glEnd();

    ///3
    glBegin(GL_POLYGON);
    glColor3ub(189,106,108);
    glVertex2f(-0.81f,(0.83f-y));
    glVertex2f(-0.7f,(0.83f-y));
    glVertex2f(-0.7f,(0.75f-y));
    glVertex2f(-0.81f,(0.75f-y));
    glEnd();

    ///4
    glBegin(GL_POLYGON);
    glColor3ub(189,106,108);
    glVertex2f(-0.69f,(0.83f-y));
    glVertex2f(-0.59f,(0.83f-y));
    glVertex2f(-0.59f,(0.75f-y));
    glVertex2f(-0.69f,(0.75f-y));
    glEnd();

    ///5
    glBegin(GL_POLYGON);
    glColor3ub(189,106,108);
    glVertex2f(-0.58f,(0.83f-y));
    glVertex2f(-0.53f,(0.83f-y));
    glVertex2f(-0.53f,(0.75f-y));
    glVertex2f(-0.58f,(0.75f-y));
    glEnd();
}

void housebrickR2(float x,float y)
{
     ///14
    glBegin(GL_POLYGON);
    glColor3ub(228,150,152);
    glVertex2f(-0.99f,(0.53f-y));
    glVertex2f(-0.88f,(0.53f-y));
    glVertex2f(-0.88f,(0.46f-y));
    glVertex2f(-0.99f,(0.46f-y));
    glEnd();


     ///15
    glBegin(GL_POLYGON);
    glColor3ub(228,150,152);
    glVertex2f(-0.87f,(0.53f-y));
    glVertex2f(-0.76f,(0.53f-y));
    glVertex2f(-0.76f,(0.46f-y));
    glVertex2f(-0.87f,(0.46f-y));
    glEnd();

    ///16
    glBegin(GL_POLYGON);
    glColor3ub(228,150,152);
    glVertex2f(-0.75f,(0.53f-y));
    glVertex2f(-0.65f,(0.53f-y));
    glVertex2f(-0.65f,(0.46f-y));
    glVertex2f(-0.75f,(0.46f-y));
    glEnd();

      ///17
    glBegin(GL_QUADS);
    glColor3ub(228,150,152);
    glVertex2f(-0.64f,(0.53f-y));
    glVertex2f(-0.53f,(0.53f-y));
    glVertex2f(-0.53f,(0.46f-y));
    glVertex2f(-0.64f,(0.46f-y));
    glEnd();
}

void square1(float x,float y)
{
    glBegin(GL_QUADS);
    glColor3ub(77,41,43);
    glVertex2f((-0.63f-x),(0.34f-y));
    glVertex2f((-0.57f-x),(0.34f-y));
    glVertex2f((-0.57f-x),(0.26f-y));
    glVertex2f((-0.63f-x),(0.26f-y));
    glEnd();
}


void square2(float x,float y)
{
    glBegin(GL_QUADS);
    glColor3ub(77,41,43);
    glVertex2f((-0.63f-x),(0.23f-y));
    glVertex2f((-0.57f-x),(0.23f-y));
    glVertex2f((-0.57f-x),(0.04f-y));
    glVertex2f((-0.63f-x),(0.04f-y));
    glEnd();
}


void menuboard(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(98,72,55);
    glVertex2f(x+(-0.98f),y+(0.96f));
    glVertex2f(x+(-0.73f),y+(0.96f));
    glVertex2f(x+(-0.73f),y+(0.8f));
    glVertex2f(x+(-0.98f),y+(0.8f));
    glEnd();

    glLineWidth(9);
    glBegin(GL_LINES);
    glColor3ub(50,33,25);
    glVertex2f(x+(-0.98f),y+(0.95f));
    glVertex2f(x+(-0.73f),y+(0.95f));
    glVertex2f(x+(-0.73f),y+(0.8f));
    glVertex2f(x+(-0.98f),y+(0.8f));
    glEnd();


    glLineWidth(0.1);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.97f),y+(0.94f));
    glVertex2f(x+(-0.76f),y+(0.94f));

    glVertex2f(x+(-0.73f),y+(0.92f));
    glVertex2f(x+(-0.94f),y+(0.92f));

    glVertex2f(x+(-0.91f),y+(0.9f));
    glVertex2f(x+(-0.74f),y+(0.9f));

    glVertex2f(x+(-0.96f),y+(0.87f));
    glVertex2f(x+(-0.77f),y+(0.87f));

    glVertex2f(x+(-0.93f),y+(0.85f));
    glVertex2f(x+(-0.74f),y+(0.85f));

    glVertex2f(x+(-0.95f),y+(0.82f));
    glVertex2f(x+(-0.81f),y+(0.82f));
    glEnd();


}
void pointboard(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(98,72,55);
    glVertex2f(x+(-0.24f),y+(0.97f));
    glVertex2f(x+(0.24f),y+(0.97f));
    glVertex2f(x+(0.24f),y+(0.84f));
    glVertex2f(x+(-0.24f),y+(0.84f));
    glEnd();

    glLineWidth(9);
    glBegin(GL_LINES);
    glColor3ub(50,33,25);
    glVertex2f(x+(-0.24f),y+(0.96f));
    glVertex2f(x+(0.24f),y+(0.96f));
    glVertex2f(x+(0.24f),y+(0.84f));
    glVertex2f(x+(-0.24f),y+(0.84f));
    glEnd();

    glLineWidth(0.1);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.22f),y+(0.94f));
    glVertex2f(x+(0.21f),y+(0.94f));

    glVertex2f(x+(0.23f),y+(0.92f));
    glVertex2f(x+(-0.13f),y+(0.92f));

    glVertex2f(x+(-0.19f),y+(0.9f));
    glVertex2f(x+(0.19f),y+(0.9f));

    glVertex2f(x+(-0.21f),y+(0.87f));
    glVertex2f(x+(0.16f),y+(0.87f));

    glVertex2f(x+(0.225f),y+(0.85f));
    glVertex2f(x+(-0.14f),y+(0.85f));

    glVertex2f(x+(-0.0f),y+(0.8455f));
    glVertex2f(x+(0.2f),y+(0.8455f));
    glEnd();


}


void point_table()
{
    kath(0.59,1.54);
    kath(1.16,1.54);
    pointboard(0,-0.015);
    menuboard(0,0);





    glColor3f(1.0,1.0,1.0);
    renderBitmapString(-0.91f, 0.85f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "<Menu");
    renderBitmapString(-0.15f, 0.87f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Points Collected:");

}
