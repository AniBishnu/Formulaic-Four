#ifndef MAP3_H_INCLUDED
#define MAP3_H_INCLUDED

void obst1(float x,float y);
void brickR1(float x,float y);
void brickR2(float x,float y);
void brickR3(float x, float y);
void levelDevide(float x,float y);
void backbox_Upper();
void levelDevideUp(float x,float y);
void pathway();
void character();

void piller_M3(float x,float y);
void box_M3(float x,float y);
void cross(float x, float y);
void X_Box_M3(float x,float y);
void X_sign_M3(float x, float y);
void bridge_M3(float x,float y);
void bridgepiller(float x, float y);

void display_Map3_Start();
void display_Map3_Screen1(float x,float y);
void display_Map3_Screen2();
void display_Map3_Screen3();


class door
{
public:

    void Door2back(float x,float y)
{
    ///back side part
    glBegin(GL_POLYGON);
    glColor3ub(60,66,88);
    glVertex2f((x+(-0.62f)),(y+(0.47f)));
    glVertex2f((x+(-0.60f)),0.43f);
    glVertex2f((x+(-0.60f)),-0.01f);
    glVertex2f((x+(-0.62f)),-0.05f);
    glEnd();

    ///back side part border
    glLineWidth(3);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.62f)),0.47f);
    glVertex2f((x+(-0.60f)),0.43f);
    glVertex2f((x+(-0.60f)),-0.01f);
    glVertex2f((x+(-0.62f)),-0.05f);
    glEnd();


    ///background 1
    glBegin(GL_POLYGON);
    glColor3ub(60,66,88);
    glVertex2f((x+(-1.0f)),0.9f);
    glVertex2f((x+(-0.62f)),0.9f);
    glVertex2f((x+(-0.62f)),-0.48f);
    glVertex2f((x+(-1.0f)),-0.48f);
    glEnd();

    ///background 1 border 2 white
    glLineWidth(6);
    glBegin(GL_LINE_LOOP);
    glColor4ub(255,255,255,80);
    glVertex2f((x+(-1.0f)),0.89f);
    glVertex2f((x+(-0.625f)),0.89f);
    glVertex2f((x+(-0.625f)),-0.47f);
    glVertex2f((x+(-1.0f)),-0.47f);
    glEnd();

    ///background 2 p1
    glBegin(GL_POLYGON);
    glColor3ub(236,39,66);
    glVertex2f((x+(-0.74f)),0.07f);
    glVertex2f((x+(-0.69f)),0.0f);
    glVertex2f((x+(-0.69f)),-0.34f);
    glVertex2f((x+(-1.0f)),-0.34f);
    glVertex2f((x+(-1.0f)),0.07f);
    glEnd();

    ///background 2 p2
    glBegin(GL_POLYGON);
    glColor3ub(236,39,66);
    glVertex2f((x+(-0.74f)),0.35f);
    glVertex2f((x+(-1.0f)),-0.35f);
    glVertex2f((x+(-1.0f)),0.74f);
    glVertex2f((x+(-0.69f)),0.74f);
    glVertex2f((x+(-0.69f)),0.42f);
    glEnd();

    ///background 2 p3
    glBegin(GL_POLYGON);
    glColor3ub(236,39,66);
    glVertex2f((x+(-0.74f)),0.37f);
    glVertex2f((x+(-0.74f)),0.05f);
    glVertex2f((x+(-1.0f)),0.05f);
    glVertex2f((x+(-1.0f)),0.37f);
    glEnd();

    ///background 2 border
    glBegin(GL_LINE_LOOP);
    glColor3ub(252,128,159);
    glVertex2f((x+(-0.74f)),0.07f);
    glVertex2f((x+(-0.69f)),0.0f);
    glVertex2f((x+(-0.69f)),-0.34f);
    glVertex2f((x+(-1.0f)),-0.34f);
    glVertex2f((x+(-1.0f)),0.74f);
    glVertex2f((x+(-0.69f)),0.74f);
    glVertex2f((x+(-0.69f)),0.42f);
    glVertex2f((x+(-0.74f)),0.35f);
    glEnd();

    ///background 1 border
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f((x+(-1.0f)),0.9f);
    glVertex2f((x+(-0.62f)),0.9f);
    glVertex2f((x+(-0.62f)),-0.48f);
    glVertex2f((x+(-1.0f)),-0.48f);
    glEnd();

    ///triangle
    glLineWidth(5);
    glBegin(GL_LINE_LOOP);
    glColor4ub(0,0,0,70);
    glVertex2f((x+(-0.69f)),0.15f);
    glVertex2f((x+(-0.62f)),-0.02f);
    glVertex2f((x+(-0.62f)),0.41f);
    glVertex2f((x+(-0.69f)),0.25f);
    glEnd();

}

void door2Right(float x,float y)
{
    ///top right 1
    glBegin(GL_POLYGON);
    glColor3ub(69,80,100);
    glVertex2f((x+(-0.76f)),0.96f);
    glVertex2f((x+(-0.61f)),0.96f);
    glVertex2f((x+(-0.59f)),0.91f);
    glVertex2f((x+(-0.59f)),0.52f);
    glVertex2f((x+(-0.64f)),0.52f);
    glVertex2f((x+(-0.76f)),0.78f);
    glEnd();


    ///top right inbox
    glBegin(GL_POLYGON);
    glColor3ub(91,100,131);
    glVertex2f((x+(-0.73f)),0.9f);
    glVertex2f((x+(-0.64f)),0.9f);
    glVertex2f((x+(-0.62f)),0.85f);
    glVertex2f((x+(-0.62f)),0.59f);
    glVertex2f((x+(-0.73f)),0.82f);
    glEnd();

    ///top right inbox white border
    glLineWidth(2);
    glBegin(GL_LINES);
    glColor4ub(255,255,255,75);
    glVertex2f((x+(-0.73f)),0.9f);
    glVertex2f((x+(-0.73f)),0.82f);

    glVertex2f((x+(-0.73f)),0.82f);
    glVertex2f((x+(-0.62f)),0.59f);
    glEnd();

    ///top right inbox black border
     glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(0,0,0,100);
    glVertex2f((x+(-0.73f)),0.9f);
    glVertex2f((x+(-0.64f)),0.9f);

    glVertex2f((x+(-0.64f)),0.9f);
    glVertex2f((x+(-0.62f)),0.85f);

    glVertex2f((x+(-0.62f)),0.85f);
    glVertex2f((x+(-0.62f)),0.59f);
    glEnd();

    ///top right 1 border
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.76f)),0.96f);
    glVertex2f((x+(-0.61f)),0.96f);
    glVertex2f((x+(-0.59f)),0.91f);
    glVertex2f((x+(-0.59f)),0.52f);
    glVertex2f((x+(-0.64f)),0.52f);
    glVertex2f((x+(-0.76f)),0.78f);
    glEnd();

    ///top right nut
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.74f)),0.91f);
    glVertex2f((x+(-0.61f)),0.91f);
    glVertex2f((x+(-0.61f)),0.55f);
    glVertex2f((x+(-0.64f)),0.55f);
    glVertex2f((x+(-0.74f)),0.79f);
    glEnd();

    ///bottom right 1
    glBegin(GL_POLYGON);
    glColor3ub(69,80,100);
    glVertex2f((x+(-0.76f)),-0.54f);
    glVertex2f((x+(-0.61f)),-0.54f);
    glVertex2f((x+(-0.59f)),-0.49f);
    glVertex2f((x+(-0.59f)),-0.10f);
    glVertex2f((x+(-0.64f)),-0.10f);
    glVertex2f((x+(-0.76f)),-0.36f);
    glEnd();


    ///bottom right inbox
    glBegin(GL_POLYGON);
    glColor3ub(91,100,131);
    glVertex2f((x+(-0.73f)),-0.49f);
    glVertex2f((x+(-0.64f)),-0.49f);
    glVertex2f((x+(-0.62f)),-0.44f);
    glVertex2f((x+(-0.62f)),-0.18f);
    glVertex2f((x+(-0.73f)),-0.41f);
    glEnd();

    ///bottom right inbox border
    glLineWidth(2);
    glBegin(GL_LINES);
    glColor4ub(255,255,255,75);
    glVertex2f((x+(-0.73f)),-0.49f);
    glVertex2f((x+(-0.73f)),-0.41f);

    glVertex2f((x+(-0.73f)),-0.41f);
    glVertex2f((x+(-0.62f)),-0.18f);
    glEnd();


    ///bottom right inbox black border
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(0,0,0,100);
    glVertex2f((x+(-0.73f)),- 0.49f);
    glVertex2f((x+(-0.64f)),-0.49f);

    glVertex2f((x+(-0.64f)),-0.49f);
    glVertex2f((x+(-0.62f)),-0.45f);

    glVertex2f((x+(-0.62f)),-0.45f);
    glVertex2f((x+(-0.62f)),-0.18f);
    glEnd();

    ///bottom right 1 border
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.76f)),-0.54f);
    glVertex2f((x+(-0.61f)),-0.54f);
    glVertex2f((x+(-0.59f)),-0.49f);
    glVertex2f((x+(-0.59f)),-0.10f);
    glVertex2f((x+(-0.64f)),-0.10f);
    glVertex2f((x+(-0.76f)),-0.36f);
    glEnd();

    ///top right nut
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.74f)),-0.51f);
    glVertex2f((x+(-0.61f)),-0.51f);
    glVertex2f((x+(-0.61f)),-0.15f);
    glVertex2f((x+(-0.64f)),-0.15f);
    glVertex2f((x+(-0.74f)),-0.39f);
    glEnd();
}
void doorNUT(float x,float y)
{
    ///Top left 1
    glBegin(GL_POLYGON);
    glColor3ub(69,80,100);
    glVertex2f((x+(-0.94f)),0.87f);
    glVertex2f((x+(-0.94f)),0.82f);
    glVertex2f((x+(-0.92f)),0.78f);
    glVertex2f((x+(-0.89f)),0.78f);
    glVertex2f((x+(-0.89f)),0.87f);
    glVertex2f((x+(-0.85f)),0.87f);
    glVertex2f((x+(-0.85f)),0.91f);
    glVertex2f((x+(-0.87f)),0.96f);
    glVertex2f((x+(-1.0f)),0.96f);
    glVertex2f((x+(-1.0f)),0.87f);
    glEnd();

    ///Top left 1 Line shade black
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.86f)),0.9f);
    glVertex2f((x+(-0.86f)),0.87f);
    glVertex2f((x+(-0.85f)),0.87f);
    glVertex2f((x+(-0.85f)),0.9f);
    glEnd();
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.87f)),0.92f);
    glVertex2f((x+(-0.86f)),0.9f);
    glVertex2f((x+(-0.85f)),0.9f);
    glVertex2f((x+(-0.87f)),0.96f);
    glVertex2f((x+(-1.0f)),0.96f);
    glVertex2f((x+(-1.0f)),0.92f);
    glEnd();

    ///Top left 1 Line shade white
    glLineWidth(2);
    glBegin(GL_LINES);
    glColor4ub(255,255,255,75);
    glVertex2f((x+(-1.0f)),0.875f);
    glVertex2f((x+(-0.94f)),0.875f);

    glVertex2f((x+(-0.94f)),0.875f);
    glVertex2f((x+(-0.94f)),0.825f);

    glVertex2f((x+(-0.94f)),0.825f);
    glVertex2f((x+(-0.92f)),0.785f);

    glVertex2f((x+(-0.92f)),0.785f);
    glVertex2f((x+(-0.89f)),0.785f);

    glVertex2f((x+(-0.89f)),0.785f);
    glVertex2f((x+(-0.89f)),0.875f);

    glVertex2f((x+(-0.89f)),0.875f);
    glVertex2f((x+(-0.85f)),0.875f);
    glEnd();

    ///top left nut
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.915f)),0.84f);
    glEnd();

    ///Top left 1 border
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.94f)),0.87f);
    glVertex2f((x+(-0.94f)),0.82f);
    glVertex2f((x+(-0.92f)),0.78f);
    glVertex2f((x+(-0.89f)),0.78f);
    glVertex2f((x+(-0.89f)),0.87f);
    glVertex2f((x+(-0.85f)),0.87f);
    glVertex2f((x+(-0.85f)),0.91f);
    glVertex2f((x+(-0.87f)),0.96f);
    glVertex2f((x+(-1.0f)),0.96f);
    glVertex2f((x+(-1.0f)),0.87f);
    glEnd();

    ///bottom left 1
    glBegin(GL_POLYGON);
    glColor3ub(69,80,100);
    glVertex2f((x+(-0.94f)),-0.45f);
    glVertex2f((x+(-0.94f)),-0.40f);
    glVertex2f((x+(-0.92f)),-0.36f);
    glVertex2f((x+(-0.89f)),-0.36f);
    glVertex2f((x+(-0.89f)),-0.45f);
    glVertex2f((x+(-0.85f)),-0.45f);
    glVertex2f((x+(-0.85f)),-0.49f);
    glVertex2f((x+(-0.87f)),-0.54f);
    glVertex2f((x+(-1.0f)),-0.54f);
    glVertex2f((x+(-1.0f)),-0.45f);
    glEnd();

    ///Top left 1 Line shade black
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.86f)),-0.49f);
    glVertex2f((x+(-0.86f)),-0.45f);
    glVertex2f((x+(-0.85f)),-0.45f);
    glVertex2f((x+(-0.85f)),-0.49f);
    glEnd();
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.87f)),-0.51f);
    glVertex2f((x+(-0.86f)),-0.49f);
    glVertex2f((x+(-0.85f)),-0.49f);
    glVertex2f((x+(-0.87f)),-0.54f);
    glVertex2f((x+(-1.0f)),-0.54f);
    glVertex2f((x+(-1.0f)),-0.51f);
    glEnd();

    ///top left nut
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.915f)),-0.42f);
    glEnd();

    ///bottom left 1 border
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.94f)),-0.45f);
    glVertex2f((x+(-0.94f)),-0.40f);
    glVertex2f((x+(-0.92f)),-0.36f);
    glVertex2f((x+(-0.89f)),-0.36f);
    glVertex2f((x+(-0.89f)),-0.45f);
    glVertex2f((x+(-0.85f)),-0.45f);
    glVertex2f((x+(-0.85f)),-0.49f);
    glVertex2f((x+(-0.87f)),-0.54f);
    glVertex2f((x+(-1.0f)),-0.54f);
    glVertex2f((x+(-1.0f)),-0.45f);
    glEnd();
}
void Door1(float x,float y)
{
    Door2back(0.05,0.00);
    door2Right(0.05,0.00);

    /// Top door Line shadow
    glLineWidth(30);
    glBegin(GL_LINES);
    glColor4ub(0,0,0,100);
    glVertex2f((x+(-0.84f)),0.9f);
    glVertex2f((x+(-0.84f)),0.74f);

    glVertex2f((x+(-0.84f)),0.74f);
    glVertex2f((x+(-0.73f)),0.48f);

    glVertex2f((x+(-0.73f)),0.48f);
    glVertex2f((x+(-0.73f)),-0.08f);

    glVertex2f((x+(-0.73f)),-0.08f);
    glVertex2f((x+(-0.84f)),-0.34f);

    glVertex2f((x+(-0.84f)),-0.34f);
    glVertex2f((x+(-0.84f)),-0.49f);
    glEnd();

    ///Top door
    glBegin(GL_POLYGON);
    glColor3ub(64,75,98);
    glVertex2f((x+(-1.0f)),0.9f);
    glVertex2f((x+(-0.84f)),0.9f);
    glVertex2f((x+(-0.84f)),0.74f);
    glVertex2f((x+(-0.73f)),0.48f);
    glVertex2f((x+(-0.73f)),-0.08f);
    glVertex2f((x+(-0.84f)),-0.34f);
    glVertex2f((x+(-0.84f)),-0.49f);
    glVertex2f((x+(-1.0f)),-0.49f);
    glEnd();

    /// Top door Line
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f((x+(-1.0f)),0.9f);
    glVertex2f((x+(-0.84f)),0.9f);
    glVertex2f((x+(-0.84f)),0.74f);
    glVertex2f((x+(-0.73f)),0.48f);
    glVertex2f((x+(-0.73f)),-0.08f);
    glVertex2f((x+(-0.84f)),-0.34f);
    glVertex2f((x+(-0.84f)),-0.49f);
    glVertex2f((x+(-1.0f)),-0.49f);
    glEnd();

    /// Top door inside 1
    glBegin(GL_POLYGON);
    glColor3ub(91,100,131);
    glVertex2f((x+(-0.87f)),-0.34f);
    glVertex2f((x+(-0.87f)),-0.49f);
    glVertex2f((x+(-1.0f)),-0.49f);
    glVertex2f((x+(-1.0f)),0.9f);
    glVertex2f((x+(-0.87f)),0.9f);
    glVertex2f((x+(-0.87f)),0.73f);
    glVertex2f((x+(-0.76f)),0.49f);
    glVertex2f((x+(-0.76f)),-0.08f);
    glEnd();

    /// Top door inside 1 border
    glLineWidth(2);
    glBegin(GL_LINE_LOOP);
    glColor4ub(255,255,255,100);
    glVertex2f((x+(-0.87f)),-0.34f);
    glVertex2f((x+(-0.87f)),-0.49f);
    glVertex2f((x+(-1.0f)),-0.49f);
    glVertex2f((x+(-1.0f)),0.9f);
    glVertex2f((x+(-0.87f)),0.9f);
    glVertex2f((x+(-0.87f)),0.73f);
    glVertex2f((x+(-0.76f)),0.49f);
    glVertex2f((x+(-0.76f)),-0.08f);
    glEnd();

    /// Top door inside 2 p1
    glBegin(GL_POLYGON);
    glColor3ub(60,66,88);
    glVertex2f((x+(-0.92f)),-0.13f);
    glVertex2f((x+(-0.92f)),-0.49f);
    glVertex2f((x+(-1.00f)),-0.49f);
    glVertex2f((x+(-1.00f)),0.9f);
    glVertex2f((x+(-0.92f)),0.9f);
    glVertex2f((x+(-0.92f)),0.54f);
    glVertex2f((x+(-0.85f)),0.38f);
    glVertex2f((x+(-0.85f)),0.03f);
    glEnd();

    /// Top door inside 2 border p1
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.92f)),-0.13f);
    glVertex2f((x+(-0.92f)),-0.49f);
    glVertex2f((x+(-1.00f)),-0.49f);
    glVertex2f((x+(-1.00f)),0.9f);
    glVertex2f((x+(-0.92f)),0.9f);
    glVertex2f((x+(-0.92f)),0.54f);
    glVertex2f((x+(-0.85f)),0.38f);
    glVertex2f((x+(-0.85f)),0.03f);
    glEnd();

    /// Top door inside 2 p2
    glBegin(GL_POLYGON);
    glColor3ub(60,66,88);
    glVertex2f((x+(-0.87f)),0.38f);
    glVertex2f((x+(-0.81f)),0.38f);
    glVertex2f((x+(-0.81f)),0.03f);
    glVertex2f((x+(-0.87f)),0.03f);
    glEnd();


    /// Top door inside 2 border p2
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.85f)),0.38f);
    glVertex2f((x+(-0.81f)),0.38f);

    glVertex2f((x+(-0.81f)),0.38f);
    glVertex2f((x+(-0.81f)),0.03f);

    glVertex2f((x+(-0.81f)),0.03f);
    glVertex2f((x+(-0.85f)),0.03f);
    glEnd();


    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.85f)),0.38f);
    glVertex2f((x+(-0.81f)),0.38f);
    glVertex2f((x+(-0.81f)),0.03f);
    glVertex2f((x+(-0.85f)),0.03f);
    glEnd();

    /// Top door inside 3
    glBegin(GL_POLYGON);
    glColor3ub(80,90,115);
    glVertex2f(x+(-1.0f),0.38f);
    glVertex2f(x+(-1.0f),0.03f);
    glVertex2f(x+(-0.95f),0.03f);
    glVertex2f(x+(-0.89f),0.17f);
    glVertex2f(x+(-0.89f),0.23f);
    glVertex2f(x+(-0.95f),0.38f);
    glEnd();

    /// Top door inside 3 outside border
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor4ub(0,0,0,60);
    glVertex2f(x+(-1.1f),0.43f);
    glVertex2f(x+(-1.1f),-0.02f);
    glVertex2f(x+(-0.94f),-0.02f);
    glVertex2f(x+(-0.86f),0.15f);
    glVertex2f(x+(-0.86f),0.26f);
    glVertex2f(x+(-0.93f),0.43f);
    glEnd();

    /// Top door inside 4
    glBegin(GL_POLYGON);
    glColor3ub(91,100,131);
    glVertex2f(x+(-1.0f),0.32f);
    glVertex2f(x+(-1.0f),0.09f);
    glVertex2f(x+(-0.97f),0.09f);
    glVertex2f(x+(-0.929f),0.21f);
    glVertex2f(x+(-0.97f),0.32f);
    glEnd();

    /// Top door inside 4 border
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor4ub(255,255,255,60);
    glVertex2f(x+(-1.0f),0.32f);
    glVertex2f(x+(-1.0f),0.09f);
    glVertex2f(x+(-0.97f),0.09f);
    glVertex2f(x+(-0.929f),0.21f);
    glVertex2f(x+(-0.97f),0.32f);
    glEnd();

    /// Top door inside 3 border
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-1.0f),0.38f);
    glVertex2f(x+(-1.0f),0.03f);
    glVertex2f(x+(-0.95f),0.03f);
    glVertex2f(x+(-0.89f),0.17f);
    glVertex2f(x+(-0.89f),0.23f);
    glVertex2f(x+(-0.95f),0.38f);
    glEnd();

    /// Top door inside 5 sided
    glBegin(GL_POLYGON);
    glColor3ub(236,39,66);
    glVertex2f(x+(-1.0f),0.65f);
    glVertex2f(x+(-0.99f),0.63f);
    glVertex2f(x+(-0.99f),0.38f);
    glVertex2f(x+(-1.0f),0.36f);
    glEnd();

    /// Top door inside 5 sided border
    glLineWidth(4);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-1.0f),0.65f);
    glVertex2f(x+(-0.99f),0.63f);
    glVertex2f(x+(-0.99f),0.38f);
    glVertex2f(x+(-1.0f),0.36f);
    glEnd();

    /// Top door inside 5 sided
    glBegin(GL_POLYGON);
    glColor3ub(236,39,66);
    glVertex2f(x+(-1.0f),-0.24f);
    glVertex2f(x+(-0.99f),-0.22f);
    glVertex2f(x+(-0.99f),0.03f);
    glVertex2f(x+(-1.0f),0.05f);
    glEnd();

    /// Top door inside 5 sided border
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-1.0f),-0.24f);
    glVertex2f(x+(-0.99f),-0.22f);
    glVertex2f(x+(-0.99f),0.03f);
    glVertex2f(x+(-1.0f),0.05f);
    glEnd();

    doorNUT(0.00,0.00);

}
};

#endif // MAP3_H_INCLUDED
