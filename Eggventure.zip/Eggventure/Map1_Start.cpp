#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"
#include "vector"

///std::vector<obstacle1> Obstacles;
Character c1;
const int numObstacles = 6;

obstacle1 Obstacles[numObstacles] = {
    obstacle1(0.0f, 0.0f),
    obstacle1(0.20f, 0.0f),
    obstacle1(0.40f, 0.0f),
    obstacle1(0.10f, 0.10f),
    obstacle1(0.30f, 0.10f),
    obstacle1(0.20f, 0.20f)
};

void upperBrick(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3f(0.447f,0.306f,0.290f);
    glVertex2f(x+(0.30f),y+(-0.54f));
    glVertex2f(x+(0.50f),y+(-0.54f));
    glVertex2f(x+(0.50f),y+(-0.44f));
    glVertex2f(x+(0.30f),y+(-0.44f));
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(0.30f),y+(-0.54f));
    glVertex2f(x+(0.50f),y+(-0.54f));
    glVertex2f(x+(0.50f),y+(-0.44f));
    glVertex2f(x+(0.30f),y+(-0.44f));
    glEnd();
}

void display_Map1_Start()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Set background color to black and opaque
    glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer (background)

    ///background
    glBegin(GL_POLYGON);
    glColor3ub(158,236,255);
    glVertex2f(1.0f,1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glVertex2f(-1.0f,1.0f);
    glEnd();



    glPushMatrix();
    glTranslatef(mapTranslateX, 0.0f, 0.0f);

    grass(0.05,-0.34);
    grass(-0.19,-0.34);

    ///wall

    glBegin(GL_POLYGON);
    glColor3f(0.447f,0.306f,0.290f);
    glVertex2f(-1.0f,-0.54f);
    glVertex2f(1.0f,-0.54f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(-1.0f,-0.67f);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(161,150,146);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(-1.0f,-0.56f);
    glVertex2f(1.0f,-0.56f);
    glEnd();

     /// Bricks
    ///1
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.7f);
    glVertex2f(-0.89f,-0.7f);
    glVertex2f(-0.89f,-0.78f);
    glVertex2f(-0.99f,-0.78f);
    glEnd();
    ///2
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.99f,-0.8f);
    glVertex2f(-0.89f,-0.8f);
    glVertex2f(-0.89f,-0.88f);
    glVertex2f(-0.99f,-0.88f);
    glEnd();

    ///3
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.9f);
    glVertex2f(-0.87f,-0.9f);
    glVertex2f(-0.87f,-1.0f);
    glVertex2f(-0.99f,-1.0f);
    glEnd();

    ///4
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.88f,-0.7f);
    glVertex2f(-0.82f,-0.7f);
    glVertex2f(-0.82f,-0.78f);
    glVertex2f(-0.88f,-0.78f);
    glEnd();

    ///5
    glBegin(GL_POLYGON);
     glColor3ub(117,51,16);
    glVertex2f(-0.81f,-0.7f);
    glVertex2f(-0.77f,-0.7f);
    glVertex2f(-0.77f,-0.78f);
    glVertex2f(-0.81f,-0.78f);
    glEnd();

  ///6
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(-0.76f,-0.7f);
    glVertex2f(-0.67f,-0.7f);
    glVertex2f(-0.67f,-0.78f);
    glVertex2f(-0.76f,-0.78f);
    glEnd();

    ///7
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(-0.66f,-0.7f);
    glVertex2f(-0.53f,-0.7f);
    glVertex2f(-0.53f,-0.78f);
    glVertex2f(-0.66f,-0.78f);
    glEnd();
    ///8
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.52f,-0.7f);
    glVertex2f(-0.45f,-0.7f);
    glVertex2f(-0.45f,-0.78f);
    glVertex2f(-0.52f,-0.78f);
    glEnd();

       ///9
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.44f,-0.7f);
    glVertex2f(-0.37f,-0.7f);
    glVertex2f(-0.37f,-0.78f);
    glVertex2f(-0.44f,-0.78f);
    glEnd();


       ///10
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(-0.36f,-0.7f);
    glVertex2f(-0.3f,-0.7f);
    glVertex2f(-0.3f,-0.78f);
    glVertex2f(-0.36f,-0.78f);
    glEnd();

        ///11
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.29f,-0.7f);
    glVertex2f(-0.17f,-0.7f);
    glVertex2f(-0.17f,-0.78f);
    glVertex2f(-0.29f,-0.78f);
    glEnd();

     ///12
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.16f,-0.7f);
    glVertex2f(-0.05f,-0.7f);
    glVertex2f(-0.05f,-0.78f);
    glVertex2f(-0.16f,-0.78f);
    glEnd();

         ///13
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.04f,-0.7f);
    glVertex2f(0.03f,-0.7f);
    glVertex2f(0.03f,-0.78f);
    glVertex2f(-0.04f,-0.78f);
    glEnd();

     ///14
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.04f,-0.7f);
    glVertex2f(0.19f,-0.7f);
    glVertex2f(0.19f,-0.78f);
    glVertex2f(0.04f,-0.78f);
    glEnd();


     ///15
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.20f,-0.7f);
    glVertex2f(0.23f,-0.7f);
    glVertex2f(0.23f,-0.78f);
    glVertex2f(0.20f,-0.78f);
    glEnd();

    ///16
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.24f,-0.7f);
    glVertex2f(0.39f,-0.7f);
    glVertex2f(0.39f,-0.78f);
    glVertex2f(0.24f,-0.78f);
    glEnd();

      ///17
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.4f,-0.7f);
    glVertex2f(0.51f,-0.7f);
    glVertex2f(0.51f,-0.78f);
    glVertex2f(0.4f,-0.78f);
    glEnd();

          ///18
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.52f,-0.7f);
    glVertex2f(0.59f,-0.7f);
    glVertex2f(0.59f,-0.78f);
    glVertex2f(0.52f,-0.78f);
    glEnd();

          ///19
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.6f,-0.7f);
    glVertex2f(0.64f,-0.7f);
    glVertex2f(0.64f,-0.78f);
    glVertex2f(0.6f,-0.78f);
    glEnd();


          ///20
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.65f,-0.7f);
    glVertex2f(0.74f,-0.7f);
    glVertex2f(0.74f,-0.78f);
    glVertex2f(0.65f,-0.78f);
    glEnd();

             ///21
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.75f,-0.7f);
    glVertex2f(0.8f,-0.7f);
    glVertex2f(0.8f,-0.78f);
    glVertex2f(0.75f,-0.78f);
    glEnd();

           ///22
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.81f,-0.7f);
    glVertex2f(0.88f,-0.7f);
    glVertex2f(0.88f,-0.78f);
    glVertex2f(0.81f,-0.78f);
    glEnd();

              ///23
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.89f,-0.7f);
    glVertex2f(1.0f,-0.7f);
    glVertex2f(1.0f,-0.78f);
    glVertex2f(0.89f,-0.78f);
    glEnd();



///24
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.88f,-0.8f);
    glVertex2f(-0.78f,-0.8f);
    glVertex2f(-0.78f,-0.88f);
    glVertex2f(-0.88f,-0.88f);
    glEnd();

    ///25
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(-0.77f,-0.8f);
    glVertex2f(-0.66f,-0.8f);
    glVertex2f(-0.66f,-0.88f);
    glVertex2f(-0.77f,-0.88f);
    glEnd();

      ///26
    glBegin(GL_POLYGON);
    glColor3ub(123,81,57);
    glVertex2f(-0.65f,-0.8f);
    glVertex2f(-0.54f,-0.8f);
    glVertex2f(-0.54f,-0.88f);
    glVertex2f(-0.65f,-0.88f);
    glEnd();

      ///27
    glBegin(GL_POLYGON);
    glColor3ub(234,186,138);
    glVertex2f(-0.53f,-0.8f);
    glVertex2f(-0.44f,-0.8f);
    glVertex2f(-0.44f,-0.88f);
    glVertex2f(-0.53f,-0.88f);
    glEnd();

      ///28
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.43f,-0.8f);
    glVertex2f(-0.3f,-0.8f);
    glVertex2f(-0.3f,-0.88f);
    glVertex2f(-0.43f,-0.88f);
    glEnd();
    ///29
    glBegin(GL_POLYGON);
    glColor3ub(123,81,57);
    glVertex2f(-0.29f,-0.8f);
    glVertex2f(-0.15f,-0.8f);
    glVertex2f(-0.15f,-0.88f);
    glVertex2f(-0.29f,-0.88f);
    glEnd();

 ///30
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.14f,-0.8f);
    glVertex2f(-0.09f,-0.8f);
    glVertex2f(-0.09f,-0.88f);
    glVertex2f(-0.14f,-0.88f);
    glEnd();

     ///31
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.08f,-0.8f);
    glVertex2f(0.0,-0.8f);
    glVertex2f(0,-0.88f);
    glVertex2f(-0.08f,-0.88f);
    glEnd();

       ///32
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.01f,-0.8f);
    glVertex2f(0.15f,-0.8f);
    glVertex2f(0.15f,-0.88f);
    glVertex2f(0.01f,-0.88f);
    glEnd();

         ///33
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.16f,-0.8f);
    glVertex2f(0.28f,-0.8f);
    glVertex2f(0.28f,-0.88f);
    glVertex2f(0.16f,-0.88f);
    glEnd();

         ///34
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.29f,-0.8f);
    glVertex2f(0.38f,-0.8f);
    glVertex2f(0.38f,-0.88f);
    glVertex2f(0.29f,-0.88f);
    glEnd();

      ///34
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.39f,-0.8f);
    glVertex2f(0.46f,-0.8f);
    glVertex2f(0.46f,-0.88f);
    glVertex2f(0.39f,-0.88f);
    glEnd();
        ///35
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.47f,-0.8f);
    glVertex2f(0.51f,-0.8f);
    glVertex2f(0.51f,-0.88f);
    glVertex2f(0.47f,-0.88f);
    glEnd();
       ///36
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.52f,-0.8f);
    glVertex2f(0.6f,-0.8f);
    glVertex2f(0.6f,-0.88f);
    glVertex2f(0.52f,-0.88f);
    glEnd();

        ///37
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.61f,-0.8f);
    glVertex2f(0.75f,-0.8f);
    glVertex2f(0.75f,-0.88f);
    glVertex2f(0.61f,-0.88f);
    glEnd();
    ///38
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.76f,-0.8f);
    glVertex2f(0.91f,-0.8f);
    glVertex2f(0.91f,-0.88f);
    glVertex2f(0.76f,-0.88f);
    glEnd();
 ///40
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.92f,-0.8f);
    glVertex2f(1.0f,-0.8f);
    glVertex2f(1.0f,-0.88f);
    glVertex2f(0.92f,-0.88f);
    glEnd();


    ///41
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.86f,-0.9f);
    glVertex2f(-0.79f,-0.9f);
    glVertex2f(-0.79f,-1.0f);
    glVertex2f(-0.86f,-1.0f);
    glEnd();

     ///41
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.78f,-0.9f);
    glVertex2f(-0.71f,-0.9f);
    glVertex2f(-0.71f,-1.0f);
    glVertex2f(-0.78f,-1.0f);
    glEnd();
       ///42
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(-0.70f,-0.9f);
    glVertex2f(-0.63f,-0.9f);
    glVertex2f(-0.63f,-1.0f);
    glVertex2f(-0.70f,-1.0f);
    glEnd();

         ///43
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.62f,-0.9f);
    glVertex2f(-0.52f,-0.9f);
    glVertex2f(-0.52f,-1.0f);
    glVertex2f(-0.62f,-1.0f);
    glEnd();

          ///43
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.51f,-0.9f);
    glVertex2f(-0.41f,-0.9f);
    glVertex2f(-0.41f,-1.0f);
    glVertex2f(-0.51f,-1.0f);
    glEnd();
        ///44
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.40f,-0.9f);
    glVertex2f(-0.31f,-0.9f);
    glVertex2f(-0.31f,-1.0f);
    glVertex2f(-0.40f,-1.0f);
    glEnd();
          ///45
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.30f,-0.9f);
    glVertex2f(-0.27f,-0.9f);
    glVertex2f(-0.27f,-1.0f);
    glVertex2f(-0.30f,-1.0f);
    glEnd();

           ///46
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(-0.26f,-0.9f);
    glVertex2f(-0.17f,-0.9f);
    glVertex2f(-0.17f,-1.0f);
    glVertex2f(-0.26f,-1.0f);
    glEnd();

       ///47
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.16f,-0.9f);
    glVertex2f(-0.01f,-0.9f);
    glVertex2f(-0.01f,-1.0f);
    glVertex2f(-0.16f,-1.0f);
    glEnd();

      ///47
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0,-0.9f);
    glVertex2f(0.07f,-0.9f);
    glVertex2f(0.07f,-1.0f);
    glVertex2f(0,-1.0f);
    glEnd();

      ///47
    glBegin(GL_POLYGON);
    glColor3ub(123,81,57);
    glVertex2f(0.08,-0.9f);
    glVertex2f(0.18f,-0.9f);
    glVertex2f(0.18f,-1.0f);
    glVertex2f(0.08,-1.0f);
    glEnd();

     ///48
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.19,-0.9f);
    glVertex2f(0.34f,-0.9f);
    glVertex2f(0.34f,-1.0f);
    glVertex2f(0.19,-1.0f);
    glEnd();
     ///49
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.35,-0.9f);
    glVertex2f(0.41f,-0.9f);
    glVertex2f(0.41f,-1.0f);
    glVertex2f(0.35,-1.0f);
    glEnd();
    ///50
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.42,-0.9f);
    glVertex2f(0.49f,-0.9f);
    glVertex2f(0.49f,-1.0f);
    glVertex2f(0.42,-1.0f);
    glEnd();

       ///51
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.5,-0.9f);
    glVertex2f(0.62f,-0.9f);
    glVertex2f(0.62f,-1.0f);
    glVertex2f(0.5f,-1.0f);
    glEnd();
           ///52
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.63,-0.9f);
    glVertex2f(0.75f,-0.9f);
    glVertex2f(0.75f,-1.0f);
    glVertex2f(0.63,-1.0f);
    glEnd();
         ///53
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.76,-0.9f);
    glVertex2f(0.87f,-0.9f);
    glVertex2f(0.87f,-1.0f);
    glVertex2f(0.76,-1.0f);
    glEnd();
///54
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.88,-0.9f);
    glVertex2f(1.0f,-0.9f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(0.88f,-1.0f);
    glEnd();




    ///Upper wall




    glBegin(GL_POLYGON);
    glColor3ub(211,176,147);
    glVertex2f(-0.41f,-0.42f);
    glVertex2f(-0.41f,-0.3f);
    glVertex2f(-0.86f,-0.3f);
    glVertex2f(-0.86f,-0.54f);
    glVertex2f(-0.37f,-0.54f);
    glVertex2f(-0.37f,-0.42f);
    glEnd();


    ///1st bricks

    glBegin(GL_POLYGON);
    glColor3ub(123, 81, 57);
    glVertex2f(-0.85f,-0.35f);
    glVertex2f(-0.72f,-0.35f);
    glVertex2f(-0.72f,-0.43f);
    glVertex2f(-0.85f,-0.43f);
    glEnd();

    /// 2nd

    glBegin(GL_POLYGON);
    glColor3ub(178, 155, 121);
    glVertex2f(-0.71f,-0.35f);
    glVertex2f(-0.65f,-0.35f);
    glVertex2f(-0.65f,-0.43f);
    glVertex2f(-0.71f,-0.43f);
    glEnd();


    ///3rd


    glBegin(GL_POLYGON);
    glColor3ub(117, 51, 16);
    glVertex2f(-0.64f,-0.35f);
    glVertex2f(-0.56f,-0.35f);
    glVertex2f(-0.56f,-0.43f);
    glVertex2f(-0.64f,-0.43f);
    glEnd();

    ///4 th

    glBegin(GL_POLYGON);
    glColor3ub(178, 101, 33);
    glVertex2f(-0.55f,-0.35f);
    glVertex2f(-0.42f,-0.35f);
    glVertex2f(-0.42f,-0.43f);
    glVertex2f(-0.55f,-0.43f);
    glEnd();


    ///5th

    glBegin(GL_POLYGON);
    glColor3ub(163, 110, 60);
    glVertex2f(-0.85f,-0.44f);
    glVertex2f(-0.79f,-0.44f);
    glVertex2f(-0.79f,-0.53f);
    glVertex2f(-0.85f,-0.53f);
    glEnd();



    /// 6 th

    glBegin(GL_POLYGON);
    glColor3ub(123, 81, 57);
    glVertex2f(-0.78f,-0.44f);
    glVertex2f(-0.73f,-0.44f);
    glVertex2f(-0.73f,-0.53f);
    glVertex2f(-0.78f,-0.53f);
    glEnd();


    ///7th


    glBegin(GL_POLYGON);
    glColor3ub(178, 101, 33);
    glVertex2f(-0.72f,-0.44f);
    glVertex2f(-0.56f,-0.44f);
    glVertex2f(-0.56f,-0.53f);
    glVertex2f(-0.72f,-0.53f);
    glEnd();


    ///8 th

    glBegin(GL_POLYGON);
    glColor3ub(68, 59, 58);
    glVertex2f(-0.55f,-0.44f);
    glVertex2f(-0.46f,-0.44f);
    glVertex2f(-0.46f,-0.53f);
    glVertex2f(-0.55f,-0.53f);
    glEnd();


    ///9th

    glBegin(GL_POLYGON);
    glColor3ub(163, 110, 60);
    glVertex2f(-0.45f,-0.44f);
    glVertex2f(-0.38f,-0.44f);
    glVertex2f(-0.38f,-0.53f);
    glVertex2f(-0.45f,-0.53f);
    glEnd();




    ///Arrow rod

    ///1st
    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(-0.77f,0.08f);
    glVertex2f(-0.74f,0.08f);
    glVertex2f(-0.74f,-0.3f);
    glVertex2f(-0.77f,-0.3f);
        glEnd();

    ///2nd
       glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(-0.57f,0.08f);
    glVertex2f(-0.54f,0.08f);
    glVertex2f(-0.54f,-0.3f);
    glVertex2f(-0.57f,-0.3f);
        glEnd();


    ///Arrow board
    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(-0.79f,-0.01f);
    glVertex2f(-0.79f,-0.19f);
    glVertex2f(-0.52f,-0.14f);
    glVertex2f(-0.5f,-0.04f);
    glVertex2f(-0.53f,0.05f);

    glEnd();


    ///Arrow board inside triangle
    glBegin(GL_POLYGON);
    glColor3ub(84,90,97);
    glVertex2f(-0.78f,-0.03f);
    glVertex2f(-0.78f,-0.15f);
    glVertex2f(-0.73f,-0.14f);
    glVertex2f(-0.71f,-0.08f);
    glVertex2f(-0.73f,-0.02f);

    glEnd();



    ///Coins

    ///1st
     glBegin(GL_POLYGON);
    glColor3ub(204,204,204);
    glVertex2f(0.5f,-0.31f);
    glVertex2f(0.53f,-0.37f);
    glVertex2f(0.5f,-0.43f);
    glVertex2f(0.47f,-0.37f);


    glEnd();

    ///inside
     glBegin(GL_POLYGON);
    glColor3ub(117,117,117);
    glVertex2f(0.5f,-0.33f);
    glVertex2f(0.52f,-0.37f);
    glVertex2f(0.5f,-0.41f);
    glVertex2f(0.48f,-0.37f);


    glEnd();

        ///2nd
     glBegin(GL_POLYGON);
    glColor3ub(204,204,204);
    glVertex2f(0.84f,-0.31f);
    glVertex2f(0.87f,-0.37f);
    glVertex2f(0.84f,-0.43f);
    glVertex2f(0.81f,-0.37f);


    glEnd();

    ///inside
    glBegin(GL_POLYGON);
    glColor3ub(117,117,117);
    glVertex2f(0.84f,-0.33f);
    glVertex2f(0.86f,-0.37f);
    glVertex2f(0.84f,-0.41f);
    glVertex2f(0.82f,-0.36f);


    glEnd();


        ///3rd
     glBegin(GL_POLYGON);
    glColor3ub(204,204,204);
    glVertex2f(0.84f,0.09f);
    glVertex2f(0.87f,0.01f);
    glVertex2f(0.84f,-0.06f);
    glVertex2f(0.81f,0.02f);
    glEnd();

    ///inside
    glBegin(GL_POLYGON);
    glColor3ub(117,117,117);
    glVertex2f(0.84f,0.05f);
    glVertex2f(0.86f,0.01f);
    glVertex2f(0.84f,-0.02f);
    glVertex2f(0.82f,0.01f);
    glEnd();

    /*obstacle1 obs1(0.0,0.0);
    obstacle1 obs2(0.20,0.0);
    obstacle1 obs3(0.40,0.0);
    obstacle1 obs4(0.10,0.10);
    obstacle1 obs5(0.30,0.10);
    obstacle1 obs6(0.20,0.20);
*/
    /*double coordinates[][2] = {
        {0.0, 0.0},
        {0.20, 0.0},
        {0.40, 0.0},
        {0.10, 0.10},
        {0.30, 0.10},
        {0.20, 0.20}
    };
*/
    for(int i=0;i<6;i++)
    {
        Obstacles[i].draw();
    }


    glColor3ub(255,255,255);
    renderBitmapString(-0.68f, -0.06f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Start");

    /*upperBrick(0.0,0.0);
    upperBrick(0.20,0.0);
    upperBrick(0.40,0.0);
    upperBrick(0.10,0.10);
    upperBrick(0.30,0.10);
    upperBrick(0.20,0.20);*/

    display_Map1_Screen1(0.0,0.0);
    display_Map1_Screen2(0.0,0.0);
    display_Map1_Screen3();
    display_Map1_Screen4();

    c1.position1(-0.9,-0.78);
    ///character2();
    glPopMatrix();


    point_table();
   /* cloud(0,0);
    cloud(-0.35,0.3);
    cloud(-0.8,-0.0);
    cloud(-0.97,0.35);
    cloud(-1.43,0.45);
*/
     glFlush(); // Render now
}


bool notmoveableX_Left()
{
    for (int i=0;i<6;i++)
            {
                if (Obstacles[i].check_colusionx2(c1))
                {
                   return true;
                }
            }
}

bool notmoveableX_Right()
{
    for (int i=0;i<6;i++)
            {
                if (Obstacles[i].check_colusionx(c1))
                {
                   return true;
                }
            }
}

bool notmoveableY_Bottom() {
    for (int i = 0; i < 6; i++) {
        if (Obstacles[i].check_colusiony(c1)) { // Modified function call
            return true;
        }
    }
    return false;
}


void update(int value) {
    if (jumping) {
        if (charTranslatey < 0.35 && jumped == false) {
            charTranslatey += 0.01;
            glutTimerFunc(15, update, 0);
        } else {
            jumped = true;
            if (!notmoveableY_Bottom()) {
                charTranslatey -= 0.01;
                glutTimerFunc(15, update, 0);
                if (charTranslatey <= 0.0) {
                    jumping = false;
                    jumped = false;
                    charTranslatey = 0.0;
                }
            } else {
                // Character is on top of an obstacle, prevent further downward movement
                jumping = false;
                jumped = false;
            }
        }
    }

    glutPostRedisplay();
}

void update2(int value)
 {
    if (jumping) {
        mapTranslateX -= 0.004;
        charTranslateX += 0.004;
        if (charTranslatey <1.0 && jumped == false) {
            charTranslatey += 0.01;
            glutTimerFunc(10, update2, 0); // Call update2 recursively with 10ms delay
        } else {
            jumped = true;
            charTranslatey -= 0.01;
            glutTimerFunc(10, update2, 0); // Call update2 recursively with 10ms delay
            if (charTranslatey <= 0.0) {
                jumping = false;
                jumped = false;
                charTranslatey = 0.0;
            }
        }
    }
    glutPostRedisplay();
}


void Movement_SpecialInput(int key, int x, int y)
{
    switch(key)
    {
        case GLUT_KEY_UP:
            if (!jumping) {
                jumping = true;
                update(0);
            }
            break;

        case GLUT_KEY_DOWN:

            break;

        case GLUT_KEY_LEFT:
            if(!notmoveableX_Left())
            {
                mapTranslateX += 0.01;
                charTranslateX -= 0.01;
                glutPostRedisplay();
            }
            break;


        case GLUT_KEY_RIGHT:
            if(!notmoveableX_Right())
            {
                    mapTranslateX -= 0.01;
                    charTranslateX += 0.01;
                    glutPostRedisplay();
            }

            break;
        case GLUT_KEY_INSERT:
            if (!jumping) {
                jumping = true;
                update2(0);
            }
            break;

            ///Shift key method
        /*case GLUT_ACTIVE_SHIFT:
            if (key == GLUT_KEY_RIGHT) {
                shiftupdate(0);
            }
            break;*/

    }
    glutPostRedisplay();
}


void Movement_handleKeypress(unsigned char key, int x, int y)
{
	switch (key)
    {
    case ' ':
            if (!jumping) {
                jumping = true;
                update2(0);
            }
            break;

    glutPostRedisplay();

	}
}
