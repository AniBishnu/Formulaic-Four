#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"


void TopBordar1M2s4(float x, float y)
{
    glBegin(GL_QUADS);
    glColor3ub(159,149,150);
    glVertex2f(x+(-0.66f),y+(0.34f));
    glVertex2f(x+(0.13f),y+(0.34f));
    glVertex2f(x+(0.13f),y+(0.27f));
    glVertex2f(x+(-0.66f),y+(0.27f));
    glEnd();

}

void TopBordar1(float x, float y)
{
    glBegin(GL_QUADS);
    glColor3ub(159,149,150);
    glVertex2f(x+(0.32f),y+(-0.38f));
    glVertex2f(x+(1.00f),y+(-0.38f));
    glVertex2f(x+(1.0f),y+(-0.44f));
    glVertex2f(x+(0.32f),y+(-0.44f));
    glEnd();

}

void Box(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(x+(-0.51f),y+(-0.61f));
    glVertex2f(x+(-0.28f),y+(-0.61f));
    glVertex2f(x+(-0.28f),y+(-0.67f));
    glVertex2f(x+(-0.51f),y+(-0.67f));
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(178,170,171);
    glVertex2f(x+(-0.51f),y+(-0.62f));
    glVertex2f(x+(-0.28f),y+(-0.62f));
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(x+(-0.51f),y+(-0.43f));
    glVertex2f(x+(-0.28f),y+(-0.43f));
    glVertex2f(x+(-0.28f),y+(-0.605f));
    glVertex2f(x+(-0.51f),y+(-0.605f));
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(178,170,171);
    glVertex2f(x+(-0.51f),y+(-0.43f));
    glVertex2f(x+(-0.28f),y+(-0.43f));
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.395f),y+(-0.42f));
    glVertex2f(x+(-0.395f),y+(-0.6f));
    glEnd();

}

void Bridge5(float x, float y)
{
    glBegin(GL_QUADS);
    glColor3ub(159,149,150);
    glVertex2f(x+(0.33f),y+(-0.41f));
    glVertex2f(x+(0.33f),y+(-0.7f));
    glVertex2f(x+(0.123f),y+(-0.92f));
    glVertex2f(x+(0.123f),y+(-0.63f));
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(0.123f),y+(-0.63f));
    glVertex2f(x+(0.33f),y+(-0.63f));
    glVertex2f(x+(0.123f),y+(-0.695f));
    glVertex2f(x+(0.32f),y+(-0.695f));
    glEnd();

}



void wallbackM2s4(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(x+(-0.65f),y+(0.27f));
    glVertex2f(x+(0.124f),y+(0.27f));
    glVertex2f(x+(0.124f),y+(0.04f));
    glVertex2f(x+(-0.65f),y+(0.04f));
    glEnd();
}


void wallback1M2s4(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(x+(0.33f),y+(-0.44f));
    glVertex2f(x+(1.0f),y+(-0.44f));
    glVertex2f(x+(1.0f),y+(-0.68f));
    glVertex2f(x+(0.33f),y+(-0.68f));
    glEnd();
}

void wallBrickM2s4(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(x+(-0.64f),y+(-0.01f));
    glVertex2f(x+(-0.51f),y+(-0.01f));
    glVertex2f(x+(-0.51f),y+(-0.09f));
    glVertex2f(x+(-0.64f),y+(-0.09f));
    glEnd();
}


void wallBrick1M2s4(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(x+(-0.5f),y+(-0.01f));
    glVertex2f(x+(-0.38f),y+(-0.01f));
    glVertex2f(x+(-0.38f),y+(-0.09f));
    glVertex2f(x+(-0.5f),y+(-0.09f));
    glEnd();
}

void wallBrick3M2s4(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(x+(0.17f),y+(-0.01f));
    glVertex2f(x+(0.25f),y+(-0.01f));
    glVertex2f(x+(0.25f),y+(-0.09f));
    glVertex2f(x+(0.17f),y+(-0.09f));
    glEnd();

}


void wallBrick4M2s4(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(x+(-0.64f),y+(-0.11f));
    glVertex2f(x+(-0.57f),y+(-0.11f));
    glVertex2f(x+(-0.57f),y+(-0.19f));
    glVertex2f(x+(-0.64f),y+(-0.19f));
    glEnd();

}

void wallBrick5(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(x+(0.96f),y+(-0.56f));
    glVertex2f(x+(1.0f),y+(-0.56f));
    glVertex2f(x+(1.0f),y+(-0.64f));
    glVertex2f(x+(0.96f),y+(-0.64f));
    glEnd();

}



void topTriangleM2s4(float x, float y)
{
    glBegin(GL_TRIANGLES);
    glColor3ub(159,149,150);
    glVertex2f(x+(0.73f),y+(0.45f));
    glVertex2f(x+(0.68f),y+(0.13f));
    glVertex2f(x+(0.78f),y+(0.13f));
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(159,149,150);
    glVertex2f(x+(0.65f),y+(0.13f));
    glVertex2f(x+(0.81f),y+(0.13f));
    glVertex2f(x+(0.81f),y+(0.06f));
    glVertex2f(x+(0.65f),y+(0.06f));
    glEnd();
}


void column2M2s4(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(x+(0.311f),y+(0.01f));
    glVertex2f(x+(0.52f),y+(0.01f));
    glVertex2f(x+(0.52f),y+(-0.07f));
    glVertex2f(x+(0.311f),y+(-0.07f));
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(x+(0.33f),y+(-0.07f));
    glVertex2f(x+(0.5f),y+(-0.07f));
    glVertex2f(x+(0.5f),y+(-0.67f));
    glVertex2f(x+(0.33f),y+(-0.67f));
    glEnd();


    glLineWidth(6);
    glBegin(GL_LINES);
    glColor3ub(76,74,78);
    glVertex2f(x+(0.33f),y+(-0.07f));
    glVertex2f(x+(0.5f),y+(-0.07f));
    glEnd();
/// black line 1
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(x+(0.36f),y+(-0.13f));
    glVertex2f(x+(0.36f),y+(-0.65f));
    glEnd();

/// black line 2
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(x+(0.41f),y+(-0.13f));
    glVertex2f(x+(0.41f),y+(-0.65f));
    glEnd();


/// black line 3
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(x+(0.46f),y+(-0.13f));
    glVertex2f(x+(0.46f),y+(-0.65f));
    glEnd();



}




void display_Map2_Screen4()
{
    glPushMatrix();
    glTranslatef(8.0,0.0,0.0);

    /// pani

    glBegin(GL_POLYGON);
    glColor3ub(46,165,255);
    glVertex2f(-1.0f,-0.82f);
    glVertex2f(1.0f,-0.82f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();






    TopBordar(0,0);
    TopBordar(0,-0.3);
    wallback(0,0);
    wallBrick(0,.25);
    wallBrick1(0,.25);
    wallBrick(0.27,.25);
    wallBrick1(0.27,.25);
    wallBrick(0.54,.25);
    wallBrick3(-0.13,.25);
    wallBrick4(0,0.25);
    wallBrick1(-0.06,0.15);
    wallBrick(0.21,0.15);
    wallBrick1(0.21,0.15);
    wallBrick(0.48,0.15);
    wallBrick(0.625,0.15);



    TopBordar(0,-0.968);
    TopBordar(0,-1.269);
    wallback(0,-0.968);
    wallBrick(0,-0.72);
    wallBrick1(0,-0.72);
    wallBrick(0.27,-0.72);
    wallBrick1(0.27,-0.72);
    wallBrick(0.54,-0.72);
    wallBrick3(-0.13,-0.72);
    wallBrick4(0,-0.72);
    wallBrick1(-0.06,-0.82);
    wallBrick(0.21,-0.82);
    wallBrick1(0.21,-0.82);
    wallBrick(0.48,-0.82);
    wallBrick(0.625,-0.82);



    TopBordar1(0,0);
    TopBordar1(0,-0.3);
    wallback1M2s4(0,0);
    wallBrick(0.976,-0.45);
    wallBrick1(0.976,-0.45);
    wallBrick(1.245,-0.45);
    wallBrick1(1.245,-0.45);
    wallBrick(1.51,-0.45);
    wallBrick4(0.98,-0.45);
    wallBrick(1.065,-0.55);
    wallBrick1(1.065,-0.55);
    wallBrick(1.335,-0.55);
    wallBrick1(1.335,-0.55);
    wallBrick5(0,0);

    topTriangle(0,0);



    column2(-1.3,-0.329);
    Bridge5(0,0);
    Box(0.82,0.73);


    glPopMatrix();

}
