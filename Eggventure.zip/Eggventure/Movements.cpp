#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

///Shift key method
/*
void shiftupdate(int value) {
    if (mapTranslateX > -0.5) {
        mapTranslateX -= 0.004;
        charTranslateX += 0.004;
        glutPostRedisplay();
        glutTimerFunc(10, shiftupdate, 0); // Call shiftupdate recursively with a 10ms delay
    }
}
*/




