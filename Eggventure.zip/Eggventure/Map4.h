#ifndef MAP4_H_INCLUDED
#define MAP4_H_INCLUDED


void display_Map4_Start();

class cave
{
public:

void cave_Front(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(129,125,124);
    glVertex2f(x+(-0.93f),-0.54f);
    glVertex2f(x+(-0.92f),-0.48f);
    glVertex2f(x+(-0.87f),-0.48f);
    glVertex2f(x+(-0.854f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(74,77,92);
    glVertex2f(x+(-0.915f),-0.54f);
    glVertex2f(x+(-0.91f),-0.49f);
    glVertex2f(x+(-0.89f),-0.49f);
    glVertex2f(x+(-0.88f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f(x+(-0.88f),-0.465f);
    glVertex2f(x+(-0.87f),-0.48f);
    glVertex2f(x+(-0.89f),-0.49f);
    glVertex2f(x+(-0.91f),-0.49f);
    glVertex2f(x+(-0.92f),-0.48f);
    glVertex2f(x+(-0.9f),-0.465f);
    glEnd();
}

void cave_Door()
{
    ///red background
    glBegin(GL_POLYGON);
    glColor3ub(144,42,37);
    glVertex2f((-0.85f),-0.54f);
    glVertex2f((-0.83f),0.00f);
    glVertex2f((-0.53f),0.06f);
    glVertex2f((-0.52f),-0.54f);
    glEnd();

    ///down shadow
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,76);
    glVertex2f((-0.83f),-0.09f);
    glVertex2f((-0.83f),-0.07f);
    glVertex2f((-0.53f),0.01f);
    glVertex2f((-0.53f),-0.009f);
    glEnd();

    ///Top shadow
    glBegin(GL_POLYGON);
    glColor3ub(90,26,27);
    glVertex2f((-0.83f),0.00f);
    glVertex2f((-0.83f),0.1f);
    glVertex2f((-0.532f),0.14f);
    glVertex2f((-0.53f),0.06f);
    glEnd();

    ///door nut
    glPointSize(6);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((-0.82f),-0.12f);
    glVertex2f((-0.58f),-0.05f);
    glVertex2f((-0.56f),-0.04f);
    glEnd();
    ///stone background
    glBegin(GL_POLYGON);
    glColor3ub(71,70,84);
    glVertex2f((-0.8f),-0.54f);
    glVertex2f((-0.8f),-0.07f);
    glVertex2f((-0.61f),-0.01f);
    glVertex2f((-0.62f),-0.54f);
    glEnd();

    ///black background
    glBegin(GL_POLYGON);
    glColor3ub(18,17,22);
    glVertex2f((-0.73f),-0.54f);
    glVertex2f((-0.74f),-0.05f);
    glVertex2f((-0.64f),-0.02f);
    glVertex2f((-0.65f),-0.54f);
    glEnd();
}

void caveDraw()
{
    ///left 3nd stone,after front stone
    glBegin(GL_POLYGON);
    glColor3ub(167,163,186);
    glVertex2f((-0.92f),-0.01f);
    glVertex2f((-0.9f),0.27f);
    glVertex2f((-0.82f),0.23f);
    glVertex2f((-0.82f),-0.12f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,91,115);
    glVertex2f((-0.82f),0.23f);
    glVertex2f((-0.75f),0.28f);
    glVertex2f((-0.75f),0.06f);
    glVertex2f((-0.82f),-0.12f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f((-0.9f),0.27f);
    glVertex2f((-0.86f),0.31f);
    glVertex2f((-0.78f),0.3f);
    glVertex2f((-0.75f),0.28f);
    glVertex2f((-0.82f),0.23f);
    glEnd();

    ///Top 3rd stone
    glBegin(GL_POLYGON);
    glColor3ub(167,163,186);
    glVertex2f((-0.63f),0.12f);
    glVertex2f((-0.63f),0.33f);
    glVertex2f((-0.56f),0.33f);
    glVertex2f((-0.56f),0.13f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,91,115);
    glVertex2f((-0.58f),0.28f);
    glVertex2f((-0.55f),0.32f);
    glVertex2f((-0.54f),0.1f);
    glVertex2f((-0.58f),0.1f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f((-0.63f),0.33f);
    glVertex2f((-0.59f),0.35f);
    glVertex2f((-0.55f),0.32f);
    glVertex2f((-0.58f),0.28f);
    glEnd();

    ///Top 2nd stone
    glBegin(GL_POLYGON);
    glColor3ub(142,141,159);
    glVertex2f((-0.79f),0.1f);
    glVertex2f((-0.77f),0.37f);
    glVertex2f((-0.74f),0.3f);
    glVertex2f((-0.73f),0.09f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(167,163,186);
    glVertex2f((-0.74f),0.3f);
    glVertex2f((-0.67f),0.29f);
    glVertex2f((-0.66f),0.11f);
    glVertex2f((-0.73f),0.09f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,91,115);
    glVertex2f((-0.67f),0.29f);
    glVertex2f((-0.61f),0.37f);
    glVertex2f((-0.61f),-0.13f);
    glVertex2f((-0.67f),0.11f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f((-0.77f),0.37f);
    glVertex2f((-0.73f),0.41f);
    glVertex2f((-0.67f),0.41f);
    glVertex2f((-0.61f),0.37f);
    glVertex2f((-0.67f),0.29f);
    glVertex2f((-0.74f),0.3f);
    glEnd();

    ///Top 1st stone
    glBegin(GL_POLYGON);
    glColor3ub(74,77,82);
    glVertex2f((-0.76f),-0.08f);
    glVertex2f((-0.75f),0.2f);
    glVertex2f((-0.68f),0.18f);
    glVertex2f((-0.69f),0.1f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(129,125,124);
    glVertex2f((-0.68f),0.18f);
    glVertex2f((-0.65f),0.2f);
    glVertex2f((-0.64f),0.12f);
    glVertex2f((-0.69f),0.1f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(68,55,73);
    glVertex2f((-0.75f),0.2f);
    glVertex2f((-0.73f),0.23f);
    glVertex2f((-0.7f),0.23f);
    glVertex2f((-0.65f),0.2f);
    glVertex2f((-0.68f),0.18f);
    glEnd();


    ///3rd right stone,after front stone
    glBegin(GL_POLYGON);
    glColor3ub(142,141,159);
    glVertex2f((-0.58f),0.13f);
    glVertex2f((-0.57f),0.26f);
    glVertex2f((-0.53f),0.19f);
    glVertex2f((-0.55f),-0.32f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(167,163,186);
    glVertex2f((-0.55f),-0.32f);
    glVertex2f((-0.53f),0.19f);
    glVertex2f((-0.47f),0.18f);
    glVertex2f((-0.46f),-0.28f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,91,115);
    glVertex2f((-0.46f),-0.28f);
    glVertex2f((-0.47f),0.18f);
    glVertex2f((-0.41f),0.27f);
    glVertex2f((-0.43f),-0.1f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f((-0.57f),0.26f);
    glVertex2f((-0.52f),0.33f);
    glVertex2f((-0.41f),0.27f);
    glVertex2f((-0.47f),0.18f);
    glVertex2f((-0.53f),0.19f);
    glEnd();


    ///2nd right stone,after front stone
    glBegin(GL_POLYGON);
    glColor3ub(93,91,115);
    glVertex2f((-0.51f),-0.15f);
    glVertex2f((-0.49f),0.14f);
    glVertex2f((-0.46f),0.09f);
    glVertex2f((-0.46f),-0.11f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(167,163,186);
    glVertex2f((-0.46f),-0.11f);
    glVertex2f((-0.46f),0.09f);
    glVertex2f((-0.42f),0.14f);
    glVertex2f((-0.41f),-0.08f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f((-0.49f),0.14f);
    glVertex2f((-0.46f),0.17f);
    glVertex2f((-0.42f),0.14f);
    glVertex2f((-0.46f),0.09f);
    glEnd();

     ///1st right stone,after front stone
    glBegin(GL_POLYGON);
    glColor3ub(74,77,92);
    glVertex2f((-0.54f),-0.54f);
    glVertex2f((-0.53f),-0.15f);
    glVertex2f((-0.49f),-0.17f);
    glVertex2f((-0.5f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(111,109,131);
    glVertex2f((-0.5f),-0.54f);
    glVertex2f((-0.49f),-0.17f);
    glVertex2f((-0.445f),-0.2f);
    glVertex2f((-0.45f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,143,160);
    glVertex2f((-0.45f),-0.54f);
    glVertex2f((-0.445f),-0.2f);
    glVertex2f((-0.38f),-0.2f);
    glVertex2f((-0.36f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124,121,140);
    glVertex2f((-0.36f),-0.54f);
    glVertex2f((-0.38f),-0.2f);
    glVertex2f((-0.35f),-0.15f);
    glVertex2f((-0.32f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f((-0.53f),-0.15f);
    glVertex2f((-0.41f),-0.08f);
    glVertex2f((-0.35f),-0.15f);
    glVertex2f((-0.38f),-0.2f);
    glVertex2f((-0.445f),-0.2f);
    glEnd();


    ///Most right stone,after front stone
    glBegin(GL_POLYGON);
    glColor3ub(74,77,92);
    glVertex2f((-0.42f),-0.54f);
    glVertex2f((-0.4f),-0.23f);
    glVertex2f((-0.36f),-0.3f);
    glVertex2f((-0.37f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(167,163,186);
    glVertex2f((-0.37f),-0.54f);
    glVertex2f((-0.36f),-0.3f);
    glVertex2f((-0.31f),-0.3f);
    glVertex2f((-0.29f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(142,141,159);
    glVertex2f((-0.29f),-0.54f);
    glVertex2f((-0.31f),-0.3f);
    glVertex2f((-0.25f),-0.24f);
    glVertex2f((-0.23f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f((-0.4f),-0.23f);
    glVertex2f((-0.36f),-0.2f);
    glVertex2f((-0.31f),-0.21f);
    glVertex2f((-0.25f),-0.24f);
    glVertex2f((-0.31f),-0.3f);
    glVertex2f((-0.36f),-0.3f);
    glEnd();

    ///left 2nd stone,after front stone
    glBegin(GL_POLYGON);
    glColor3ub(142,141,159);
    glVertex2f((-0.99f),-0.54f);
    glVertex2f((-0.96f),-0.08f);
    glVertex2f((-0.91f),-0.18f);
    glVertex2f((-0.92f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(167,163,186);
    glVertex2f((-0.91f),-0.18f);
    glVertex2f((-0.86f),-0.18f);
    glVertex2f((-0.85f),-0.54f);
    glVertex2f((-0.92f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,91,115);
    glVertex2f((-0.86f),-0.18f);
    glVertex2f((-0.83f),-0.12f);
    glVertex2f((-0.82f),-0.54f);
    glVertex2f((-0.85f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f((-0.96f),-0.08f);
    glVertex2f((-0.92f),-0.01f);
    glVertex2f((-0.85f),-0.01f);
    glVertex2f((-0.81f),-0.09f);
    glVertex2f((-0.86f),-0.18f);
    glVertex2f((-0.91f),-0.18f);
    glEnd();


    ///left 1st stone,after front stone
    glBegin(GL_POLYGON);
    glColor3ub(167,163,186);
    glVertex2f((-0.96f),-0.54f);
    glVertex2f((-0.94f),-0.32f);
    glVertex2f((-0.87f),-0.36f);
    glVertex2f((-0.87f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,91,115);
    glVertex2f((-0.87f),-0.54f);
    glVertex2f((-0.87f),-0.36f);
    glVertex2f((-0.84f),-0.31f);
    glVertex2f((-0.83f),-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,184,196);
    glVertex2f((-0.94f),-0.32f);
    glVertex2f((-0.88f),-0.27f);
    glVertex2f((-0.84f),-0.31f);
    glVertex2f((-0.87f),-0.36f);
    glEnd();


    cave_Door();

    ///front stones
    cave_Front(0.0,0.0);
    cave_Front(0.39,0.0);
}
};
#endif // MAP4_H_INCLUDED
