#ifndef OBSTACLES_H_INCLUDED
#define OBSTACLES_H_INCLUDED
#include <windows.h>
#include <GL/glut.h>
#include "Start.h"

#include<iostream>

///class character;

#include<math.h>>

# define PI           3.14159265358979323846

class Pata
{
public:
    float x_Axis;
    float y_Axis;
public:
    pata()
    {

    }

void position1 (float t, float z)
{
    int i;

	GLfloat x=(t+0.845f); GLfloat y=(z+0.8f); GLfloat radius =.08f;
	int triangleAmount = 300; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;


	glColor3ub(48,98,0);
	glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for(i = 0; i <= triangleAmount;i++) {
    glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

	GLfloat o=(t+0.9f); GLfloat p=(z+0.7f); GLfloat r4 =.08f;


	glColor3ub(48,98,0);
	glBegin(GL_TRIANGLE_FAN);
    glVertex2f(o,p); // center of circle
    for(i = 0; i <= triangleAmount;i++) {
    glVertex2f( o + (r4 * cos(i *  twicePi / triangleAmount)),
    p + (r4 * sin(i * twicePi / triangleAmount)) );
    }
	glEnd();



}
};

class Character
{
public:
    float x_Axis;
    float y_Axis;
public:
    float X_Left_Char=-0.12;
    float X_Right_Char=0.01;
    float Y_Top_Char= -0.05;
    float Y_Bottom_Char=-0.54;

    float set_right_Char(){return X_Right_Char;}
    float set_Left_Char(){return X_Left_Char;}
    float set_Top_Char(){return Y_Top_Char;}
    float set_Bottom_Char(){return Y_Bottom_Char;}



void position1 (float t, float z)
{
    int i;

    glPushMatrix();
    glTranslatef(charTranslateX,charTranslatey, 0.0f);
	GLfloat x=(t+0.845f); GLfloat y=(z+0.297f); GLfloat radius =.058f;
	int triangleAmount = 300; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	 GLfloat o=(t+0.845f); GLfloat p=(z+0.457f); GLfloat r4 =.04f;


	glColor3ub(169,169,169);
	glBegin(GL_TRIANGLE_FAN);
    glVertex2f(o,p); // center of circle
    for(i = 0; i <= triangleAmount;i++) {
    glVertex2f( o + (r4 * cos(i *  twicePi / triangleAmount)),
    p + (r4 * sin(i * twicePi / triangleAmount)) );
    }
	glEnd();

	glColor3ub(253,238,195);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

	GLfloat a=(t+0.845f); GLfloat b=(z+0.434f); GLfloat r =.0343f;
	 //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius

	glColor3ub(253,238,195);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a, b); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( a + (r * cos(i *  twicePi / triangleAmount)),
                        b + (r * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

	glColor3ub(253,238,195);
	glBegin(GL_POLYGON);
    glVertex2f(t+(0.81),z+(0.43)); // center of circle
    glVertex2f(t+(0.88),z+(0.43)); // center of circle
    glVertex2f(t+(0.9),z+(0.32)); // center of circle
    glVertex2f(t+(0.79),z+(0.32)); // center of circle
    glEnd();

    GLfloat c=(t+0.845f); GLfloat d=(z+0.297f); GLfloat r1 =.061f;
	 //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi1 = -1.0f * PI;

	glColor3ub(143,97,35);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(c, d); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (r1 * cos(i *  twicePi1 / triangleAmount)),
                        y + (r1 * sin(i * twicePi1 / triangleAmount)) );
		}
	glEnd();


	GLfloat e=(t+0.83f); GLfloat f=(z+0.42f); GLfloat r2 =.01f;
	 //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius


	glColor3ub(0,0,0);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(e, f); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( e + (r2 * cos(i *  twicePi / triangleAmount)),
                        f + (r2 * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

	GLfloat g=(t+0.86f); GLfloat h=(z+0.42f);
	 //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius


	glColor3ub(0,0,0);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(g, h); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( g + (r2 * cos(i *  twicePi / triangleAmount)),
                        h + (r2 * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();



GLfloat j=(t+0.86f); GLfloat k=(z+0.42f); GLfloat r3 =.003f;


	glColor3ub(255,255,255);
	glBegin(GL_TRIANGLE_FAN);
    glVertex2f(j,k); // center of circle
    for(i = 0; i <= triangleAmount;i++) {
    glVertex2f( j + (r3 * cos(i *  twicePi / triangleAmount)),
    k + (r3 * sin(i * twicePi / triangleAmount)) );
    }
	glEnd();


	GLfloat m=(t+0.83f); GLfloat n=(z+0.42f);
	 //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius


	glColor3ub(255,255,255);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(m,n); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( m + (r3 * cos(i *  twicePi / triangleAmount)),
                        n + (r3 * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

	glColor3ub(169,169,169);
	glBegin(GL_POLYGON);
    glVertex2f(t+(0.82),z+(0.58)); // center of circle
    glVertex2f(t+(0.87),z+(0.58)); // center of circle
    glVertex2f(t+(0.87),z+(0.47)); // center of circle
    glVertex2f(t+(0.82),z+(0.47)); // center of circle
    glEnd();


    GLfloat q=(t+0.845f); GLfloat s=(z+0.57f); GLfloat r5 =.027f;


	glColor3ub(169,169,169);
	glBegin(GL_TRIANGLE_FAN);
    glVertex2f(q,s); // center of circle
    for(i = 0; i <= triangleAmount;i++) {
    glVertex2f( q + (r5 * cos(i *  twicePi / triangleAmount)),
    s + (r5 * sin(i * twicePi / triangleAmount)) );
    }
	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(t+0.82f,z+0.36f);
	glVertex2f(t+0.87f,z+0.36f);
	glEnd();


glPopMatrix();
}
};
class obstacle1
{
public:
    float x;
    float y;
    float Left_Obs=x+0.30;
    float Right_Obs=x+0.50;
    float Y_Top_Obs=y+(-44);
    float Y_Bottom_Obs=y+(-0.54);

    obstacle1(float x, float y) : x(x), y(y) {};

    void draw()
    {
        glBegin(GL_POLYGON);
        glColor3f(0.447f,0.306f,0.290f);
        glVertex2f(x+(0.30f),y+(-0.54f));
        glVertex2f(x+(0.50f),y+(-0.54f));
        glVertex2f(x+(0.50f),y+(-0.44f));
        glVertex2f(x+(0.30f),y+(-0.44f));
        glEnd();

        glLineWidth(3);
        glBegin(GL_LINE_LOOP);
        glColor3ub(0,0,0);
        glVertex2f(x+(0.30f),y+(-0.54f));
        glVertex2f(x+(0.50f),y+(-0.54f));
        glVertex2f(x+(0.50f),y+(-0.44f));
        glVertex2f(x+(0.30f),y+(-0.44f));
        glEnd();
    }

    bool check_colusionx(Character characterObj)const
    {
        float X_Right_Char=characterObj.set_right_Char()+charTranslateX;
        float X_Left_Char=characterObj.set_Left_Char()+charTranslateX;
        float Y_Top_Char=characterObj.set_Top_Char()+charTranslatey;
        float Y_Bottom_Char=characterObj.set_Bottom_Char()+charTranslatey;

        float X_Left_Obs=Left_Obs+mapTranslateX;
        float X_Right_Obs=Right_Obs+mapTranslateX;

        if(0.01>=X_Left_Obs)
        {
           if(0.01<X_Right_Obs)
           {
               if(check_colusiony(characterObj))
               {return false;}
               else if(check_charontop(characterObj))
               {return false;}
               else{return true;}
           }
           else{return false;}

        }
        else{return false;}
    }

    bool check_colusionx2(Character characterObj)const
    {
        float X_Right_Char=characterObj.set_right_Char()+charTranslateX;
        float X_Left_Char=characterObj.set_Left_Char()+charTranslateX;
        float Y_Top_Char=characterObj.set_Top_Char()+charTranslatey;
        float Y_Bottom_Char=characterObj.set_Bottom_Char()+charTranslatey;

        float X_Left_Obs=Left_Obs+mapTranslateX;
        float X_Right_Obs=Right_Obs+mapTranslateX;

        if(-0.12<=X_Right_Obs  )
        {
           if(-0.12>X_Left_Obs){return true;}
           else{return false;}

        }
        else{return false;}
    }
    bool check_charontop(Character characterObj)const
    {
        float Y_Bottom_Char=characterObj.set_Bottom_Char()+charTranslatey;

        if(Y_Bottom_Char<Y_Top_Obs)
        {
            return true;
        }
        else{return false;}
    }

    bool check_colusiony(Character characterObj)const
    {
        float X_Right_Char=characterObj.set_right_Char()+charTranslateX;
        float X_Left_Char=characterObj.set_Left_Char()+charTranslateX;
        float Y_Top_Char=characterObj.set_Top_Char()+charTranslatey;
        float Y_Bottom_Char=characterObj.set_Bottom_Char()+charTranslatey;

        float X_Left_Obs=Left_Obs+mapTranslateX;
        float X_Right_Obs=Right_Obs+mapTranslateX;

        if(Y_Bottom_Char<=Y_Top_Obs)
        {
            if(Y_Bottom_Char>Y_Bottom_Obs )
            {
                return true;
                /*if(0.22>=X_Left_Obs)
                {
                    if(0.22<X_Right_Obs){return true;}
                    else{return false;}
                }
                else{return false;}*/
            }

        }
        else{return false;}
    }
};

bool isPointInScreen(float x, float y) ;
bool isBrickInScreen(const obstacle1& obstacle1);
#endif // OBSTACLES_H_INCLUDED
