#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void bar(float x, float y)
{
     glBegin(GL_POLYGON);
    glColor3ub(139,130,77);
    glVertex2f(x+(0.01f),y+(0.78f));
    glVertex2f(x+(0.04f),y+(0.78f));
    glVertex2f(x+(0.04f),y+(0.52f));
    glVertex2f(x+(0.01f),y+(0.52f));
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(20,44,46);
    glVertex2f(x+(0.04f),y+(0.78f));
    glVertex2f(x+(0.04f),y+(0.52f));
    glEnd();
}

void grass(float x, float y)
{


    ///Grass first part
    glBegin(GL_POLYGON);
    glColor3ub(56,128,4);
    glVertex2f(x+(-0.62f),y+(-0.2f));
    glVertex2f(x+(-0.65f),y+(-0.09f));
    glVertex2f(x+(-0.64f),y+(-0.06f));
    glVertex2f(x+(-0.59f),y+(-0.2f));
    glEnd();

    ///Grass triangle
    glBegin(GL_TRIANGLES);
    glColor3ub(56,128,4);
    glVertex2f(x+(-0.65f),y+(-0.09f));
    glVertex2f(x+(-0.67f),y+(-0.17f));
    glVertex2f(x+(-0.64f),y+(-0.12f));
    glEnd();

    ///Grass 2nd part
    glBegin(GL_POLYGON);
    glColor3ub(56,128,4);
    glVertex2f(x+(-0.62f),y+(-0.13f));
    glVertex2f(x+(-0.63f),y+(0.02f));
    glVertex2f(x+(-0.6f),y+(-0.13f));
    glVertex2f(x+(-0.61f),y+(-0.16f));
    glEnd();

    ///Grass 3rd part
    glBegin(GL_POLYGON);
    glColor3ub(56,128,4);
    glVertex2f(x+(-0.61f),y+(-0.16f));
    glVertex2f(x+(-0.6f),y+(0.07f));
    glVertex2f(x+(-0.59f),y+(-0.11f));
    glVertex2f(x+(-0.6f),y+(-0.18f));
    glEnd();

    ///Grass 4th part
    glBegin(GL_POLYGON);
    glColor3ub(56,128,4);
    glVertex2f(x+(-0.6f),y+(-0.18f));
    glVertex2f(x+(-0.58f),y+(0.02f));
    glVertex2f(x+(-0.58f),y+(-0.14f));
    glVertex2f(x+(-0.59f),y+(-0.2f));
    glEnd();

///Grass 5th part
    glBegin(GL_POLYGON);
    glColor3ub(56,128,4);
    glVertex2f(x+(-0.59f),y+(-0.14f));
    glVertex2f(x+(-0.56f),y+(-0.02f));
    glVertex2f(x+(-0.57f),y+(-0.14f));
    glVertex2f(x+(-0.59f),y+(-0.2f));
    glEnd();

    ///Grass 6th part
    glBegin(GL_POLYGON);
    glColor3ub(56,128,4);
    glVertex2f(x+(-0.59f),y+(-0.2f));
    glVertex2f(x+(-0.55f),y+(-0.06f));
    glVertex2f(x+(-0.54f),y+(-0.08f));
    glVertex2f(x+(-0.57f),y+(-0.2f));
    glEnd();

        ///Grass 6th part traingle
    glBegin(GL_TRIANGLES);
    glColor3ub(56,128,4);

    glVertex2f(x+(-0.54f),y+(-0.08f));
    glVertex2f(x+(-0.52f),y+(-0.16f));
    glVertex2f(x+(-0.55f),y+(-0.12f));
    glEnd();
}
void rassta(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(183,171,107);
    glVertex2f(x+(-0.09f),y+(0.75f));
    glVertex2f(x+(0.5f),y+(0.75f));
    glVertex2f(x+(0.5f),y+(0.65f));
    glVertex2f(x+(-0.09f),y+(0.65f));
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(81,87,59);
    glVertex2f(x+(-0.09f),y+(0.66f));
    glVertex2f(x+(0.5f),y+(0.66f));
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(28,46,38);
    glVertex2f(x+(0.5f),y+(0.65f));
    glVertex2f(x+(-0.09f),y+(0.65f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(27,30,18);
    glVertex2f(x+(-0.09f),y+(0.57f));
    glVertex2f(x+(0.5f),y+(0.57f));
    glVertex2f(x+(0.5f),y+(0.55f));
    glVertex2f(x+(-0.09f),y+(0.55f));
    glEnd();


}
void obs1(float x, float y)
{


    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(x+(-0.51f),y+(-0.61f));
    glVertex2f(x+(-0.28f),y+(-0.61f));
    glVertex2f(x+(-0.28f),y+(-0.67f));
    glVertex2f(x+(-0.51f),y+(-0.67f));
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(x+(-0.51f),y+(-0.62f));
    glVertex2f(x+(-0.28f),y+(-0.62f));
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(x+(-0.51f),y+(-0.43f));
    glVertex2f(x+(-0.28f),y+(-0.43f));
    glVertex2f(x+(-0.28f),y+(-0.605f));
    glVertex2f(x+(-0.51f),y+(-0.605f));
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(x+(-0.51f),y+(-0.43f));
    glVertex2f(x+(-0.28f),y+(-0.43f));
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.395f),y+(-0.42f));
    glVertex2f(x+(-0.395f),y+(-0.6f));
    glEnd();
}

void bridgedanda(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(x+(-0.52f),y+(-0.43f));
    glVertex2f(x+(-0.46f),y+(-0.43f));
    glVertex2f(x+(-0.46f),y+(-0.45f));
    glVertex2f(x+(-0.52f),y+(-0.45f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(x+(-0.45f),y+(-0.4f));
    glVertex2f(x+(-0.46f),y+(-0.4f));
    glVertex2f(x+(-0.46f),y+(-0.54f));
    glVertex2f(x+(-0.45f),y+(-0.54f));
    glEnd();



}

void bridgedanda1(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(x+(-0.45f),y+(-0.4f));
    glVertex2f(x+(-0.46f),y+(-0.4f));
    glVertex2f(x+(-0.46f),y+(-0.54f));
    glVertex2f(x+(-0.45f),y+(-0.54f));
    glEnd();
}

void bridgedanda1M2S1(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(x+(-0.52f),y+(-0.43f));
    glVertex2f(x+(-0.46f),y+(-0.43f));
    glVertex2f(x+(-0.46f),y+(-0.45f));
    glVertex2f(x+(-0.52f),y+(-0.45f));
    glEnd();
}

void woodenBox(float x, float y)
{
    ///upper part
    glBegin(GL_POLYGON);
    glColor3ub(159,103,54);
    glVertex2f(x+(-0.09f),y+(0.59f));
    glVertex2f(x+(0.14f),y+(0.59f));
    glVertex2f(x+(0.14f),y+(0.21f));
    glVertex2f(x+(-0.09f),y+(0.21f));
    glEnd();

        ///middle part
    glBegin(GL_POLYGON);
    glColor3ub(178,116,69);
    glVertex2f(x+(-0.06f),y+(0.54f));
    glVertex2f(x+(0.11f),y+(0.54f));
    glVertex2f(x+(0.11f),y+(0.26f));
    glVertex2f(x+(-0.06f),y+(0.26f));
    glEnd();


    ///middle part shade
    glBegin(GL_POLYGON);
    glColor3ub(142,93,55);

     glVertex2f(x+(-0.058f),y+(0.51f));

    glVertex2f(x+(0.1f),y+(0.51f));
    glVertex2f(x+(0.1f),y+(0.29f));
    glVertex2f(x+(-0.058f),y+(0.29f));
    glEnd();

        ///upper part line
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.09f),y+(0.59f));
    glVertex2f(x+(0.14f),y+(0.59f));
    glVertex2f(x+(0.14f),y+(0.21f));
    glVertex2f(x+(-0.09f),y+(0.21f));
    glEnd();

        ///middle part line
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.06f),y+(0.54f));
    glVertex2f(x+(0.11f),y+(0.54f));
    glVertex2f(x+(0.11f),y+(0.26f));
    glVertex2f(x+(-0.06f),y+(0.26f));
    glEnd();

    ///Middle and upper box line
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.09f),y+(0.54f));
    glVertex2f(x+(0.14f),y+(0.54f));
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.09f),y+(0.26f));
    glVertex2f(x+(0.14f),y+(0.26f));
    glEnd();


       ///Middle box line  1
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.05f),y+(0.54f));
    glVertex2f(x+(-0.05f),y+(0.26f));
    glEnd();


    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.01f),y+(0.54f));
    glVertex2f(x+(-0.01f),y+(0.26f));
    glEnd();

        glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(0.03f),y+(0.54f));
    glVertex2f(x+(0.03f),y+(0.26f));
    glEnd();

           glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(0.07f),y+(0.54f));
    glVertex2f(x+(0.07f),y+(0.26f));
    glEnd();

           glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(0.1f),y+(0.54f));
    glVertex2f(x+(0.1f),y+(0.26f));
    glEnd();
}


void pathor(float x, float y)
{

    glLineWidth(2.2);
    glBegin(GL_POLYGON);
    glColor3ub(127,127,127);
    glVertex2f(x+(-0.77f),y+(-0.19f));
    glVertex2f(x+(-0.55f),y+(-0.19f));
    glVertex2f(x+(-0.55f),y+(-0.58f));
    glVertex2f(x+(-0.77f),y+(-0.58f));
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.77f),y+(-0.19f));
    glVertex2f(x+(-0.55f),y+(-0.19f));
    glVertex2f(x+(-0.55f),y+(-0.58f));
    glVertex2f(x+(-0.767f),y+(-0.58f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(82,82,82);
    glVertex2f(x+(-0.77f),y+(-0.19f));
    glVertex2f(x+(-0.71f),y+(-0.19f));
    glVertex2f(x+(-0.69f),y+(-0.4f));
    glVertex2f(x+(-0.77f),y+(-0.36f));
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.77f),y+(-0.19f));
    glVertex2f(x+(-0.71f),y+(-0.19f));
    glVertex2f(x+(-0.69f),y+(-0.4f));
    glVertex2f(x+(-0.77f),y+(-0.36f));
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(82,82,82);
    glVertex2f(x+(-0.64f),y+(-0.41f));
    glVertex2f(x+(-0.6f),y+(-0.19f));
    glVertex2f(x+(-0.61f),y+(-0.44f));
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.64f),y+(-0.41f));
    glVertex2f(x+(-0.6f),y+(-0.19f));
    glVertex2f(x+(-0.61f),y+(-0.44f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(67,67,65);
    glVertex2f(x+(-0.6f),y+(-0.19f));
    glVertex2f(x+(-0.55f),y+(-0.19f));
    glVertex2f(x+(-0.55f),y+(-0.44f));
    glVertex2f(x+(-0.61f),y+(-0.45f));
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.6f),y+(-0.192f));
    glVertex2f(x+(-0.55f),y+(-0.192f));
    glVertex2f(x+(-0.55f),y+(-0.44f));
    glVertex2f(x+(-0.61f),y+(-0.45f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,52,51);
    glVertex2f(x+(-0.77f),y+(-0.36f));
    glVertex2f(x+(-0.64f),y+(-0.41f));
    glVertex2f(x+(-0.68f),y+(-0.58f));
    glVertex2f(x+(-0.77f),y+(-0.58f));
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.77f),y+(-0.36f));
    glVertex2f(x+(-0.64f),y+(-0.41f));
    glVertex2f(x+(-0.68f),y+(-0.58f));
    glVertex2f(x+(-0.77f),y+(-0.58f));
    glEnd();


}



void kath(float x ,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(66,44,27);
    glVertex2f(x+(-0.96f),y+(-0.54f));
    glVertex2f(x+(-0.79f),y+(-0.54f));
    glVertex2f(x+(-0.79f),y+(-0.76f));
    glVertex2f(x+(-0.96f),y+(-0.76f));
    glEnd();

    glLineWidth(9);
    glBegin(GL_LINES);
    glColor3ub(47,32,25);
    glVertex2f(x+(-0.96f),y+(-0.56f));
    glVertex2f(x+(-0.79f),y+(-0.56f));
    glVertex2f(x+(-0.79f),y+(-0.76f));
    glVertex2f(x+(-0.96f),y+(-0.76f));
    glEnd();

    glLineWidth(0.1);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.94f),y+(-0.59f));
    glVertex2f(x+(-0.84f),y+(-0.59f));

    glVertex2f(x+(-0.83f),y+(-0.73f));
    glVertex2f(x+(-0.94f),y+(-0.73f));

    glVertex2f(x+(-0.91f),y+(-0.71f));
    glVertex2f(x+(-0.803f),y+(-0.71f));

    glVertex2f(x+(-0.945f),y+(-0.685f));
    glVertex2f(x+(-0.83f),y+(-0.685f));

    glVertex2f(x+(-0.89f),y+(-0.65f));
    glVertex2f(x+(-0.794f),y+(-0.65f));

    glVertex2f(x+(-0.95f),y+(-0.63f));
    glVertex2f(x+(-0.815f),y+(-0.63f));
    glEnd();



}
