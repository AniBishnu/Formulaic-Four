#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void TopBordar(float x, float y)
{
    glBegin(GL_QUADS);
    glColor3ub(159,149,150);
    glVertex2f(x+(-0.66f),y+(0.08f));
    glVertex2f(x+0.28f,y+(0.08f));
    glVertex2f(x+0.28f,y+(0.02f));
    glVertex2f(x+(-0.66f),y+(0.02f));
    glEnd();

}

void wallback(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(x+(-0.65f),y+(0.02f));
    glVertex2f(0.27f,y+(0.02f));
    glVertex2f(0.27f,y+(-0.22f));
    glVertex2f(x+(-0.65f),y+(-0.22f));
    glEnd();
}

void wallBrick(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(x+(-0.64f),y+(-0.01f));
    glVertex2f(x+(-0.51f),y+(-0.01f));
    glVertex2f(x+(-0.51f),y+(-0.09f));
    glVertex2f(x+(-0.64f),y+(-0.09f));
    glEnd();
}


void wallBrick1(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(x+(-0.5f),y+(-0.01f));
    glVertex2f(x+(-0.38f),y+(-0.01f));
    glVertex2f(x+(-0.38f),y+(-0.09f));
    glVertex2f(x+(-0.5f),y+(-0.09f));
    glEnd();
}

void wallBrick3(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(x+(0.17f),y+(-0.01f));
    glVertex2f(x+(0.25f),y+(-0.01f));
    glVertex2f(x+(0.25f),y+(-0.09f));
    glVertex2f(x+(0.17f),y+(-0.09f));
    glEnd();

}


void wallBrick4(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(x+(-0.64f),y+(-0.11f));
    glVertex2f(x+(-0.57f),y+(-0.11f));
    glVertex2f(x+(-0.57f),y+(-0.19f));
    glVertex2f(x+(-0.64f),y+(-0.19f));
    glEnd();

}

void bottomTriangle(float x, float y)
{
    glBegin(GL_TRIANGLES);
    glColor3ub(159,149,150);
    glVertex2f(x+(-0.54f),y+(-0.34f));
    glVertex2f(x+(-0.48f),y+(-0.67f));
    glVertex2f(x+(-0.59f),y+(-0.67f));
    glEnd();

}

void topTriangle(float x, float y)
{
    glBegin(GL_TRIANGLES);
    glColor3ub(159,149,150);
    glVertex2f(x+(-0.45f),y+(0.77f));
    glVertex2f(x+(-0.35f),y+(0.77f));
    glVertex2f(x+(-0.4f),y+(0.46f));
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(159,149,150);
    glVertex2f(x+(-0.48f),y+(0.84f));
    glVertex2f(x+(-0.32f),y+(0.84f));
    glVertex2f(x+(-0.32f),y+(0.77f));
    glVertex2f(x+(-0.48f),y+(0.77f));
    glEnd();
}


void column2(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(0.3f,0.01f);
    glVertex2f(0.52f,0.01f);
    glVertex2f(0.52f,-0.07f);
    glVertex2f(0.3f,-0.07f);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(0.33f,-0.07f);
    glVertex2f(0.5f,-0.07f);
    glVertex2f(0.5f,-0.67f);
    glVertex2f(0.33f,-0.67f);
    glEnd();


    glLineWidth(6);
    glBegin(GL_LINES);
    glColor3ub(76,74,78);
    glVertex2f(0.33f,-0.07f);
    glVertex2f(0.5f,-0.07f);
    glEnd();
/// black line 1
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(0.36f,-0.13f);
    glVertex2f(0.36f,-0.65f);
    glEnd();

/// black line 2
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(0.41f,-0.13f);
    glVertex2f(0.41f,-0.65f);
    glEnd();


/// black line 3
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(0.46f,-0.13f);
    glVertex2f(0.46f,-0.65f);
    glEnd();



}


void column3()
{
    glTranslatef(0.1f,-0.13f,0.0f);
    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(0.46f,0.5f);
    glVertex2f(0.69f,0.5f);
    glVertex2f(0.69f,0.43f);
    glVertex2f(0.46f,0.43f);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(0.5f,0.43f);
    glVertex2f(0.65f,0.43f);
    glVertex2f(0.65f,-0.54f);
    glVertex2f(0.5f,-0.54f);
    glEnd();


    glLineWidth(6);
    glBegin(GL_LINES);
    glColor3ub(76,74,78);
    glVertex2f(0.5f,0.42f);
    glVertex2f(0.65f,0.42f);
    glEnd();
/// black line 1
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(0.53f,0.33f);
    glVertex2f(0.53f,-0.52f);
    glEnd();

/// black line 2
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(0.58f,0.32f);
    glVertex2f(0.58f,-0.52f);
    glEnd();


/// black line 3
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(0.62f,0.33f);
    glVertex2f(0.62f,-0.52f);
    glEnd();
}
