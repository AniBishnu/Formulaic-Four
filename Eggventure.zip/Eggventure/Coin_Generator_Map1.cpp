#include <windows.h>
#include <GL/glut.h>
#include <iostream>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void Coin_Generator()
{

}
