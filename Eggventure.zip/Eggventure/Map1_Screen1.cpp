#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"
void coin1(float x, float y)
{
    ///1st
     glBegin(GL_POLYGON);
    glColor3ub(204,204,204);
    glVertex2f((0.5f-x),(-0.31f-y));
    glVertex2f((0.53f-x),(-0.37f-y));
    glVertex2f((0.5f-x),(-0.43f-y));
    glVertex2f((0.47f-x),(-0.37f-y));


    glEnd();

    ///inside
     glBegin(GL_POLYGON);
    glColor3ub(117,117,117);
    glVertex2f((0.5f-x),(-0.33f-y));
    glVertex2f((0.52f-x),(-0.37f-y));
    glVertex2f((0.5f-x),(-0.41f-y));
    glVertex2f((0.48f-x),(-0.37f-y));


    glEnd();
}

void column1(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(x+(-0.94f),y+0.02f);
    glVertex2f(x+(-0.73f),y+0.02f);
    glVertex2f(x+(-0.73f),y+(-0.06f));
    glVertex2f(x+(-0.94f),y+(-0.06f));
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(x+(-0.91f),y+(-0.06f));
    glVertex2f(x+(-0.76f),y+(-0.06f));
    glVertex2f(x+(-0.76f),y+(-0.54f));
    glVertex2f(x+(-0.91f),y+(-0.54f));
    glEnd();



    glLineWidth(6);
    glBegin(GL_LINES);
    glColor3ub(68,47,44);
    glVertex2f(x+(-0.91f),y+(-0.07f));
    glVertex2f(x+(-0.76f),y+(-0.07f));
    glEnd();
/// black line 1

    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(x+(-0.88f),y+(-0.13f));
    glVertex2f(x+(-0.88f),y+(-0.54f));
    glEnd();

/// black line 2

    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(x+(-0.83f),y+(-0.13f));
    glVertex2f(x+(-0.83f),y+(-0.54f));
    glEnd();


/// black line 3

    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(x+(-0.78f),y+(-0.13f));
    glVertex2f(x+(-0.78f),y+(-0.54f));
    glEnd();

}





void column3MS1()
{

    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(0.46f,0.5f);
    glVertex2f(0.69f,0.5f);
    glVertex2f(0.69f,0.43f);
    glVertex2f(0.46f,0.43f);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(0.5f,0.43f);
    glVertex2f(0.65f,0.43f);
    glVertex2f(0.65f,-0.54f);
    glVertex2f(0.5f,-0.54f);
    glEnd();


    glLineWidth(6);
    glBegin(GL_LINES);
    glColor3ub(68,47,44);
    glVertex2f(0.5f,0.42f);
    glVertex2f(0.65f,0.42f);
    glEnd();

/// black line 1
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(0.53f,0.33f);
    glVertex2f(0.53f,-0.54f);
    glEnd();

/// black line 2
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(0.58f,0.33f);
    glVertex2f(0.58f,-0.54f);
    glEnd();


/// black line 3
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3ub(46,32,30);
    glVertex2f(0.62f,0.33f);
    glVertex2f(0.62f,-0.54f);
    glEnd();


}





void bridge(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(190,116,71);
    glVertex2f(x+(-0.49f),y+(-0.54f));
    glVertex2f(x+(0.16f),y+(-0.54f));
    glVertex2f(x+(0.16f),y+(-0.67f));
    glVertex2f(x+(-0.49f),y+(-0.67f));
    glEnd();
}


void bridgeColumn(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(123,87,58);
    glVertex2f(x+(-0.36f),y+(-0.94f));
    glVertex2f(x+(-0.36f),y+(-0.67f));
    glVertex2f(x+(-0.3f),y+(-0.67f));
    glVertex2f(x+(-0.3f),y+(-0.94f));
    glVertex2f(x+(-0.27f),y+(-1.0f));
    glVertex2f(x+(-0.40f),y+(-1.0f));
    glEnd();

    glLineWidth(2);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.36f),y+(-0.94f));
    glVertex2f(x+(-0.3f),y+(-0.94f));
    glEnd();

}



void display_Map1_Screen1(float x,float y)
{
    glPushMatrix();
    glTranslatef(2.0,0.0,0.0);
///pani

    glBegin(GL_POLYGON);
    glColor3ub(46,165,255);
    glVertex2f(-0.52,-0.82f);
    glVertex2f(0.18f,-0.82f);
    glVertex2f(0.18f,-1.0f);
    glVertex2f(-0.52,-1.0f);
    glEnd();

    ///wall

    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(-1.0f,-0.54f);
    glVertex2f(-0.49f,-0.54f);
    glVertex2f(-0.49f,-0.67f);
    glVertex2f(-1.0f,-0.67f);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(-0.51f,-0.67f);
    glVertex2f(-0.51f,-0.86f);
    glVertex2f(-0.5f,-0.86f);
    glVertex2f(-0.5f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(-1.0f,-0.56f);
    glVertex2f(-0.49f,-0.56f);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(114,78,74);
    glVertex2f(0.16f,-0.54f);
    glVertex2f(1.0f,-0.54f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(0.16f,-0.67f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(0.18f,-0.78f);
    glVertex2f(0.15f,-0.78f);
    glVertex2f(0.15f,-0.9f);
    glVertex2f(0.18f,-0.9f);
    glVertex2f(0.18f,-1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(0.18f,-0.67f);
    glEnd();

    glLineWidth(8);
    glBegin(GL_LINES);
    glColor3ub(142,113,110);
    glVertex2f(0.16f,-0.56f);
    glVertex2f(1.0f,-0.56f);
    glEnd();

     /// Bricks
    ///1
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.7f);
    glVertex2f(-0.89f,-0.7f);
    glVertex2f(-0.89f,-0.78f);
    glVertex2f(-0.99f,-0.78f);
    glEnd();
    ///2
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.99f,-0.8f);
    glVertex2f(-0.89f,-0.8f);
    glVertex2f(-0.89f,-0.88f);
    glVertex2f(-0.99f,-0.88f);
    glEnd();

    ///3
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.9f);
    glVertex2f(-0.87f,-0.9f);
    glVertex2f(-0.87f,-1.0f);
    glVertex2f(-0.99f,-1.0f);
    glEnd();

    ///4
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.88f,-0.7f);
    glVertex2f(-0.82f,-0.7f);
    glVertex2f(-0.82f,-0.78f);
    glVertex2f(-0.88f,-0.78f);
    glEnd();

    ///5
    glBegin(GL_POLYGON);
     glColor3ub(117,51,16);
    glVertex2f(-0.81f,-0.7f);
    glVertex2f(-0.77f,-0.7f);
    glVertex2f(-0.77f,-0.78f);
    glVertex2f(-0.81f,-0.78f);
    glEnd();

  ///6
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(-0.76f,-0.7f);
    glVertex2f(-0.67f,-0.7f);
    glVertex2f(-0.67f,-0.78f);
    glVertex2f(-0.76f,-0.78f);
    glEnd();

    ///7
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(-0.66f,-0.7f);
    glVertex2f(-0.53f,-0.7f);
    glVertex2f(-0.53f,-0.78f);
    glVertex2f(-0.66f,-0.78f);
    glEnd();




     ///8
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.20f,-0.7f);
    glVertex2f(0.23f,-0.7f);
    glVertex2f(0.23f,-0.78f);
    glVertex2f(0.20,-0.78f);
    glEnd();

    ///9
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.24f,-0.7f);
    glVertex2f(0.39f,-0.7f);
    glVertex2f(0.39f,-0.78f);
    glVertex2f(0.24,-0.78f);
    glEnd();

      ///10
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.4f,-0.7f);
    glVertex2f(0.51f,-0.7f);
    glVertex2f(0.51f,-0.78f);
    glVertex2f(0.4,-0.78f);
    glEnd();

          ///11
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.52f,-0.7f);
    glVertex2f(0.59f,-0.7f);
    glVertex2f(0.59f,-0.78f);
    glVertex2f(0.52,-0.78f);
    glEnd();

          ///12
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.6f,-0.7f);
    glVertex2f(0.64f,-0.7f);
    glVertex2f(0.64f,-0.78f);
    glVertex2f(0.6,-0.78f);
    glEnd();


          ///13
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.65f,-0.7f);
    glVertex2f(0.74f,-0.7f);
    glVertex2f(0.74f,-0.78f);
    glVertex2f(0.65,-0.78f);
    glEnd();

             ///14
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.75f,-0.7f);
    glVertex2f(0.8f,-0.7f);
    glVertex2f(0.8f,-0.78f);
    glVertex2f(0.75,-0.78f);
    glEnd();

           ///15
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.81f,-0.7f);
    glVertex2f(0.88f,-0.7f);
    glVertex2f(0.88f,-0.78f);
    glVertex2f(0.81,-0.78f);
    glEnd();

              ///16
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.89f,-0.7f);
    glVertex2f(1.0f,-0.7f);
    glVertex2f(1.0f,-0.78f);
    glVertex2f(0.89,-0.78f);
    glEnd();



///17
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.88f,-0.8f);
    glVertex2f(-0.78f,-0.8f);
    glVertex2f(-0.78f,-0.88f);
    glVertex2f(-0.88f,-0.88f);
    glEnd();

    ///18
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(-0.77f,-0.8f);
    glVertex2f(-0.66f,-0.8f);
    glVertex2f(-0.66f,-0.88f);
    glVertex2f(-0.77f,-0.88f);
    glEnd();

      ///19
    glBegin(GL_POLYGON);
    glColor3ub(123,81,57);
    glVertex2f(-0.65f,-0.8f);
    glVertex2f(-0.54f,-0.8f);
    glVertex2f(-0.54f,-0.88f);
    glVertex2f(-0.65f,-0.88f);
    glEnd();


         ///20
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.16f,-0.8f);
    glVertex2f(0.28f,-0.8f);
    glVertex2f(0.28f,-0.88f);
    glVertex2f(0.16f,-0.88f);
    glEnd();

         ///21
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.29f,-0.8f);
    glVertex2f(0.38f,-0.8f);
    glVertex2f(0.38f,-0.88f);
    glVertex2f(0.29f,-0.88f);
    glEnd();

      ///22
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.39f,-0.8f);
    glVertex2f(0.46f,-0.8f);
    glVertex2f(0.46f,-0.88f);
    glVertex2f(0.39f,-0.88f);
    glEnd();
        ///23
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.47f,-0.8f);
    glVertex2f(0.51f,-0.8f);
    glVertex2f(0.51f,-0.88f);
    glVertex2f(0.47f,-0.88f);
    glEnd();
       ///24
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.52f,-0.8f);
    glVertex2f(0.6f,-0.8f);
    glVertex2f(0.6f,-0.88f);
    glVertex2f(0.52f,-0.88f);
    glEnd();

        ///25
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.61f,-0.8f);
    glVertex2f(0.75f,-0.8f);
    glVertex2f(0.75f,-0.88f);
    glVertex2f(0.61f,-0.88f);
    glEnd();
    ///26
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.76f,-0.8f);
    glVertex2f(0.91f,-0.8f);
    glVertex2f(0.91f,-0.88f);
    glVertex2f(0.76f,-0.88f);
    glEnd();
 ///27
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.92f,-0.8f);
    glVertex2f(1.0f,-0.8f);
    glVertex2f(1.0f,-0.88f);
    glVertex2f(0.92f,-0.88f);
    glEnd();


    ///28
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.86f,-0.9f);
    glVertex2f(-0.79f,-0.9f);
    glVertex2f(-0.79f,-1.0f);
    glVertex2f(-0.86f,-1.0f);
    glEnd();

     ///29
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.78f,-0.9f);
    glVertex2f(-0.71f,-0.9f);
    glVertex2f(-0.71f,-1.0f);
    glVertex2f(-0.78f,-1.0f);
    glEnd();
       ///30
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(-0.70f,-0.9f);
    glVertex2f(-0.63f,-0.9f);
    glVertex2f(-0.63f,-1.0f);
    glVertex2f(-0.70f,-1.0f);
    glEnd();

         ///31
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.62f,-0.9f);
    glVertex2f(-0.52f,-0.9f);
    glVertex2f(-0.52f,-1.0f);
    glVertex2f(-0.62f,-1.0f);
    glEnd();

     ///32
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.19,-0.9f);
    glVertex2f(0.34f,-0.9f);
    glVertex2f(0.34f,-1.0f);
    glVertex2f(0.19,-1.0f);
    glEnd();
     ///33
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.35,-0.9f);
    glVertex2f(0.41f,-0.9f);
    glVertex2f(0.41f,-1.0f);
    glVertex2f(0.35,-1.0f);
    glEnd();
    ///34
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.42,-0.9f);
    glVertex2f(0.49f,-0.9f);
    glVertex2f(0.49f,-1.0f);
    glVertex2f(0.42,-1.0f);
    glEnd();

       ///35
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.5,-0.9f);
    glVertex2f(0.62f,-0.9f);
    glVertex2f(0.62f,-1.0f);
    glVertex2f(0.5f,-1.0f);
    glEnd();
           ///36
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.63,-0.9f);
    glVertex2f(0.75f,-0.9f);
    glVertex2f(0.75f,-1.0f);
    glVertex2f(0.63,-1.0f);
    glEnd();
    ///37
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.76,-0.9f);
    glVertex2f(0.87f,-0.9f);
    glVertex2f(0.87f,-1.0f);
    glVertex2f(0.76,-1.0f);
    glEnd();
    ///38
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.88,-0.9f);
    glVertex2f(1.0f,-0.9f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(0.88f,-1.0f);
    glEnd();

    column1(0,0);
    column1(1.16,0);
    column3MS1();
    column1(1.65,0);
    bridge(0,0);
    bridgedanda(0,0);
    bridgedanda(0.07,0);
    bridgedanda(0.14,0);
    bridgedanda(0.21,0);
    bridgedanda(0.28,0);
    bridgedanda(0.35,0);
    bridgedanda(0.42,0);
    bridgedanda(0.49,0);
    bridgedanda(0.56,0);
    bridgedanda1M2S1(0.63,0);
    bridgeColumn(0,0);
    bridgeColumn(0.3,0);

    coin1(0.0,0.0);

    glPopMatrix();

}
