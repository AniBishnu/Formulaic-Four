#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void cloud(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2f((-0.87f-x),(0.63f-y));
    glVertex2f((-0.91f-x),(0.63f-y));
    glVertex2f((-0.92f-x),(0.64f-y));
    glVertex2f((-0.93f-x),(0.68f-y));
    glVertex2f((-0.93f-x),(0.71f-y));
    glVertex2f((-0.92f-x),(0.72f-y));
    glVertex2f((-0.91f-x),(0.73f-y));
    glVertex2f((-0.91f-x),(0.73f-y));
    glVertex2f((-0.9f-x),(0.75f-y));
    glVertex2f((-0.88f-x),(0.76f-y));
    glVertex2f((-0.86f-x),(0.76f-y));
    glVertex2f((-0.85f-x),(0.74f-y));
    glVertex2f((-0.84f-x),(0.77f-y));
    glVertex2f((-0.83f-x),(0.8f-y));
    glVertex2f((-0.81f-x),(0.8f-y));
    glVertex2f((-0.79f-x),(0.8f-y));
    glVertex2f((-0.78f-x),(0.78f-y));
    glVertex2f((-0.77f-x),(0.77f-y));
    glVertex2f((-0.75f-x),(0.78f-y));
    glVertex2f((-0.73f-x),(0.78f-y));
    glVertex2f((-0.72f-x),(0.77f-y));
    glVertex2f((-0.72f-x),(0.79f-y));
    glVertex2f((-0.68f-x),(0.8f-y));
    glVertex2f((-0.66f-x),(0.79f-y));
    glVertex2f((-0.64f-x),(0.75f-y));
    glVertex2f((-0.81f-x),(0.62f-y));
    glVertex2f((-0.83f-x),(0.6f-y));
    glVertex2f((-0.85f-x),(0.61f-y));
    glEnd();



    /// Cloud light purple

    glBegin(GL_POLYGON);
    glColor3ub(204,194,247);
    glVertex2f((-0.83f-x),(0.71f-y));
    glVertex2f((-0.82f-x),(0.73f-y));
    glVertex2f((-0.81f-x),(0.74f-y));
    glVertex2f((-0.79f-x),(0.73f-y));
    glVertex2f((-0.78f-x),(0.72f-y));
    glVertex2f((-0.77f-x),(0.7f-y));
    glVertex2f((-0.77f-x),(0.73f-y));
    glVertex2f((-0.76f-x),(0.75f-y));
    glVertex2f((-0.75f-x),(0.75f-y));
    glVertex2f((-0.73f-x),(0.73f-y));
    glVertex2f((-0.72f-x),(0.74f-y));
    glVertex2f((-0.68f-x),(0.74f-y));
    glVertex2f((-0.74f-x),(0.61f-y));
    glVertex2f((-0.75f-x),(0.6f-y));
    glVertex2f((-0.77f-x),(0.61f-y));
    glVertex2f((-0.79f-x),(0.59f-y));
    glVertex2f((-0.8f-x),(0.59f-y));
    glVertex2f((-0.81f-x),(0.62f-y));
    glVertex2f((-0.82f-x),(0.62f-y));
    glVertex2f((-0.83f-x),(0.63f-y));
    glVertex2f((-0.84f-x),(0.62f-y));
    glVertex2f((-0.86f-x),(0.61f-y));
    glVertex2f((-0.87f-x),(0.64f-y));
    glVertex2f((-0.87f-x),(0.67f-y));
    glVertex2f((-0.86f-x),(0.68f-y));
    glVertex2f((-0.86f-x),(0.72f-y));
    glVertex2f((-0.85f-x),(0.73f-y));
    glVertex2f((-0.84f-x),(0.74f-y));
    glEnd();


    ///cloud dark purple
    glBegin(GL_POLYGON);
    glColor3ub(168,148,243);
    glVertex2f((-0.73f-x),(0.63f-y));
    glVertex2f((-0.74f-x),(0.62f-y));
    glVertex2f((-0.76f-x),(0.63f-y));
    glVertex2f((-0.76f-x),(0.67f-y));
    glVertex2f((-0.75f-x),(0.69f-y));
    glVertex2f((-0.73f-x),(0.68f-y));
    glVertex2f((-0.72f-x),(0.71f-y));
    glVertex2f((-0.7f-x),(0.7f-y));
    glVertex2f((-0.7f-x),(0.73f-y));
    glVertex2f((-0.69f-x),(0.75f-y));
    glVertex2f((-0.68f-x),(0.75f-y));
    glVertex2f((-0.67f-x),(0.74f-y));
    glVertex2f((-0.65f-x),(0.76f-y));
    glVertex2f((-0.64f-x),(0.75f-y));
    glVertex2f((-0.64f-x),(0.72f-y));
    glVertex2f((-0.62f-x),(0.72f-y));
    glVertex2f((-0.6f-x),(0.7f-y));
    glVertex2f((-0.6f-x),(0.68f-y));
    glVertex2f((-0.61f-x),(0.65f-y));
    glVertex2f((-0.65f-x),(0.63f-y));
    glVertex2f((-0.66f-x),(0.66f-y));
    glVertex2f((-0.67f-x),(0.63f-y));
    glVertex2f((-0.68f-x),(0.65f-y));
    glVertex2f((-0.7f-x),(0.63f-y));
    glVertex2f((-0.71f-x),(0.62f-y));
    glEnd();
}
