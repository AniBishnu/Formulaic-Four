#ifndef MAP1_H_INCLUDED
#define MAP1_H_INCLUDED

void bridgedanda(float x, float y);
void bridgedanda1(float x, float y);
void bridgedanda1M2S1(float x, float y);

void bridgeColumn();
void bridgedanda9();
void grass(float x, float y);
void rassta(float x, float y);
void obs1(float x, float y);
void woodenBox(float x, float y);
void pathor(float x, float y);
void kath(float x ,float y);

void bar(float x, float y);
void display_Map1_Start();
void display_Map1_Screen1(float x,float y);
void display_Map1_Screen2(float x,float y);
void display_Map1_Screen3();
void display_Map1_Screen4();

#endif // MAP1_H_INCLUDED
