#ifndef MAP2_H_INCLUDED
#define MAP2_H_INCLUDED

void TopBordar(float x, float y);
void wallback(float x, float y);
void wallBrick(float x, float y);
void wallBrick1(float x, float y);
void wallBrick3(float x, float y);
void wallBrick4(float x, float y);
void bottomTriangle(float x, float y);
void topTriangle(float x, float y);
void column2(float x, float y);
void column3();

void display_Map2_Start();
void display_Map2_Screen1(float x,float y);
void display_Map2_Screen2(float x,float y);
void display_Map2_Screen3(float x,float y);
void display_Map2_Screen4();
void display_Map1_Screen5();

#endif // MAP2_H_INCLUDED
