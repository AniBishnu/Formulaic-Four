#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void cross(float x, float y)
{
    glBegin(GL_LINES);
    glColor3ub(49,52,59);
     glVertex2f(x+(-0.07),y+(0.92));
    glVertex2f(x+(0.04f),y+(0.62f));
    glVertex2f(x+(-0.07f),y+(0.61f));
    glVertex2f(x+(0.05f),y+(0.91f));
    glEnd();
}

void piller_M3(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(76,75,80);
    glVertex2f(x+0.14,y+.01);
    glVertex2f(x+(0.16),y+(-0.08));
    glVertex2f(x+(0.28),y+(-0.08));
    glVertex2f(x+0.30,y+.01);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(96,95,100);
    glVertex2f(x+(0.16),y+(-0.08));
    glVertex2f(x+(0.16),y+(-0.55));
    glVertex2f(x+(0.28),y+(-0.55));
    glVertex2f(x+(0.28),y+(-0.08));

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(96,95,100);
    glVertex2f(x+(0.16),y+(-0.55));
    glVertex2f(x+(0.11),y+(-0.64));
    glVertex2f(x+(0.34),y+(-0.64));
    glVertex2f(x+(0.28),y+(-0.55));

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(43,35,67);
    glVertex2f(x+(0.21),y+(-0.56));
    glVertex2f(x+(0.17),y+(-0.64));
    glVertex2f(x+(0.28),y+(-0.64));
    glVertex2f(x+(0.24),y+(-0.56));

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(40,42,55);
    glVertex2f(x+(0.18),y+(-0.15));
    glVertex2f(x+(0.18),y+(-0.25));
    glVertex2f(x+(0.26),y+(-0.25));
    glVertex2f(x+(0.26),y+(-0.15));

    glEnd();



     glBegin(GL_POLYGON);
    glColor3ub(40,42,55);
    glVertex2f(x+(0.18),y+(-0.42));
    glVertex2f(x+(0.18),y+(-0.52));
    glVertex2f(x+(0.26),y+(-0.52));
    glVertex2f(x+(0.26),y+(-0.42));
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(40,42,55);
    glVertex2f(x+(0.21),y+(-0.28));
    glVertex2f(x+(0.21),y+(-0.37));
    glVertex2f(x+(0.23),y+(-0.37));
    glVertex2f(x+(0.23),y+(-0.28));
    glEnd();


    glLineWidth(1);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(0.18),y+(-0.15f));
    glVertex2f(x+(0.18f),y+(-0.52f));
    glVertex2f(x+(0.26f),y+(-0.52f));
    glVertex2f(x+(0.26f),y+(-0.15f));
    glEnd();

    glLineWidth(10);
    glBegin(GL_LINES);
    glColor3ub(48,47,50);
    glVertex2f(x+(0.16f),y+(-0.08f));
    glVertex2f(x+(0.28f),y+(-0.08f));
    glEnd();


}

void box_M3(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(191,159,74);
    glVertex2f(x+(-0.43f),y+0.82f);
    glVertex2f(x+(-0.44f),y+0.79f);
    glVertex2f(x+(-0.44f),y+0.55f);
    glVertex2f(x+(-0.43f),y+0.52f);
    glVertex2f(x+(-0.38f),y+0.52f);
    glVertex2f(x+(-0.37f),y+0.55f);
    glVertex2f(x+(-0.37f),y+0.79f);
    glVertex2f(x+(-0.38f),y+0.82f);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(62,96,12);
    glVertex2f(x+(-0.37f),y+0.76f);
    glVertex2f(x+(-0.37f),y+0.55f);
    glVertex2f(x+(-0.20f),y+0.55f);
    glVertex2f(x+(-0.20f),y+0.76f);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(175,193,207);
    glVertex2f(x+(-0.37f),y+0.79f);
    glVertex2f(x+(-0.37f),y+0.76f);
    glVertex2f(x+(-0.2f),y+0.76f);
    glVertex2f(x+(-0.20f),y+0.79f);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(113,113,137);
    glVertex2f(x+(-0.32f),y+0.82f);
    glVertex2f(x+(-0.32f),y+0.77f);
    glVertex2f(x+(-0.25f),y+0.77f);
    glVertex2f(x+(-0.25f),y+0.82f);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(85,208,223);
    glVertex2f(x+(-0.32f),y+0.72f);
    glVertex2f(x+(-0.32f),y+0.70f);
    glVertex2f(x+(-0.25f),y+0.70f);
    glVertex2f(x+(-0.25f),y+0.72f);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(113,113,137);
    glVertex2f(x+(-0.32f),y+0.67f);
    glVertex2f(x+(-0.32f),y+0.55f);
    glVertex2f(x+(-0.25f),y+0.55f);
    glVertex2f(x+(-0.25f),y+0.67f);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.32f),y+0.65f);
    glVertex2f(x+(-0.25f),y+0.65f);
    glVertex2f(x+(-0.32f),y+0.61f);
    glVertex2f(x+(-0.25f),y+0.61f);
    glVertex2f(x+(-0.32f),y+0.57f);
    glVertex2f(x+(-0.25f),y+0.57f);
    glEnd();


     glBegin(GL_POLYGON);
    glColor3ub(191,159,74);
    glVertex2f(x+(-0.19f),y+0.82f);
    glVertex2f(x+(-0.20f),y+0.79f);
    glVertex2f(x+(-0.20f),y+0.55f);
    glVertex2f(x+(-0.19f),y+0.52f);
    glVertex2f(x+(-0.14f),y+0.52f);
    glVertex2f(x+(-0.13f),y+0.55f);
    glVertex2f(x+(-0.13f),y+0.79f);
    glVertex2f(x+(-0.14f),y+0.82f);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.44f),y+0.76f);
    glVertex2f(x+(-0.37f),y+0.76f);
    glVertex2f(x+(-0.20f),y+0.76f);
    glVertex2f(x+(-0.13f),y+0.76f);
    glEnd();
}

void obst1(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(237,166,19);
    glVertex2f(x+(-0.99f),(-0.52f-y));
    glVertex2f(x+(-0.89f),(-0.52f-y));
    glVertex2f(x+(-0.89f),(-0.63f-y));
    glVertex2f(x+(-0.99f),(-0.63f-y));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.96f),(-0.52f-y));
    glVertex2f(x+(-0.95f),(-0.52f-y));
    glVertex2f(x+(-0.98f),(-0.63f-y));
    glVertex2f(x+(-0.99f),(-0.63f-y));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.935f),(-0.52f-y));
    glVertex2f(x+(-0.925f),(-0.52f-y));
    glVertex2f(x+(-0.955f),(-0.63f-y));
    glVertex2f(x+(-0.965f),(-0.63f-y));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(x+(-0.91f),(-0.52f-y));
    glVertex2f(x+(-0.9f),(-0.52f-y));
    glVertex2f(x+(-0.93f),(-0.63f-y));
    glVertex2f(x+(-0.94f),(-0.63f-y));
    glEnd();
}


void brickR1(float x,float y)
{
    ///brick 1
    glBegin(GL_POLYGON);
    glColor3ub(48,85,129);
    glVertex2f((x+(-0.99f)),-0.70f);
    glVertex2f((x+(-0.91f)),-0.70f);
    glVertex2f((x+(-0.91f)),-0.78f);
    glVertex2f((x+(-0.99f)),-0.78f);
    glEnd();

    ///brick 1 points
    glPointSize(4.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.985f)),-0.71f);
    glVertex2f((x+(-0.915f)),-0.71f);
    glVertex2f((x+(-0.915f)),-0.77f);
    glVertex2f((x+(-0.985f)),-0.77f);
    glEnd();

    ///brick 1 inside
    glBegin(GL_POLYGON);
    glColor3ub(72,161,189);
    glVertex2f((x+(-0.98f)),-0.72f);
    glVertex2f((x+(-0.92f)),-0.72f);
    glVertex2f((x+(-0.92f)),-0.76f);
    glVertex2f((x+(-0.98f)),-0.76f);
    glEnd();

    ///brick 1 Line 1
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(255,255,255,102);
    glVertex2f((x+(-0.98f)),-0.72f);
    glVertex2f((x+(-0.92f)),-0.72f);
    glEnd();

    ///brick 1 Line 2
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_LINES);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.92f)),-0.72f);
    glVertex2f((x+(-0.92f)),-0.76f);
    glEnd();

    ///brick 1 Line 3
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.92f)),-0.76f);
    glVertex2f((x+(-0.98f)),-0.76f);
    glEnd();

    ///brick 1 Line 4
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(255,255,255,102);
    glVertex2f((x+(-0.98f)),-0.76f);
    glVertex2f((x+(-0.98f)),-0.72f);
    glEnd();


    ///brick 2
    glBegin(GL_POLYGON);
    glColor3ub(48,85,129);
    glVertex2f((x+(-0.90f)),-0.70f);
    glVertex2f((x+(-0.82f)),-0.70f);
    glVertex2f((x+(-0.82f)),-0.78f);
    glVertex2f((x+(-0.90f)),-0.78f);
    glEnd();

    ///brick 2 points
    glPointSize(4.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.89f)),-0.71f);
    glVertex2f((x+(-0.83f)),-0.71f);
    glVertex2f((x+(-0.83f)),-0.77f);
    glVertex2f((x+(-0.89f)),-0.77f);
    glEnd();
}
void brickR2(float x,float y)
{
    ///brick 2
    glBegin(GL_POLYGON);
    glColor3ub(48,85,129);
    glVertex2f((x+(-0.94f)),-0.80f);
    glVertex2f((x+(-0.86f)),-0.80f);
    glVertex2f((x+(-0.86f)),-0.88f);
    glVertex2f((x+(-0.94f)),-0.88f);
    glEnd();

    ///brick 2 points
    glPointSize(4.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.935f)),-0.81f);
    glVertex2f((x+(-0.865f)),-0.81f);
    glVertex2f((x+(-0.865f)),-0.87f);
    glVertex2f((x+(-0.935f)),-0.87f);
    glEnd();

    ///brick 2 inside
    glBegin(GL_POLYGON);
    glColor3ub(72,161,189);
    glVertex2f((x+(-0.93f)),-0.82f);
    glVertex2f((x+(-0.87f)),-0.82f);
    glVertex2f((x+(-0.87f)),-0.86f);
    glVertex2f((x+(-0.93f)),-0.86f);
    glEnd();

    ///brick 2 Line 1
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(255,255,255,102);
    glVertex2f((x+(-0.93f)),-0.82f);
    glVertex2f((x+(-0.87f)),-0.82f);
    glEnd();

    ///brick 2 Line 2
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_LINES);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.87f)),-0.82f);
    glVertex2f((x+(-0.87f)),-0.86f);
    glEnd();

    ///brick 2 Line 3
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.87f)),-0.86f);
    glVertex2f((x+(-0.93f)),-0.86f);
    glEnd();

    ///brick 2 Line 4
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(255,255,255,102);
    glVertex2f((x+(-0.93f)),-0.86f);
    glVertex2f((x+(-0.93f)),-0.82f);
    glEnd();


    ///brick 3
    glBegin(GL_POLYGON);
    glColor3ub(48,85,129);
    glVertex2f((x+(-0.85f)),-0.80f);
    glVertex2f((x+(-0.77f)),-0.80f);
    glVertex2f((x+(-0.77f)),-0.88f);
    glVertex2f((x+(-0.85f)),-0.88f);
    glEnd();

    ///brick 3 points
    glPointSize(4.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.84f)),-0.81f);
    glVertex2f((x+(-0.78f)),-0.81f);
    glVertex2f((x+(-0.78f)),-0.87f);
    glVertex2f((x+(-0.84f)),-0.87f);
    glEnd();

}

void brickR3(float x, float y)
{
    ///brick 1
    glBegin(GL_POLYGON);
    glColor3ub(48,85,129);
    glVertex2f((x+(-0.99f)),-0.90f);
    glVertex2f((x+(-0.91f)),-0.90f);
    glVertex2f((x+(-0.91f)),-0.98f);
    glVertex2f((x+(-0.99f)),-0.98f);
    glEnd();

    ///brick 1 points
    glPointSize(4.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.985f)),-0.91f);
    glVertex2f((x+(-0.915f)),-0.91f);
    glVertex2f((x+(-0.915f)),-0.97f);
    glVertex2f((x+(-0.985f)),-0.97f);
    glEnd();

    ///brick 1 inside
    glBegin(GL_POLYGON);
    glColor3ub(72,161,189);
    glVertex2f((x+(-0.98f)),-0.92f);
    glVertex2f((x+(-0.92f)),-0.92f);
    glVertex2f((x+(-0.92f)),-0.96f);
    glVertex2f((x+(-0.98f)),-0.96f);
    glEnd();

    ///brick 1 Line 1
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(255,255,255,102);
    glVertex2f((x+(-0.98f)),-0.92f);
    glVertex2f((x+(-0.92f)),-0.92f);
    glEnd();

    ///brick 1 Line 2
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_LINES);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.92f)),-0.92f);
    glVertex2f((x+(-0.92f)),-0.96f);
    glEnd();

    ///brick 1 Line 3
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(0,0,0,90);
    glVertex2f((x+(-0.92f)),-0.96f);
    glVertex2f((x+(-0.98f)),-0.96f);
    glEnd();

    ///brick 1 Line 4
    glLineWidth(3);
    glBegin(GL_LINES);
    glColor4ub(255,255,255,102);
    glVertex2f((x+(-0.98f)),-0.96f);
    glVertex2f((x+(-0.98f)),-0.92f);
    glEnd();


    ///brick 2
    glBegin(GL_POLYGON);
    glColor3ub(48,85,129);
    glVertex2f((x+(-0.90f)),-0.90f);
    glVertex2f((x+(-0.82f)),-0.90f);
    glVertex2f((x+(-0.82f)),-0.98f);
    glVertex2f((x+(-0.90f)),-0.98f);
    glEnd();

    ///brick 2 points
    glPointSize(4.0f);
    glBegin(GL_POINTS);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.89f)),-0.91f);
    glVertex2f((x+(-0.83f)),-0.91f);
    glVertex2f((x+(-0.83f)),-0.97f);
    glVertex2f((x+(-0.89f)),-0.97f);
    glEnd();
}
void levelDevide(float x,float y)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POLYGON);
    glColor4ub(255,255,255,120);
    glVertex2f((x+(-0.83f)),-0.52f);
    glVertex2f((x+(-0.82f)),-0.52f);
    glVertex2f((x+(-0.82f)),-0.67f);
    glVertex2f((x+(-0.83f)),-0.67f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.83f)),-0.52f);
    glVertex2f((x+(-0.83f)),-0.67f);
    glEnd();
}

void backbox_Upper()
{
    ///wall back upper silver

    glBegin(GL_POLYGON);
    glColor3ub(47,150,175);
    glVertex2f(-0.46f,-0.04f);
    glVertex2f(0.13f,-0.04f);
    glVertex2f(0.13f,-0.19f);
    glVertex2f(-0.46f,-0.19f);
    glEnd();
}

void levelDevideUp(float x,float y)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POLYGON);
    glColor4ub(255,255,255,120);
    glVertex2f((x+(-0.28f)),-0.04f);
    glVertex2f((x+(-0.27f)),-0.04f);
    glVertex2f((x+(-0.27f)),-0.19f);
    glVertex2f((x+(-0.28f)),-0.19f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2f((x+(-0.28f)),-0.04f);
    glVertex2f((x+(-0.28f)),-0.19f);
    glEnd();
}

void pathway()
{

    backbox_Upper();

    levelDevideUp(0.0,0.0);
    levelDevideUp(0.10,0.0);
    levelDevideUp(0.20,0.0);
    levelDevideUp(0.30,0.0);
    levelDevideUp(0.40,0.0);

    glPushMatrix();
    glTranslatef(0.0,0.48,0.0);
    obst1(0.53,0.0);
    glPopMatrix();

    ///white Back ground white transparent up
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POLYGON);
    glColor4ub(255,255,255,110);
    glVertex2f(-0.46f,-0.06f);
    glVertex2f(.130f,-0.06f);
    glVertex2f(.130f,-0.075f);
    glVertex2f(-0.46f,-0.075f);
    glEnd();

    glPushMatrix();
    glTranslatef(0.0,0.48,0.0);
    ///black Back ground solid
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(0.13f,-0.63f);
    glVertex2f(-.460f,-0.63f);
    glVertex2f(-.46f,-0.67f);
    glVertex2f(0.130f,-0.67f);


    ///black Back ground transparent 1
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(0.13f,-0.60f);
    glVertex2f(-.460f,-0.60f);
    glVertex2f(-.460f,-0.64f);
    glVertex2f(0.13f,-0.64f);
    glEnd();

    ///black Back ground transparent 2
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(0.13f,-0.655f);
    glVertex2f(-.460f,-0.655f);
    glVertex2f(-.460f,-0.67f);
    glVertex2f(0.13f,-0.67f);
    glEnd();

    ///black Back ground solid
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(0.13f,-0.61f);
    glVertex2f(-.460f,-0.61f);
    glVertex2f(-.460f,-0.63f);
    glVertex2f(0.13f,-0.63f);
    glEnd();

    glPopMatrix();
}

void X_sign_M3(float x, float y)
{
    glBegin(GL_LINES);
    glColor3ub(49,52,59);
     glVertex2f(x+(-0.07),y+(0.92));
    glVertex2f(x+(0.04f),y+(0.62f));
    glVertex2f(x+(-0.07f),y+(0.61f));
    glVertex2f(x+(0.05f),y+(0.91f));
    glEnd();
}

void X_Box_M3(float x,float y)
{

    glBegin(GL_POLYGON);
    glColor3ub(159,161,170);
    glVertex2f(x+(-0.09),y+(1.00f));
    glVertex2f(x+(-0.09f),y+(0.92f));
    glVertex2f(x+(0.9f),y+(0.92f));
    glVertex2f(x+(0.9f),y+(1.00f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(159,161,170);
    glVertex2f(x+(-0.09),y+(0.61f));
    glVertex2f(x+(-0.09f),y+(0.53f));
    glVertex2f(x+(0.89f),y+(0.53f));
    glVertex2f(x+(0.89f),y+(0.61f));
    glEnd();

    glLineWidth(15);
    glBegin(GL_LINES);
    glColor3ub(49,52,59);
    glVertex2f(x+(-0.07),y+(0.92f));
    glVertex2f(x+(-0.07f),y+(0.61f));
    glVertex2f(x+(0.88f),y+(0.92f));
    glVertex2f(x+(0.88f),y+(0.61f));
    glEnd();

     glLineWidth(12);
    glBegin(GL_LINES);
    glColor3ub(49,52,59);
    glVertex2f(x+(-0.07),y+(0.92f));
    glVertex2f(x+(0.88f),y+(0.92f));
    glVertex2f(x+(-0.07f),y+(0.61f));
    glVertex2f(x+(0.88f),y+(0.61f));
    glEnd();


    cross(x+(0),y+(0));
    cross(x+(0.12),y+(0));
    cross(x+(0.24),y+(0));
    cross(x+(0.36),y+(0));
    cross(x+(0.48),y+(0));
    cross(x+(0.60),y+(0));
    cross(x+(0.72),y+(0));
    cross(x+(0.84),y+(0));


}


void bridge_M3(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(43,35,67);
    glVertex2f(x+(-0.9),y+(-0.52));
    glVertex2f(x+(0.07),y+(-0.52));
    glVertex2f(x+(0.07),y+(-0.99));
    glVertex2f(x+(-0.9),y+(-0.99));
    glEnd();
//black
    glBegin(GL_POLYGON);
    glColor3ub(52,52,50);
    glVertex2f(x+(-0.9),y+(-0.52));
    glVertex2f(x+(0.07),y+(-0.52));
    glVertex2f(x+(0.07),y+(-0.63));
    glVertex2f(x+(-0.9),y+(-0.63));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(14,135,204);
    glVertex2f(x+(-0.9),y+(-0.77));
    glVertex2f(x+(0.07),y+(-0.77));
    glVertex2f(x+(0.07),y+(-0.99));
    glVertex2f(x+(-0.9),y+(-0.99));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(129,198,235);
    glVertex2f(x+(-0.9),y+(-0.8));
    glVertex2f(x+(-0.4),y+(-0.82));
    glVertex2f(x+(-0.9),y+(-0.85));

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(129,198,235);
    glVertex2f(x+(0.07),y+(-0.79));
    glVertex2f(x+(0.07),y+(-0.83));
    glVertex2f(x+(-0.25),y+(-0.81));

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(129,198,235);
    glVertex2f(x+(0.07),y+(-0.94));
    glVertex2f(x+(0.07),y+(-0.97));
    glVertex2f(x+(-0.56),y+(-0.96));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(131,133,142);
    glVertex2f(x+(-0.87),y+(-0.63));
    glVertex2f(x+(-0.89),y+(-0.63));
    glVertex2f(x+(-0.79),y+(-0.9));
    glVertex2f(x+(-0.77),y+(-0.89));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(131,133,142);
    glVertex2f(x+(-0.79),y+(-0.9));
    glVertex2f(x+(-0.78),y+(-0.89));
    glVertex2f(x+(-0.09),y+(-0.89));
    glVertex2f(x+(-0.08),y+(-0.91));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(131,133,142);
    glVertex2f(x+(-0.09),y+(-0.89));
    glVertex2f(x+(-0.08),y+(-0.91));
    glVertex2f(x+(0.07),y+(-0.62));
    glVertex2f(x+(0.05),y+(-0.62));

    glEnd();


   /* glBegin(GL_POLYGON);
    glColor3ub(,,);
    glVertex2f(x+(),y+());
    glVertex2f(x+(),y+());
    glVertex2f(x+(),y+());
    glVertex2f(x+(),y+());
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(,,);
    glVertex2f(x+(),y+());
    glVertex2f(x+(),y+());
    glVertex2f(x+(),y+());
    glVertex2f(x+(),y+());
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(,,);
    glVertex2f(x+(),y+());
    glVertex2f(x+(),y+());
    glVertex2f(x+(),y+());
    glVertex2f(x+(),y+());
    glEnd();*/
}

void bridgepiller(float x, float y)
{
    //pilar 4
    glBegin(GL_POLYGON);
    glColor3ub(225,232,238);
    glVertex2f(x+(-0.11),y+(-0.63));
    glVertex2f(x+(-0.16),y+(-0.63));
    glVertex2f(x+(-0.16),y+(-0.85));
    glVertex2f(x+(-0.11),y+(-0.85));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(225,232,238);

    glVertex2f(x+(-0.11),y+(-0.85));
    glVertex2f(x+(-0.16),y+(-0.85));
    glVertex2f(x+(-0.18),y+(-0.9));
    glVertex2f(x+(-0.09),y+(-0.9));

    glEnd();
}

