#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

bool isPointInScreen(float x, float y) {
    return (x >= 0 && x <= 1700 && y >= 0 && y <= 785);
}

// Check if a brick object is within the screen boundaries
bool isBrickInScreen(const obstacle1& obstacle1) {
    // Define the vertices of the brick object
    float vertices[4][2] = {
        {obstacle1.x + 0.30f, obstacle1.y - 0.54f},
        {obstacle1.x + 0.50f, obstacle1.y - 0.54f},
        {obstacle1.x + 0.50f, obstacle1.y - 0.44f},
        {obstacle1.x + 0.30f, obstacle1.y - 0.44f}
    };

    // Check each vertex if it's within the screen boundaries
    for (int i = 0; i < 4; ++i) {
        if (!isPointInScreen(vertices[i][0], vertices[i][1])) {
            return false; // If any vertex is outside the screen, return false
        }
    }
    return true;
}

