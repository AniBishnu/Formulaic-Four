#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

Character c4;
void snowtriangle(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(234,249,254);
    glVertex2f(x+(-1.0f),y+(-0.67f));
    glVertex2f(x+(-0.98f),y+(-0.86f));
    glVertex2f(x+(-0.96f),y+(-0.67f));
    glEnd();
}
void snowtriangle2(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(234,249,254);
    glVertex2f(x+(-1.0f),y+(-0.67f));
    glVertex2f(x+(-0.97f),y+(-0.89f));
    glVertex2f(x+(-0.94f),y+(-0.67f));
    glEnd();
}
void snowtriangle3(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(234,249,254);
    glVertex2f(x+(-1.0f),y+(-0.67f));
    glVertex2f(x+(-0.99f),y+(-0.84f));
    glVertex2f(x+(-0.98f),y+(-0.67f));
    glEnd();
}
void snowtriangle4(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(234,249,254);
    glVertex2f(x+(-1.0f),y+(-0.67f));
    glVertex2f(x+(-0.965f),y+(-0.92f));
    glVertex2f(x+(-0.93f),y+(-0.67f));
    glEnd();
}
void snowtriangle5(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(234,249,254);
    glVertex2f(x+(-1.0f),y+(-0.67f));
    glVertex2f(x+(-0.99f),y+(-0.81f));
    glVertex2f(x+(-0.98f),y+(-0.67f));
    glEnd();
}
void snowtriangle6(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(234,249,254);
    glVertex2f(x+(-1.0f),y+(-0.67f));
    glVertex2f(x+(-0.98f),y+(-0.84f));
    glVertex2f(x+(-0.96f),y+(-0.67f));
    glEnd();
}

void snow_Draw()
{
    snowtriangle(0.0,0.0);
    snowtriangle(0.03,0.05);
    snowtriangle(0.05,0.02);
    snowtriangle2(0.08,0.00);
    snowtriangle(0.13,0.03);
    snowtriangle(0.16,0.0);
    snowtriangle4(0.2,0.0);
    snowtriangle2(0.25,0.01);
    snowtriangle5(0.30,0.00);
    snowtriangle2(0.31,0.01);
    snowtriangle6(0.36,0.00);
    snowtriangle(0.38,0.05);

    glPushMatrix();
    glTranslatef(.4,0.0,0.0);
    snowtriangle(0.0,0.0);
    snowtriangle(0.03,0.05);
    snowtriangle(0.05,0.02);
    snowtriangle2(0.08,0.00);
    snowtriangle(0.13,0.03);
    snowtriangle(0.16,0.0);
    snowtriangle4(0.2,0.0);
    snowtriangle2(0.25,0.01);
    snowtriangle5(0.30,0.00);
    snowtriangle2(0.31,0.01);
    snowtriangle6(0.36,0.00);
    snowtriangle(0.38,0.05);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.8,0.0,0.0);
    snowtriangle(0.0,0.0);
    snowtriangle(0.03,0.05);
    snowtriangle(0.05,0.02);
    snowtriangle2(0.08,0.00);
    snowtriangle(0.13,0.03);
    snowtriangle(0.16,0.0);
    snowtriangle4(0.2,0.0);
    snowtriangle2(0.25,0.01);
    snowtriangle5(0.30,0.00);
    snowtriangle2(0.31,0.01);
    snowtriangle6(0.36,0.00);
    snowtriangle(0.38,0.05);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(1.2,0.0,0.0);
    snowtriangle(0.0,0.0);
    snowtriangle(0.03,0.05);
    snowtriangle(0.05,0.02);
    snowtriangle2(0.08,0.00);
    snowtriangle(0.13,0.03);
    snowtriangle(0.16,0.0);
    snowtriangle4(0.2,0.0);
    snowtriangle2(0.25,0.01);
    snowtriangle5(0.30,0.00);
    snowtriangle2(0.31,0.01);
    snowtriangle6(0.36,0.00);
    snowtriangle(0.38,0.05);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(1.6,0.0,0.0);
    snowtriangle(0.0,0.0);
    snowtriangle(0.03,0.05);
    snowtriangle(0.05,0.02);
    snowtriangle2(0.08,0.00);
    snowtriangle(0.13,0.03);
    snowtriangle(0.16,0.0);
    snowtriangle4(0.2,0.0);
    snowtriangle2(0.25,0.01);
    snowtriangle5(0.30,0.00);
    snowtriangle2(0.31,0.01);
    snowtriangle6(0.365,0.00);
    glPopMatrix();
}

void backgroundHill_Light()
{
    ///back pahar light 1
    glBegin(GL_POLYGON);
    glColor3ub(161,196,236);
    glVertex2f(-0.55f,-0.24f);
    glVertex2f(-0.63f,0.11f);
    glVertex2f(-0.8f,0.17f);
    glVertex2f(-1.0f,0.37f);
    glVertex2f(-1.0f,-0.54f);
    glVertex2f(-0.55f,-0.54f);
    glEnd();

    ///back pahar light 2
    glBegin(GL_POLYGON);
    glColor3ub(161,196,236);
    glVertex2f(-0.55f,-0.24f);
    glVertex2f(-0.33f,-0.06f);
    glVertex2f(-0.16f,-0.25f);
    glVertex2f(-0.16f,-0.54f);
    glVertex2f(-0.55f,-0.54f);
    glEnd();

    ///back pahar light 3
    glBegin(GL_POLYGON);
    glColor3ub(161,196,236);
    glVertex2f(-0.16f,-0.24f);
    glVertex2f(-0.03f,0.29f);
    glVertex2f(0.23f,0.12f);
    glVertex2f(0.42f,-0.24f);
    glVertex2f(0.42f,-0.54f);
    glVertex2f(-0.16f,-0.54f);
    glEnd();

    ///back pahar light 4
    glBegin(GL_POLYGON);
    glColor3ub(161,196,236);
    glVertex2f(0.42f,-0.24f);
    glVertex2f(0.61f,0.05f);
    glVertex2f(0.78f,0.11f);
    glVertex2f(1.0f,0.37f);
    glVertex2f(1.0f,-0.54f);
    glVertex2f(0.42f,-0.54f);
    glEnd();
}

void backgroundHill_Dark_Tree(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(-0.53f),y+(-0.3f));
    glVertex2f(x+(-0.52f),y+(-0.2f));
    glVertex2f(x+(-0.51f),y+(-0.3f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(-0.515f),y+(-0.3f));
    glVertex2f(x+(-0.505f),y+(-0.18f));
    glVertex2f(x+(-0.5f),y+(-0.3f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(-0.505f),y+(-0.3f));
    glVertex2f(x+(-0.498f),y+(-0.23f));
    glVertex2f(x+(-0.491f),y+(-0.3f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(-0.495f),y+(-0.29f));
    glVertex2f(x+(-0.486f),y+(-0.19f));
    glVertex2f(x+(-0.477f),y+(-0.3f));
    glEnd();
}

void backgroundHill_Dark_Tree2(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(-0.18f),y+(-0.31f));
    glVertex2f(x+(-0.175f),y+(-0.25f));
    glVertex2f(x+(-0.17f),y+(-0.31f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(-0.1725f),y+(-0.31f));
    glVertex2f(x+(-0.1675f),y+(-0.2f));
    glVertex2f(x+(-0.1575f),y+(-0.3f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(-0.16f),y+(-0.27f));
    glVertex2f(x+(-0.15f),y+(-0.13f));
    glVertex2f(x+(-0.14f),y+(-0.27f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(-0.145f),y+(-0.26f));
    glVertex2f(x+(-0.139f),y+(-0.16f));
    glVertex2f(x+(-0.133f),y+(-0.26f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(-0.136f),y+(-0.26f));
    glVertex2f(x+(-0.13f),y+(-0.1f));
    glVertex2f(x+(-0.124f),y+(-0.26f));
    glEnd();
}

void backgroundHill_Dark_Tree3(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(0.463f),y+(-0.35f));
    glVertex2f(x+(0.473f),y+(-0.27f));
    glVertex2f(x+(0.483f),y+(-0.35f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(0.473f),y+(-0.35f));
    glVertex2f(x+(0.493f),y+(-0.25f));
    glVertex2f(x+(0.503f),y+(-0.35f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(0.45f),y+(-0.35f));
    glVertex2f(x+(0.46f),y+(-0.22f));
    glVertex2f(x+(0.47f),y+(-0.31f));
    glEnd();
}

void backgroundHill_Dark_Tree4(float x,float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(0.92f),y+(-0.11f));
    glVertex2f(x+(0.93f),y+(-0.04f));
    glVertex2f(x+(0.94f),y+(-0.13f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(0.937f),y+(-0.13f));
    glVertex2f(x+(0.945f),y+(-0.02f));
    glVertex2f(x+(0.953f),y+(-0.15f));
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(x+(0.948f),y+(-0.17f));
    glVertex2f(x+(0.955f),y+(-0.08f));
    glVertex2f(x+(0.962f),y+(-0.2f));
    glEnd();
}
void backgroundHill_Dark()
{
    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(-1.0f,-0.22f);
    glVertex2f(-0.93f,-0.29f);
    glVertex2f(-0.93f,-0.54f);
    glVertex2f(-1.0f,-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(-0.93f,-0.29f);
    glVertex2f(-0.79f,-0.02f);
    glVertex2f(-0.65f,-0.12f);
    glVertex2f(-0.58f,-0.32f);
    glVertex2f(-0.58f,-0.54f);
    glVertex2f(-0.93f,-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(-0.58f,-0.31f);
    glVertex2f(-0.37f,-0.25f);
    glVertex2f(-0.23f,-0.37f);
    glVertex2f(-0.23f,-0.54f);
    glVertex2f(-0.58f,-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(-0.23f,-0.37f);
    glVertex2f(-0.06f,-0.05f);
    glVertex2f(0.14f,-0.29f);
    glVertex2f(0.14f,-0.54f);
    glVertex2f(-0.29f,-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(0.14f,-0.29f);
    glVertex2f(0.33f,-0.19f);
    glVertex2f(0.48f,-0.32f);
    glVertex2f(0.48f,-0.54f);
    glVertex2f(0.14f,-0.54f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42,67,124);
    glVertex2f(0.48f,-0.32f);
    glVertex2f(0.74f,-0.05f);
    glVertex2f(0.95f,-0.12f);
    glVertex2f(1.0f,-0.22f);
    glVertex2f(1.0f,-0.54f);
    glVertex2f(0.48f,-0.54f);
    glEnd();

    backgroundHill_Dark_Tree(0.0,0.0);
    backgroundHill_Dark_Tree2(0.0,0.025);
    backgroundHill_Dark_Tree3(0.0,0.0);
    backgroundHill_Dark_Tree4(0.0,0.0);
}


void display_Map4_Start()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Set background color to black and opaque
    glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer (background)

    glPushMatrix();
    glTranslatef(mapTranslateX, 0.0f, 0.0f);

    ///Back ground
    glBegin(GL_POLYGON);
    glColor3ub(158,236,255);
    glVertex2f(1.0f,1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glVertex2f(-1.0f,1.0f);
    glEnd();

    backgroundHill_Light();
    backgroundHill_Dark();

    ///wall
    glBegin(GL_POLYGON);
    glColor3ub(234,249,254);
    glVertex2f(-1.0f,-0.54f);
    glVertex2f(1.0f,-0.54f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(-1.0f,-0.67f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(25,50,57);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();

    ///under ice components 1
    glBegin(GL_POLYGON);
    glColor3ub(5,169,181);
    glVertex2f(-0.91f,-0.67f);
    glVertex2f(-0.8f,-0.67f);
    glVertex2f(-0.83f,-1.0f);
    glVertex2f(-0.9f,-1.0f);
    glEnd();

    ///under ice components 2
    glBegin(GL_POLYGON);
    glColor3ub(5,169,181);
    glVertex2f(-0.73f,-0.67f);
    glVertex2f(-0.67f,-0.67f);
    glVertex2f(-0.68f,-1.0f);
    glVertex2f(-0.77f,-1.0f);
    glEnd();

    ///under ice components 3
    glBegin(GL_POLYGON);
    glColor3ub(5,169,181);
    glVertex2f(-0.64f,-0.67f);
    glVertex2f(-0.57f,-0.67f);
    glVertex2f(-0.57f,-1.0f);
    glVertex2f(-0.61f,-1.0f);
    glEnd();

    ///under ice components 4
    glBegin(GL_POLYGON);
    glColor3ub(5,169,181);
    glVertex2f(-0.48f,-0.67f);
    glVertex2f(-0.42f,-0.67f);
    glVertex2f(-0.48f,-1.0f);
    glVertex2f(-0.51f,-1.0f);
    glEnd();

    ///under ice components 5
    glBegin(GL_POLYGON);
    glColor3ub(5,169,181);
    glVertex2f(-0.3f,-0.67f);
    glVertex2f(-0.24f,-0.67f);
    glVertex2f(-0.21f,-1.0f);
    glVertex2f(-0.33f,-1.0f);
    glEnd();

    ///under ice components 6
    glBegin(GL_POLYGON);
    glColor3ub(5,169,181);
    glVertex2f(-0.08f,-0.67f);
    glVertex2f(0.09f,-0.67f);
    glVertex2f(0.06f,-1.0f);
    glVertex2f(-0.02f,-1.0f);
    glEnd();

    ///under ice components 7
    glBegin(GL_POLYGON);
    glColor3ub(7,150,166);
    glVertex2f(0.2f,-0.67f);
    glVertex2f(0.64f,-0.67f);
    glVertex2f(0.6f,-1.0f);
    glVertex2f(0.23f,-1.0f);
    glEnd();


    ///under ice components 8
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POLYGON);
    glColor4ub(255,255,255,102);
    glVertex2f(0.4f,-0.67f);
    glVertex2f(0.47f,-0.67f);
    glVertex2f(0.43f,-1.0f);
    glVertex2f(0.4f,-1.0f);
    glEnd();

    ///under ice components 9
    glBegin(GL_POLYGON);
    glColor3ub(5,169,181);
    glVertex2f(0.71f,-0.67f);
    glVertex2f(0.8f,-0.67f);
    glVertex2f(0.78f,-1.0f);
    glVertex2f(0.72f,-1.0f);
    glEnd();


    snow_Draw();

/*
    glBegin(GL_POLYGON);
    glColor3ub(164,175,178);
    glVertex2f(-1.0f,-0.55f);
    glVertex2f(1.0f,-0.55f);
    glVertex2f(1.0f,-0.6f);
    glVertex2f(-1.0f,-0.6f);
    glEnd();*/

    cave c1;
    c1.caveDraw();

    c4.position1(-0.9,-0.78);
    glPopMatrix();
    glFlush();
}
