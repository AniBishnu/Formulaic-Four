#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void display()
{
    glClearColor(0.196f, 0.658f, 0.514, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    Initial_Display="load";
    Start_Game();

    glFlush();
}


int main(int argc, char** argv) {
    glutInit(&argc, argv);
    ///glutInitDisplayMode(GLUT_DOUBLE);
    glutInitWindowSize(850, 290);
    glutInitWindowPosition(525, 345);
    glutCreateWindow("EggVenture");
    glutDisplayFunc(display);

    /// glutReshapeFunc(windowReshape);
    ///glutSpecialFunc(Movement_SpecialInputM2);
    ///glutKeyboardFunc(Movement_handleKeypress);
    glutMainLoop();

    return 0;
}
