#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

class coin_silver
{
public:
    float x_Axis;
    float y_Axis;
public:
    coin_silver()
    {}
    void position(float x, float y)
    {
        glBegin(GL_POLYGON);
        glColor3ub(204,204,204);
        glVertex2f((0.5f-x),(-0.31f-y));
        glVertex2f((0.53f-x),(-0.37f-y));
        glVertex2f((0.5f-x),(-0.43f-y));
        glVertex2f((0.47f-x),(-0.37f-y));
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(117,117,117);
        glVertex2f((0.5f-x),(-0.33f-y));
        glVertex2f((0.52f-x),(-0.37f-y));
        glVertex2f((0.5f-x),(-0.41f-y));
        glVertex2f((0.48f-x),(-0.37f-y));
        glEnd();
    }
};
