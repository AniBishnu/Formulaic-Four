#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

using namespace std;
char input_strt;

int i=1;
void map_change()
{
    if(i==1)
    {
        Home_display();
        input_strt = inputed_option_Home();
        if (input_strt == 's')
        {
            ///input_strt = ' ';
            glutKeyboardFunc(Movement_handleKeypress_Map_Opt);
            Map_Opt_display();
            input_strt = inputed_option_Map_Opt();
            if (input_strt == '1') {
                glutKeyboardFunc(Movement_handleKeypress);
                glutSpecialFunc(Movement_SpecialInput);
                Initial_Display="Map1";
                ///input_strt = ' ';
                display_Map1_Start();
            }
            else if (input_strt == '2') {
                glutKeyboardFunc(Movement_handleKeypressM2);
                glutSpecialFunc(Movement_SpecialInputM2);
                Initial_Display="Map1";
                ///input_strt = ' ';
                display_Map2_Start();
            }
            else if (input_strt == '3') {
                glutKeyboardFunc(Movement_handleKeypressM3);
                glutSpecialFunc(Movement_SpecialInputM3);
                Initial_Display="Map1";
                //input_strt = ' ';
                display_Map3_Start();
            }
            else if (input_strt == '4') {
                glutKeyboardFunc(Movement_handleKeypressM3);
                glutSpecialFunc(Movement_SpecialInputM3);
                Initial_Display="Map1";
                ///input_strt = ' ';
                display_Map4_Start();
            }
            else if (input_strt == 'b') {
                Initial_Display="home";
                ///input_strt = ' ';
                map_change();
            }
        }
        else if(input_strt == 't')
        {
            Team_display();
        }
    }
    else if(i==2)
    {
        glutKeyboardFunc(Movement_handleKeypress_Map_Opt);
            Map_Opt_display();
            input_strt = inputed_option_Map_Opt();
            if (input_strt == '1') {
                glutKeyboardFunc(Movement_handleKeypress);
                glutSpecialFunc(Movement_SpecialInput);
                Initial_Display="Map1";
                ///input_strt = ' ';
                display_Map1_Start();
            }
            else if (input_strt == 'b') {
                Initial_Display="home";
                ///input_strt = ' ';
                map_change();
            }
    }
}

void Start_Game() {
    ///input_strt == ' ';
    if (Initial_Display == "load" && Load_Scale <= 1.31) {
        Load_display();
    } else {
        glutKeyboardFunc(Movement_handleKeypress_Home);
        glutReshapeWindow(1700, 785);
        glutPositionWindow(100, 140);
        map_change();
    }
}

