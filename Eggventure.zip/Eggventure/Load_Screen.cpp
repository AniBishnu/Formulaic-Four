#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

Character c5;
void LoadBar()
{
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f((-0.7f),-0.39f);
    glVertex2f(Load_Scale+(-0.58f),-0.39f);
    glVertex2f(Load_Scale+(-0.58),-0.48f);
    glVertex2f((-0.7f),-0.48f);
    glEnd();
}

void update_Load(int value)
{
    if(Load_Scale<1.31)
    {
        Load_Scale+=0.00001;
        glutPostRedisplay();
        glutTimerFunc(10, update_Load, 0);
    }
    else if(Load_Scale>=1.30)
    {
        Initial_Display="home";
    }
}

void Load_display()
{
    glClearColor(0, 0, 0, 0.0f); // Set background color to black and opaque
    glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer (background)



    glutTimerFunc(100, update_Load, 0);

    ///Back ground
    glBegin(GL_POLYGON);
    glColor3ub(158,236,255);
    glVertex2f(1.0f,1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glVertex2f(-1.0f,1.0f);
    glEnd();



    ///Load

    glBegin(GL_POLYGON);
    glColor3ub(217,217,217);
    glVertex2f(-0.72f,-0.35f);
    glVertex2f(0.75f,-0.35);
    glVertex2f(0.75f,-0.54f);
    glVertex2f(-0.72f,-0.54f);
    glEnd();

    LoadBar();

///box1
     glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.84f,-0.37f);
    glVertex2f(-0.77f,-0.37f);
    glVertex2f(-0.77f,-0.48f);
    glVertex2f(-0.84f,-0.48f);
    glEnd();

    ///box 2
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.8f,-0.39f);
    glVertex2f(0.87f,-0.39);
    glVertex2f(0.87f,-0.5f);
    glVertex2f(0.8f,-0.5f);
    glEnd();

    c5.position1(-0.9,-0.50);
    glColor3ub(0,0,0);
    renderBitmapString(-0.18f, 0.35f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "EGGVENTURE");

    glFlush(); // Render now
}
