#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

Character c3;

void display_Map3_Start()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Set background color to black and opaque
    glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer (background)


    ///Back ground
    glBegin(GL_POLYGON);
    glColor3ub(43,35,67);
    glVertex2f(1.0f,1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glVertex2f(-1.0f,1.0f);
    glEnd();

    glPushMatrix();
    glTranslatef(mapTranslateX, 0.0f, 0.0f);





    ///wall back upper

    glBegin(GL_POLYGON);
    glColor3ub(47,150,175);
    glVertex2f(-1.0f,-0.52f);
    glVertex2f(1.0f,-0.52f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(-1.0f,-0.67f);
    glEnd();

    ///wall back down
    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();

    ///yellow and black brick
    obst1(0.0,0.0);
    obst1(0.36,0.0);
    obst1(1.06,0.0);
    obst1(1.26,0.0);
    obst1(1.56,0.0);


    ///white Back ground white transparent 1
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_POLYGON);
    glColor4ub(255,255,255,110);
    glVertex2f(1.0f,-0.535f);
    glVertex2f(-1.0f,-0.535f);
    glVertex2f(-1.0f,-0.55f);
    glVertex2f(1.0f,-0.55f);
    glEnd();


    levelDevide(0.0,0.0);
    levelDevide(0.10,0.10);
    levelDevide(0.20,0.20);
    levelDevide(0.30,0.30);
    levelDevide(0.40,0.40);
    levelDevide(0.50,0.50);
    levelDevide(0.60,0.60);
    levelDevide(0.70,0.70);
    levelDevide(0.80,0.80);
    levelDevide(0.90,0.90);
    levelDevide(1.00,1.00);
    levelDevide(1.10,1.10);
    levelDevide(1.20,1.20);
    levelDevide(1.30,1.30);
    levelDevide(1.40,1.40);
    levelDevide(1.50,1.50);
    levelDevide(1.60,1.60);
    levelDevide(1.70,1.70);
    levelDevide(1.80,1.80);

    ///black Back ground solid
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(1.0f,-0.61f);
    glVertex2f(-1.0f,-0.61f);
    glVertex2f(-1.0f,-0.63f);
    glVertex2f(1.0f,-0.63f);
    glEnd();


    ///black Back ground solid
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(1.0f,-0.63f);
    glVertex2f(-1.0f,-0.63f);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(1.0f,-0.67f);


    ///black Back ground transparent 1
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(1.0f,-0.60f);
    glVertex2f(-1.0f,-0.60f);
    glVertex2f(-1.0f,-0.64f);
    glVertex2f(1.0f,-0.64f);
    glEnd();

    ///black Back ground transparent 2
    glBegin(GL_POLYGON);
    glColor4ub(0,0,0,102);
    glVertex2f(1.0f,-0.655f);
    glVertex2f(-1.0f,-0.655f);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(1.0f,-0.67f);
    glEnd();

    ///Row 1
    brickR1(0.00,0.00);
    brickR1(0.18,0.00);
    brickR1(0.36,0.00);
    brickR1(0.54,0.00);
    brickR1(0.72,0.00);
    brickR1(0.9,0.00);
    brickR1(1.08,0.00);
    brickR1(1.26,0.00);
    brickR1(1.44,0.00);
    brickR1(1.62,0.00);
    brickR1(1.8,0.00);
    brickR1(1.98,0.00);
    brickR1(2.16,0.00);

    ///Row 2

     ///brick 1
    glBegin(GL_POLYGON);
    glColor3ub(48,85,129);
    glVertex2f(-0.99f,-0.80f);
    glVertex2f(-0.95f,-0.80f);
    glVertex2f(-0.95f,-0.88f);
    glVertex2f(-0.99f,-0.88f);
    glEnd();

    brickR2(0.00,0.00);
    brickR2(0.18,0.00);
    brickR2(0.36,0.00);
    brickR2(0.54,0.00);
    brickR2(0.72,0.00);
    brickR2(0.9,0.00);
    brickR2(1.08,0.00);
    brickR2(1.26,0.00);
    brickR2(1.44,0.00);
    brickR2(1.62,0.00);
    brickR2(1.8,0.00);
    brickR2(1.98,0.00);

    ///Row 3
    brickR3(0.00,0.00);
    brickR3(0.18,0.00);
    brickR3(0.36,0.00);
    brickR3(0.54,0.00);
    brickR3(0.72,0.00);
    brickR3(0.9,0.00);
    brickR3(1.08,0.00);
    brickR3(1.26,0.00);
    brickR3(1.44,0.00);
    brickR3(1.62,0.00);
    brickR3(1.8,0.00);
    brickR3(1.98,0.00);

    door d1;
    d1.Door1(0.00,0.00);


    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(1.05f,-1.0f);
    glVertex2f(1.05f,1.0f);
    glVertex2f(1.0f,1.0f);
    glEnd();


    display_Map3_Screen1(0.0,0.0);
    display_Map3_Screen2();
    display_Map3_Screen3();

    c3.position1(-0.9,-0.78);
    glPopMatrix();


    point_table();
    glFlush();
}


void updateM3(int value) {
    if (jumping) {
        if (charTranslatey < 0.35 && jumped == false) {
            charTranslatey += 0.01;
            glutTimerFunc(15, updateM3, 0);
        } else {
            jumped = true;
                charTranslatey -= 0.01;
                glutTimerFunc(15, updateM3, 0);
                if (charTranslatey <= 0.0) {
                    jumping = false;
                    jumped = false;
                    charTranslatey = 0.0;
                }
            }

        }


    glutPostRedisplay();
}

void update2M3(int value)
 {
    if (jumping) {
        mapTranslateX -= 0.004;
        charTranslateX += 0.004;
        if (charTranslatey <1.0 && jumped == false) {
            charTranslatey += 0.01;
            glutTimerFunc(10, update2M3, 0); // Call update2 recursively with 10ms delay
        } else {
            jumped = true;
            charTranslatey -= 0.01;
            glutTimerFunc(10, update2M3, 0); // Call update2 recursively with 10ms delay
            if (charTranslatey <= 0.0) {
                jumping = false;
                jumped = false;
                charTranslatey = 0.0;
            }
        }
    }
    glutPostRedisplay();
}


void Movement_SpecialInputM3(int key, int x, int y)
{
    switch(key)
    {
        case GLUT_KEY_UP:
            if (!jumping) {
                jumping = true;
                updateM3(0);
            }
            break;

        case GLUT_KEY_DOWN:

            break;

        case GLUT_KEY_LEFT:

                mapTranslateX += 0.01;
                charTranslateX -= 0.01;
                glutPostRedisplay();

            break;


        case GLUT_KEY_RIGHT:

                    mapTranslateX -= 0.01;
                    charTranslateX += 0.01;
                    glutPostRedisplay();


            break;
        case GLUT_KEY_INSERT:
            if (!jumping) {
                jumping = true;
                update2M3(0);
            }
            break;

            ///Shift key method
        /*case GLUT_ACTIVE_SHIFT:
            if (key == GLUT_KEY_RIGHT) {
                shiftupdate(0);
            }
            break;*/

    }
    glutPostRedisplay();
}


void Movement_handleKeypressM3(unsigned char key, int x, int y)
{
	switch (key)
    {
    case ' ':
            if (!jumping) {
                jumping = true;
                update2M3(0);
            }
            break;

    glutPostRedisplay();

	}
}
