#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"


void TopBordarS1(float x, float y)
{
    glBegin(GL_QUADS);
    glColor3ub(159,149,150);
    glVertex2f(0.45f,y+(0.37f));
    glVertex2f(0.96f,y+(0.37f));
    glVertex2f(0.96f,y+(0.32f));
    glVertex2f(0.45f,y+(0.32f));
    glEnd();

}
///
void wallbackS1(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(0.46f,y+(0.32f));
    glVertex2f(0.95f,y+(0.32f));
    glVertex2f(0.95f,y+(0.06f));
    glVertex2f(0.46f,y+(0.06f));
    glEnd();
}

///
void topbox(float x, float y)
{
    glBegin(GL_TRIANGLES);
    glColor3ub(159,149,150);
    glVertex2f(x+(-0.45f),y+(0.77f));
    glVertex2f(x+(-0.35f),y+(0.77f));
    glVertex2f(x+(-0.4f),y+(0.46f));
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(159,149,150);
    glVertex2f(x+(-0.48f),y+(0.84f));
    glVertex2f(x+(-0.32f),y+(0.84f));
    glVertex2f(x+(-0.32f),y+(0.77f));
    glVertex2f(x+(-0.48f),y+(0.77f));
    glEnd();
}

void display_Map2_Screen1(float x,float y)
{
    glPushMatrix();
    glTranslatef(2.0,0.0,0.0);




    ///wall

    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(0.45f,-0.54f);
    glVertex2f(1.0f,-0.54f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(0.45f,-0.67f);
    glEnd();

    ///wall

    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(-0.86f,-0.54f);
    glVertex2f(-1.0f,-0.54f);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(-0.86f,-0.67f);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(1.0f,-0.67f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();


    ///beside wall


    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(-0.88f,-0.19f);
    glVertex2f(-0.21f,-0.19f);
    glVertex2f(-0.21f,-0.33f);
    glVertex2f(-0.88f,-0.33f);
    glEnd();


     glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(-0.86f,-0.33f);
    glVertex2f(-0.23f,-0.33f);
    glVertex2f(-0.23f,-0.67f);
    glVertex2f(-0.86f,-0.67f);
    glEnd();




     /// Bricks
    ///1
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.7f);
    glVertex2f(-0.89f,-0.7f);
    glVertex2f(-0.89f,-0.78f);
    glVertex2f(-0.99f,-0.78f);
    glEnd();
    ///2
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.99f,-0.8f);
    glVertex2f(-0.89f,-0.8f);
    glVertex2f(-0.89f,-0.88f);
    glVertex2f(-0.99f,-0.88f);
    glEnd();

    ///3
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.9f);
    glVertex2f(-0.87f,-0.9f);
    glVertex2f(-0.87f,-1.0f);
    glVertex2f(-0.99f,-1.0f);
    glEnd();

    ///4
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.88f,-0.7f);
    glVertex2f(-0.82f,-0.7f);
    glVertex2f(-0.82f,-0.78f);
    glVertex2f(-0.88f,-0.78f);
    glEnd();

    ///5
    glBegin(GL_POLYGON);
     glColor3ub(117,51,16);
    glVertex2f(-0.81f,-0.7f);
    glVertex2f(-0.77f,-0.7f);
    glVertex2f(-0.77f,-0.78f);
    glVertex2f(-0.81f,-0.78f);
    glEnd();

  ///6
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(-0.76f,-0.7f);
    glVertex2f(-0.67f,-0.7f);
    glVertex2f(-0.67f,-0.78f);
    glVertex2f(-0.76f,-0.78f);
    glEnd();

    ///7
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(-0.66f,-0.7f);
    glVertex2f(-0.53f,-0.7f);
    glVertex2f(-0.53f,-0.78f);
    glVertex2f(-0.66f,-0.78f);
    glEnd();
    ///8
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.52f,-0.7f);
    glVertex2f(-0.45f,-0.7f);
    glVertex2f(-0.45f,-0.78f);
    glVertex2f(-0.52f,-0.78f);
    glEnd();

       ///9
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.44f,-0.7f);
    glVertex2f(-0.37f,-0.7f);
    glVertex2f(-0.37f,-0.78f);
    glVertex2f(-0.44f,-0.78f);
    glEnd();


       ///10
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(-0.36f,-0.7f);
    glVertex2f(-0.3f,-0.7f);
    glVertex2f(-0.3f,-0.78f);
    glVertex2f(-0.36f,-0.78f);
    glEnd();

        ///11
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.29f,-0.7f);
    glVertex2f(-0.17f,-0.7f);
    glVertex2f(-0.17f,-0.78f);
    glVertex2f(-0.29f,-0.78f);
    glEnd();

     ///12
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.16f,-0.7f);
    glVertex2f(-0.05f,-0.7f);
    glVertex2f(-0.05f,-0.78f);
    glVertex2f(-0.16f,-0.78f);
    glEnd();

         ///13
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.04f,-0.7f);
    glVertex2f(0.03f,-0.7f);
    glVertex2f(0.03f,-0.78f);
    glVertex2f(-0.04f,-0.78f);
    glEnd();

     ///14
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.04f,-0.7f);
    glVertex2f(0.19f,-0.7f);
    glVertex2f(0.19f,-0.78f);
    glVertex2f(0.04f,-0.78f);
    glEnd();


     ///15
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.20f,-0.7f);
    glVertex2f(0.23f,-0.7f);
    glVertex2f(0.23f,-0.78f);
    glVertex2f(0.20,-0.78f);
    glEnd();

    ///16
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.24f,-0.7f);
    glVertex2f(0.39f,-0.7f);
    glVertex2f(0.39f,-0.78f);
    glVertex2f(0.24,-0.78f);
    glEnd();

      ///17
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.4f,-0.7f);
    glVertex2f(0.51f,-0.7f);
    glVertex2f(0.51f,-0.78f);
    glVertex2f(0.4,-0.78f);
    glEnd();

          ///18
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.52f,-0.7f);
    glVertex2f(0.59f,-0.7f);
    glVertex2f(0.59f,-0.78f);
    glVertex2f(0.52,-0.78f);
    glEnd();

          ///19
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.6f,-0.7f);
    glVertex2f(0.64f,-0.7f);
    glVertex2f(0.64f,-0.78f);
    glVertex2f(0.6,-0.78f);
    glEnd();


          ///20
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.65f,-0.7f);
    glVertex2f(0.74f,-0.7f);
    glVertex2f(0.74f,-0.78f);
    glVertex2f(0.65,-0.78f);
    glEnd();

             ///21
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.75f,-0.7f);
    glVertex2f(0.8f,-0.7f);
    glVertex2f(0.8f,-0.78f);
    glVertex2f(0.75,-0.78f);
    glEnd();

           ///22
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.81f,-0.7f);
    glVertex2f(0.88f,-0.7f);
    glVertex2f(0.88f,-0.78f);
    glVertex2f(0.81,-0.78f);
    glEnd();

              ///23
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.89f,-0.7f);
    glVertex2f(1.0f,-0.7f);
    glVertex2f(1.0f,-0.78f);
    glVertex2f(0.89,-0.78f);
    glEnd();



///24
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.88f,-0.8f);
    glVertex2f(-0.78f,-0.8f);
    glVertex2f(-0.78f,-0.88f);
    glVertex2f(-0.88f,-0.88f);
    glEnd();

    ///25
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(-0.77f,-0.8f);
    glVertex2f(-0.66f,-0.8f);
    glVertex2f(-0.66f,-0.88f);
    glVertex2f(-0.77f,-0.88f);
    glEnd();

      ///26
    glBegin(GL_POLYGON);
    glColor3ub(123,81,57);
    glVertex2f(-0.65f,-0.8f);
    glVertex2f(-0.54f,-0.8f);
    glVertex2f(-0.54f,-0.88f);
    glVertex2f(-0.65f,-0.88f);
    glEnd();

      ///27
    glBegin(GL_POLYGON);
    glColor3ub(234,186,138);
    glVertex2f(-0.53f,-0.8f);
    glVertex2f(-0.44f,-0.8f);
    glVertex2f(-0.44f,-0.88f);
    glVertex2f(-0.53f,-0.88f);
    glEnd();

      ///28
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.43f,-0.8f);
    glVertex2f(-0.3f,-0.8f);
    glVertex2f(-0.3f,-0.88f);
    glVertex2f(-0.43f,-0.88f);
    glEnd();
    ///29
    glBegin(GL_POLYGON);
    glColor3ub(123,81,57);
    glVertex2f(-0.29f,-0.8f);
    glVertex2f(-0.15f,-0.8f);
    glVertex2f(-0.15f,-0.88f);
    glVertex2f(-0.29f,-0.88f);
    glEnd();

 ///30
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.14f,-0.8f);
    glVertex2f(-0.09f,-0.8f);
    glVertex2f(-0.09f,-0.88f);
    glVertex2f(-0.14f,-0.88f);
    glEnd();

     ///31
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.08f,-0.8f);
    glVertex2f(0.0,-0.8f);
    glVertex2f(0,-0.88f);
    glVertex2f(-0.08f,-0.88f);
    glEnd();

       ///32
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.01f,-0.8f);
    glVertex2f(0.15f,-0.8f);
    glVertex2f(0.15f,-0.88f);
    glVertex2f(0.01f,-0.88f);
    glEnd();

         ///33
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.16f,-0.8f);
    glVertex2f(0.28f,-0.8f);
    glVertex2f(0.28f,-0.88f);
    glVertex2f(0.16f,-0.88f);
    glEnd();

         ///34
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.29f,-0.8f);
    glVertex2f(0.38f,-0.8f);
    glVertex2f(0.38f,-0.88f);
    glVertex2f(0.29f,-0.88f);
    glEnd();

      ///34
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.39f,-0.8f);
    glVertex2f(0.46f,-0.8f);
    glVertex2f(0.46f,-0.88f);
    glVertex2f(0.39f,-0.88f);
    glEnd();
        ///35
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.47f,-0.8f);
    glVertex2f(0.51f,-0.8f);
    glVertex2f(0.51f,-0.88f);
    glVertex2f(0.47f,-0.88f);
    glEnd();
       ///36
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.52f,-0.8f);
    glVertex2f(0.6f,-0.8f);
    glVertex2f(0.6f,-0.88f);
    glVertex2f(0.52f,-0.88f);
    glEnd();

        ///37
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.61f,-0.8f);
    glVertex2f(0.75f,-0.8f);
    glVertex2f(0.75f,-0.88f);
    glVertex2f(0.61f,-0.88f);
    glEnd();
    ///38
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.76f,-0.8f);
    glVertex2f(0.91f,-0.8f);
    glVertex2f(0.91f,-0.88f);
    glVertex2f(0.76f,-0.88f);
    glEnd();
 ///40
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.92f,-0.8f);
    glVertex2f(1.0f,-0.8f);
    glVertex2f(1.0f,-0.88f);
    glVertex2f(0.92f,-0.88f);
    glEnd();


    ///41
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.86f,-0.9f);
    glVertex2f(-0.79f,-0.9f);
    glVertex2f(-0.79f,-1.0f);
    glVertex2f(-0.86f,-1.0f);
    glEnd();

     ///41
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.78f,-0.9f);
    glVertex2f(-0.71f,-0.9f);
    glVertex2f(-0.71f,-1.0f);
    glVertex2f(-0.78f,-1.0f);
    glEnd();
       ///42
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(-0.70f,-0.9f);
    glVertex2f(-0.63f,-0.9f);
    glVertex2f(-0.63f,-1.0f);
    glVertex2f(-0.70f,-1.0f);
    glEnd();

         ///43
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.62f,-0.9f);
    glVertex2f(-0.52f,-0.9f);
    glVertex2f(-0.52f,-1.0f);
    glVertex2f(-0.62f,-1.0f);
    glEnd();

          ///43
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.51f,-0.9f);
    glVertex2f(-0.41f,-0.9f);
    glVertex2f(-0.41f,-1.0f);
    glVertex2f(-0.51f,-1.0f);
    glEnd();
        ///44
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.40f,-0.9f);
    glVertex2f(-0.31f,-0.9f);
    glVertex2f(-0.31f,-1.0f);
    glVertex2f(-0.40f,-1.0f);
    glEnd();
          ///45
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.30f,-0.9f);
    glVertex2f(-0.27f,-0.9f);
    glVertex2f(-0.27f,-1.0f);
    glVertex2f(-0.30f,-1.0f);
    glEnd();

           ///46
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(-0.26f,-0.9f);
    glVertex2f(-0.17f,-0.9f);
    glVertex2f(-0.17f,-1.0f);
    glVertex2f(-0.26f,-1.0f);
    glEnd();

       ///47
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.16f,-0.9f);
    glVertex2f(-0.01f,-0.9f);
    glVertex2f(-0.01f,-1.0f);
    glVertex2f(-0.16f,-1.0f);
    glEnd();

      ///47
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0,-0.9f);
    glVertex2f(0.07f,-0.9f);
    glVertex2f(0.07f,-1.0f);
    glVertex2f(0,-1.0f);
    glEnd();

      ///47
    glBegin(GL_POLYGON);
    glColor3ub(123,81,57);
    glVertex2f(0.08,-0.9f);
    glVertex2f(0.18f,-0.9f);
    glVertex2f(0.18f,-1.0f);
    glVertex2f(0.08,-1.0f);
    glEnd();

     ///48
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.19,-0.9f);
    glVertex2f(0.34f,-0.9f);
    glVertex2f(0.34f,-1.0f);
    glVertex2f(0.19,-1.0f);
    glEnd();
     ///49
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.35,-0.9f);
    glVertex2f(0.41f,-0.9f);
    glVertex2f(0.41f,-1.0f);
    glVertex2f(0.35,-1.0f);
    glEnd();
    ///50
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.42,-0.9f);
    glVertex2f(0.49f,-0.9f);
    glVertex2f(0.49f,-1.0f);
    glVertex2f(0.42,-1.0f);
    glEnd();

       ///51
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.5,-0.9f);
    glVertex2f(0.62f,-0.9f);
    glVertex2f(0.62f,-1.0f);
    glVertex2f(0.5f,-1.0f);
    glEnd();
           ///52
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.63,-0.9f);
    glVertex2f(0.75f,-0.9f);
    glVertex2f(0.75f,-1.0f);
    glVertex2f(0.63,-1.0f);
    glEnd();
    ///53
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.76,-0.9f);
    glVertex2f(0.87f,-0.9f);
    glVertex2f(0.87f,-1.0f);
    glVertex2f(0.76,-1.0f);
    glEnd();
    ///54
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.88,-0.9f);
    glVertex2f(1.0f,-0.9f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(0.88f,-1.0f);
    glEnd();

    bottomTriangle(0.5,0);
    bottomTriangle(0.75,0);
    TopBordarS1(0,0);
    TopBordarS1(0.0,-0.31);
    wallbackS1(0,0);
    wallBrick(-0.21,-0.34);
    wallBrick1(-0.21,-0.34);
    wallBrick(0.06,-0.34);
    wallBrick1(0.06,-0.34);
    wallBrick3(-0.484,-0.34);
    wallBrick4(-0.21,-0.34);
    wallBrick(-0.13,-0.44);
    wallBrick1(-0.13,-0.44);
    wallBrick(0.14,-0.44);
    wallBrick1(0.14,-0.44);
    wallBrick3(-1.02,-0.54);
    wallBrick1(-0.26,-0.54);
    wallBrick(0.01,-0.54);
    wallBrick1(0.01,-0.54);
    wallBrick(0.276,-0.54);

    ///besides
    wallBrick(1.11,0.31);
    wallBrick1(1.11,0.31);
    wallBrick(1.381,0.31);
    wallBrick4(1.516,0.41);
    wallBrick4(1.11,0.31);
    wallBrick(1.19,0.21);
    wallBrick1(1.19,0.21);
    wallBrick(1.456,0.21);


    glPopMatrix();

}
