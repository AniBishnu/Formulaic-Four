#include <windows.h>
#include <GL/glut.h>

#include"Map1.h"
#include "Map2.h"
#include "Map3.h"
#include "Map4.h"
#include "Obstacles.h"
#include "Start.h"

void bridgepillerfirstwall()
{
    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(-1.0f,-0.54f);
    glVertex2f(-0.8f,-0.54f);
    glVertex2f(-0.8f,-0.67f);
    glVertex2f(-1.0f,-0.67f);
    glEnd();
}


void bridgepillersecondwall()
{
    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(0.33f,-0.67f);
    glVertex2f(0.33f,-0.54f);
    glVertex2f(0.76f,-0.54f);
    glVertex2f(0.76f,-0.67f);
    glEnd();
}


void bridgeDownpiller()
{
     glBegin(GL_POLYGON);
    glColor3ub(37,47,56);
    glVertex2f(-0.8f,-0.55f);
    glVertex2f(-0.8f,-0.66f);
    glVertex2f(0.33f,-0.66f);
    glVertex2f(0.33f,-0.55f);
    glEnd();
}

void bridgefirsttriangle()
{
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(-0.78f,-0.13f);
    glVertex2f(-0.9f,-0.54f);
    glVertex2f(-0.93f,-0.54f);
    glVertex2f(-0.78f,-0.04f);
    glVertex2f(-0.65f,-0.55f);
    glVertex2f(-0.68f,-0.55f);

    glEnd();
}

void bridgesecondtriangle()
{
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(-0.5f,-0.13f);
    glVertex2f(-0.62f,-0.55f);
    glVertex2f(-0.65f,-0.55f);
    glVertex2f(-0.5f,-0.04f);
    glVertex2f(-0.36f,-0.55f);
    glVertex2f(-0.39f,-0.55f);


    glEnd();
}

void bridgethirdtriangle()
{
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(-0.21f,-0.13f);
    glVertex2f(-0.33f,-0.55f);

    glVertex2f(-0.36f,-0.55f);
    glVertex2f(-0.21f,-0.04f);

    glVertex2f(-0.08f,-0.55f);
    glVertex2f(-0.11f,-0.55f);


    glEnd();
}


void bridgefourthtriangle()
{
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(0.06f,-0.13f);
    glVertex2f(-0.05f,-0.55f);

    glVertex2f(-0.08f,-0.55f);
    glVertex2f(0.06f,-0.04f);

    glVertex2f(0.2f,-0.55f);
    glVertex2f(0.17f,-0.55f);


    glEnd();
}

void bridgefifthtriangle()
{
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(0.33f,-0.13f);
    glVertex2f(0.23f,-0.55f);

    glVertex2f(0.2f,-0.55f);
    glVertex2f(0.33f,-0.04f);

    glVertex2f(0.47f,-0.54f);
    glVertex2f(0.44f,-0.54f);


    glEnd();
}

 void all1()
{

     ///bridge upper line
    glBegin(GL_POLYGON);
    glColor3ub(120,5,135);
    glVertex2f(-0.8f,-0.03f);
    glVertex2f(-0.8f,0.03f);
    glVertex2f(0.36f,0.03f);
    glVertex2f(0.36f,-0.03f);


    glEnd();

     ///bridge upper 1st triangle
    glBegin(GL_TRIANGLES);
    glColor3ub(120,5,135);
      glVertex2f(-0.76f,-0.03f);
    glVertex2f(-0.78f,-0.11f);
    glVertex2f(-0.8f,-0.03f);


    glEnd();

     ///bridge upper 5th triangle
    glBegin(GL_TRIANGLES);
    glColor3ub(120,5,135);
    glVertex2f(0.36f,-0.03f);
    glVertex2f(0.33f,-0.11f);
    glVertex2f(0.30f,-0.03f);


    glEnd();

       ///bridge upper 4th triangle
    glBegin(GL_TRIANGLES);
    glColor3ub(120,5,135);
    glVertex2f(0.08f,-0.03f);
    glVertex2f(0.06f,-0.11f);
    glVertex2f(0.04f,-0.03f);


    glEnd();


       ///bridge upper 3rd triangle
    glBegin(GL_TRIANGLES);
    glColor3ub(120,5,135);
      glVertex2f(-0.19f,-0.03f);
    glVertex2f(-0.21f,-0.11f);
    glVertex2f(-0.23f,-0.03f);


    glEnd();



       ///bridge upper 2nd triangle
    glBegin(GL_TRIANGLES);
    glColor3ub(120,5,135);
    glVertex2f(-0.48f,-0.03f);
    glVertex2f(-0.5f,-0.11f);
    glVertex2f(-0.52f,-0.03f);


    glEnd();



    ///Cement piller upper

    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(-0.32f,-0.66f);
    glVertex2f(-0.32f,-0.76f);
    glVertex2f(-0.11f,-0.76f);
    glVertex2f(-0.11f,-0.66f);
    glEnd();



    ///Cement piller down

    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(-0.29f,-0.76f);
    glVertex2f(-0.29f,-1.0f);
    glVertex2f(-0.14f,-1.0f);
    glVertex2f(-0.14f,-0.76f);
    glEnd();

    ///Cement piller shade

    glBegin(GL_POLYGON);
    glColor3ub(89,84,86);
    glVertex2f(-0.29f,-0.76f);
    glVertex2f(-0.29f,-0.78f);
    glVertex2f(-0.14f,-0.78f);
    glVertex2f(-0.14f,-0.76f);
    glEnd();


     ///Cement piller 1st line

    glBegin(GL_LINE_LOOP);
    glColor3ub(118,111,112);
    glVertex2f(-0.26f,-0.81f);
    glVertex2f(-0.26f,-1.0f);

    glEnd();

    ///Cement piller 2nd line

    glBegin(GL_LINE_LOOP);
    glColor3ub(118,111,112);
    glVertex2f(-0.21f,-0.81f);
    glVertex2f(-0.21f,-1.0f);

    glEnd();

        ///Cement piller 3rd line

    glBegin(GL_LINE_LOOP);
    glColor3ub(118,111,112);
    glVertex2f(-0.16f,-0.81f);
    glVertex2f(-0.16f,-1.0f);

    glEnd();


        ///Trap lower rectangle

    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(0.82f,-0.94f);
    glVertex2f(0.82f,-1.0f);
    glVertex2f(0.98f,-1.0f);
    glVertex2f(0.98f,-0.94f);
    glEnd();


        ///Trap black shade

    glBegin(GL_LINE_LOOP);
    glColor3ub(118,111,112);
    glVertex2f(0.82f,-0.94f);

    glVertex2f(0.98f,-0.94f);
    glEnd();



        ///Trap upper tangle

    glBegin(GL_POLYGON);
    glColor3ub(159,149,150);
    glVertex2f(0.85f,-0.94f);
    glVertex2f(0.9f,-0.65f);
    glVertex2f(0.95f,-0.94f);

    glEnd();

}



void display_Map2_Screen3(float x,float y)
{
    glPushMatrix();
    glTranslatef(6.0,0.0,0.0);



    ///Water
    glBegin(GL_POLYGON);
    glColor3ub(46,165,255);
    glVertex2f(-1.0f,-0.83f);
    glVertex2f(-1.0f,-1.07f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(1.0f,-0.83f);

    glEnd();

    ///wall

    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(-0.81f,-0.78f);
    glVertex2f(-0.76f,-0.78f);
    glVertex2f(-0.76f,-0.89f);
    glVertex2f(-0.78f,-0.89f);
    glVertex2f(-0.78f,-1.0f);
    glVertex2f(-1.0f,-1.00f);
    glVertex2f(-1.0f,-0.67f);
    glVertex2f(-0.81f,-0.67f);
    glEnd();

    ///wall

    glBegin(GL_POLYGON);
    glColor3ub(62,64,76);
    glVertex2f(0.37f,-0.89f);
    glVertex2f(0.34f,-0.89f);
    glVertex2f(0.34f,-1.0f);
    glVertex2f(0.76f,-1.0f);
    glVertex2f(0.76f,-0.77f);
    glVertex2f(0.75f,-0.77f);
    glVertex2f(0.75f,-0.67f);
    glVertex2f(0.39f,-0.67f);
    glVertex2f(0.39f,-0.77f);
    glVertex2f(0.37f,-0.77f);
    glEnd();



     /// Bricks
    ///1
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.7f);
    glVertex2f(-0.89f,-0.7f);
    glVertex2f(-0.89f,-0.78f);
    glVertex2f(-0.99f,-0.78f);
    glEnd();
    ///2
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.99f,-0.8f);
    glVertex2f(-0.89f,-0.8f);
    glVertex2f(-0.89f,-0.88f);
    glVertex2f(-0.99f,-0.88f);
    glEnd();

    ///3
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.99f,-0.9f);
    glVertex2f(-0.87f,-0.9f);
    glVertex2f(-0.87f,-1.0f);
    glVertex2f(-0.99f,-1.0f);
    glEnd();

    ///4
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(-0.88f,-0.7f);
    glVertex2f(-0.82f,-0.7f);
    glVertex2f(-0.82f,-0.78f);
    glVertex2f(-0.88f,-0.78f);
    glEnd();




      ///17
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.4f,-0.7f);
    glVertex2f(0.51f,-0.7f);
    glVertex2f(0.51f,-0.78f);
    glVertex2f(0.4,-0.78f);
    glEnd();

          ///18
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.52f,-0.7f);
    glVertex2f(0.59f,-0.7f);
    glVertex2f(0.59f,-0.78f);
    glVertex2f(0.52,-0.78f);
    glEnd();

          ///19
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.6f,-0.7f);
    glVertex2f(0.64f,-0.7f);
    glVertex2f(0.64f,-0.78f);
    glVertex2f(0.6,-0.78f);
    glEnd();


    ///20
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.65f,-0.7f);
    glVertex2f(0.74f,-0.7f);
    glVertex2f(0.74f,-0.78f);
    glVertex2f(0.65,-0.78f);
    glEnd();






    ///24
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(-0.88f,-0.8f);
    glVertex2f(-0.78f,-0.8f);
    glVertex2f(-0.78f,-0.88f);
    glVertex2f(-0.88f,-0.88f);
    glEnd();





      ///34
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.39f,-0.8f);
    glVertex2f(0.46f,-0.8f);
    glVertex2f(0.46f,-0.88f);
    glVertex2f(0.39f,-0.88f);
    glEnd();
        ///35
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.47f,-0.8f);
    glVertex2f(0.51f,-0.8f);
    glVertex2f(0.51f,-0.88f);
    glVertex2f(0.47f,-0.88f);
    glEnd();
       ///36
    glBegin(GL_POLYGON);
    glColor3ub(163,110,60);
    glVertex2f(0.52f,-0.8f);
    glVertex2f(0.6f,-0.8f);
    glVertex2f(0.6f,-0.88f);
    glVertex2f(0.52f,-0.88f);
    glEnd();

        ///37
    glBegin(GL_POLYGON);
    glColor3ub(178,101,33);
    glVertex2f(0.61f,-0.8f);
    glVertex2f(0.75f,-0.8f);
    glVertex2f(0.75f,-0.88f);
    glVertex2f(0.61f,-0.88f);
    glEnd();


    ///41
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(-0.86f,-0.9f);
    glVertex2f(-0.79f,-0.9f);
    glVertex2f(-0.79f,-1.0f);
    glVertex2f(-0.86f,-1.0f);
    glEnd();






     ///49
    glBegin(GL_POLYGON);
    glColor3ub(178,155,121);
    glVertex2f(0.35,-0.9f);
    glVertex2f(0.41f,-0.9f);
    glVertex2f(0.41f,-1.0f);
    glVertex2f(0.35,-1.0f);
    glEnd();
    ///50
    glBegin(GL_POLYGON);
    glColor3ub(124,87,60);
    glVertex2f(0.42,-0.9f);
    glVertex2f(0.49f,-0.9f);
    glVertex2f(0.49f,-1.0f);
    glVertex2f(0.42,-1.0f);
    glEnd();

       ///51
    glBegin(GL_POLYGON);
    glColor3ub(117,51,16);
    glVertex2f(0.5,-0.9f);
    glVertex2f(0.62f,-0.9f);
    glVertex2f(0.62f,-1.0f);
    glVertex2f(0.5f,-1.0f);
    glEnd();
           ///52
    glBegin(GL_POLYGON);
    glColor3ub(68,59,58);
    glVertex2f(0.63,-0.9f);
    glVertex2f(0.75f,-0.9f);
    glVertex2f(0.75f,-1.0f);
    glVertex2f(0.63,-1.0f);
    glEnd();




    bridgeDownpiller();
    bridgefifthtriangle();
    bridgefirsttriangle();
    bridgefourthtriangle();
    bridgepillerfirstwall();
    bridgepillersecondwall();
    bridgesecondtriangle();
    bridgethirdtriangle();
    all1();

    glPopMatrix();
}
